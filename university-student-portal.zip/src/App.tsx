import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Home, 
  Calendar, 
  Award, 
  FileText, 
  BookOpen, 
  Briefcase, 
  DollarSign, 
  Activity, 
  Bell, 
  User, 
  Menu, 
  X, 
  Sparkles,
  Sun,
  Moon,
  GraduationCap,
  ShieldCheck,
  Users,
  Presentation
} from "lucide-react";

// Components
import DashboardScreen from "./components/DashboardScreen";
import ScheduleScreen from "./components/ScheduleScreen";
import GradesScreen from "./components/GradesScreen";
import AssignmentsScreen from "./components/AssignmentsScreen";
import AttendanceScreen from "./components/AttendanceScreen";
import PlacementsScreen from "./components/PlacementsScreen";
import FinanceScreen from "./components/FinanceScreen";
import LibraryScreen from "./components/LibraryScreen";
import NotificationsScreen from "./components/NotificationsScreen";
import ProfileScreen from "./components/ProfileScreen";

// New Operator Role Dashboards
import TeacherDashboard from "./components/TeacherDashboard";
import AdminDashboard from "./components/AdminDashboard";
import AdvisorDashboard from "./components/AdvisorDashboard";

// Types & Data
import { 
  Notification, 
  Profile, 
  Department, 
  Subject, 
  Enrollment, 
  TimetableSlot, 
  AttendanceRecord, 
  AssignmentSubmission, 
  Exam, 
  ExamMark, 
  AdvisorNote, 
  AuditLog,
  Assignment
} from "./types";

import { INITIAL_NOTIFICATIONS, INITIAL_ASSIGNMENTS } from "./data";
import { 
  INITIAL_PROFILES, 
  INITIAL_DEPARTMENTS, 
  INITIAL_SUBJECTS, 
  INITIAL_ENROLLMENTS, 
  INITIAL_TIMETABLE, 
  INITIAL_ATTENDANCE, 
  INITIAL_SUBMISSIONS, 
  INITIAL_EXAMS, 
  INITIAL_EXAM_MARKS, 
  INITIAL_ADVISOR_NOTES, 
  INITIAL_AUDIT_LOGS 
} from "./mockDb";

export default function App() {
  const [activeTab, setActiveTab] = useState<string>("Dashboard");
  const [notifications, setNotifications] = useState<Notification[]>(INITIAL_NOTIFICATIONS);
  const [isDark, setIsDark] = useState<boolean>(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState<boolean>(false);

  // Active Demo Role State Switcher
  const [selectedRole, setSelectedRole] = useState<"student" | "teacher" | "admin" | "advisor">("student");

  // Global Mock Database state synchronizers
  const [profiles, setProfiles] = useState<Profile[]>(INITIAL_PROFILES);
  const [departments, setDepartments] = useState<Department[]>(INITIAL_DEPARTMENTS);
  const [subjects, setSubjects] = useState<Subject[]>(INITIAL_SUBJECTS);
  const [enrollments, setEnrollments] = useState<Enrollment[]>(INITIAL_ENROLLMENTS);
  const [timetable, setTimetable] = useState<TimetableSlot[]>(INITIAL_TIMETABLE);
  const [attendance, setAttendance] = useState<AttendanceRecord[]>(INITIAL_ATTENDANCE);
  const [submissions, setSubmissions] = useState<AssignmentSubmission[]>(INITIAL_SUBMISSIONS);
  const [exams, setExams] = useState<Exam[]>(INITIAL_EXAMS);
  const [examMarks, setExamMarks] = useState<ExamMark[]>(INITIAL_EXAM_MARKS);
  const [advisorNotes, setAdvisorNotes] = useState<AdvisorNote[]>(INITIAL_ADVISOR_NOTES);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>(INITIAL_AUDIT_LOGS);
  const [assignments, setAssignments] = useState<Assignment[]>(INITIAL_ASSIGNMENTS);
  const [digitalAssets, setDigitalAssets] = useState<any[]>([]);

  // Initialize Theme on load
  useEffect(() => {
    const savedTheme = localStorage.getItem("student-portal-theme");
    if (savedTheme === "dark") {
      setIsDark(true);
      document.documentElement.classList.add("dark");
    } else {
      setIsDark(false);
      document.documentElement.classList.remove("dark");
    }
  }, []);

  const handleToggleTheme = () => {
    setIsDark((prev) => {
      const newVal = !prev;
      if (newVal) {
        document.documentElement.classList.add("dark");
        localStorage.setItem("student-portal-theme", "dark");
      } else {
        document.documentElement.classList.remove("dark");
        localStorage.setItem("student-portal-theme", "light");
      }
      return newVal;
    });
  };

  // Callback append helpers
  const handleAddProfile = (newProfile: Profile) => {
    setProfiles(prev => [...prev, newProfile]);
  };

  const handleAddDepartment = (newDept: Department) => {
    setDepartments(prev => [...prev, newDept]);
  };

  const handleAddSubject = (newSubj: Subject) => {
    setSubjects(prev => [...prev, newSubj]);
  };

  const handleAddEnrollment = (newEnr: Enrollment) => {
    setEnrollments(prev => [...prev, newEnr]);
  };

  const handleAddTimetableSlot = (newSlot: TimetableSlot) => {
    setTimetable(prev => [...prev, newSlot]);
  };

  const handleAddAttendanceList = (records: AttendanceRecord[]) => {
    setAttendance(prev => {
      const updated = [...prev];
      records.forEach(rec => {
        const idx = updated.findIndex(r => r.studentId === rec.studentId && r.subjectCode === rec.subjectCode && r.date === rec.date);
        if (idx > -1) {
          updated[idx] = rec;
        } else {
          updated.push(rec);
        }
      });
      return updated;
    });
  };

  const handleAddAssignment = (newAsg: Assignment) => {
    setAssignments(prev => [...prev, newAsg]);
  };

  const handleGradeSubmission = (submissionId: string, score: number, feedback: string, teacherName: string) => {
    setSubmissions(prev => prev.map(sub => {
      if (sub.id === submissionId) {
        return {
          ...sub,
          status: "Graded",
          score,
          feedback,
          gradedAt: new Date().toISOString(),
          gradedBy: teacherName
        };
      }
      return sub;
    }));
  };

  const handleAddExam = (newExam: Exam) => {
    setExams(prev => [...prev, newExam]);
  };

  const handleSaveExamMarkList = (marks: ExamMark[]) => {
    setExamMarks(prev => {
      const updated = [...prev];
      marks.forEach(mk => {
        const idx = updated.findIndex(m => m.studentId === mk.studentId && m.subjectCode === mk.subjectCode && m.examName === mk.examName);
        if (idx > -1) {
          updated[idx] = mk;
        } else {
          updated.push(mk);
        }
      });
      return updated;
    });
  };

  const handlePublishExamMarks = (subjectCode: string, examName: string) => {
    setExamMarks(prev => prev.map(m => {
      if (m.subjectCode === subjectCode && m.examName === examName) {
        return { ...m, published: true };
      }
      return m;
    }));
  };

  const handleAddDigitalAsset = (asset: any) => {
    setDigitalAssets(prev => [...prev, asset]);
  };

  const handleAddAdvisorNote = (newNote: AdvisorNote) => {
    setAdvisorNotes(prev => [...prev, newNote]);
  };

  const handleAddAuditLog = (action: string, entity: string, entityType: string) => {
    let actorName = "Austin Reaves";
    let actorEmail = "austin.reaves@pacific.edu";

    if (selectedRole === "teacher") {
      actorName = "Dr. Emily Ross";
      actorEmail = "emily.ross@pacific.edu";
    } else if (selectedRole === "admin") {
      actorName = "System Administrator";
      actorEmail = "admin@pacific.edu";
    } else if (selectedRole === "advisor") {
      actorName = "Dr. Emily Ross (HOD / Advisor)";
      actorEmail = "emily.ross@pacific.edu";
    }

    const newLog: AuditLog = {
      id: `log-${Date.now()}`,
      actorName,
      actorEmail,
      action,
      entity,
      entityType,
      timestamp: new Date().toISOString()
    };

    setAuditLogs(prev => [newLog, ...prev]);
  };

  // Navigations definitions (Student only)
  const NAV_ITEMS = [
    { name: "Dashboard", label: "Overview", icon: Home },
    { name: "Schedule", label: "Schedules", icon: Calendar },
    { name: "Grades", label: "Academics", icon: Award },
    { name: "Assignments", label: "Assignments", icon: FileText },
    { name: "Attendance", label: "Attendance", icon: Activity },
    { name: "Placements", label: "Careers", icon: Briefcase },
    { name: "Finance", label: "Finance & Fees", icon: DollarSign },
    { name: "Library", label: "Library Catalog", icon: BookOpen },
    { name: "Notifications", label: "Notifications Center", icon: Bell, badge: true },
    { name: "Profile", label: "ID & Settings", icon: User },
  ];

  const handleTabChange = (tabName: string) => {
    setActiveTab(tabName);
    setMobileMenuOpen(false);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const currentUnreadCount = notifications.filter((n) => !n.read).length;

  // Active Actors selected based on selectedRole
  const currentStudent = profiles.find(p => p.id === "student-1")!;
  const currentTeacher = profiles.find(p => p.id === "teacher-ross")!;
  const currentAdvisor = profiles.find(p => p.id === "advisor-ross")!;
  const currentAdmin = profiles.find(p => p.id === "admin-1")!;

  // Render correct component based on activeTab state and selected role
  const renderScreen = () => {
    if (selectedRole === "teacher") {
      return (
        <TeacherDashboard 
          currentTeacher={currentTeacher}
          profiles={profiles}
          subjects={subjects}
          departments={departments}
          enrollments={enrollments}
          attendance={attendance}
          onAddAttendance={handleAddAttendanceList}
          assignments={assignments}
          onAddAssignment={handleAddAssignment}
          submissions={submissions}
          onGradeSubmission={handleGradeSubmission}
          exams={exams}
          onAddExam={handleAddExam}
          examMarks={examMarks}
          onSaveExamMark={handleSaveExamMarkList}
          onPublishExamMarks={handlePublishExamMarks}
          digitalAssets={digitalAssets}
          onAddDigitalAsset={handleAddDigitalAsset}
          auditLogs={auditLogs}
          onAddAuditLog={handleAddAuditLog}
        />
      );
    }

    if (selectedRole === "admin") {
      return (
        <AdminDashboard 
          currentAdmin={currentAdmin}
          profiles={profiles}
          onAddProfile={handleAddProfile}
          departments={departments}
          onAddDepartment={handleAddDepartment}
          subjects={subjects}
          onAddSubject={handleAddSubject}
          enrollments={enrollments}
          onAddEnrollment={handleAddEnrollment}
          timetable={timetable}
          onAddTimetableSlot={handleAddTimetableSlot}
          auditLogs={auditLogs}
          onAddAuditLog={handleAddAuditLog}
        />
      );
    }

    if (selectedRole === "advisor") {
      return (
        <AdvisorDashboard 
          currentAdvisor={currentAdvisor}
          profiles={profiles}
          enrollments={enrollments}
          attendance={attendance}
          assignments={INITIAL_ASSIGNMENTS}
          submissions={submissions}
          exams={exams}
          examMarks={examMarks}
          advisorNotes={advisorNotes}
          onAddAdvisorNote={handleAddAdvisorNote}
          onAddAuditLog={handleAddAuditLog}
        />
      );
    }

    // Default student terminal flow
    switch (activeTab) {
      case "Dashboard":
        return <DashboardScreen onNavigate={handleTabChange} isDark={isDark} />;
      case "Schedule":
        return <ScheduleScreen />;
      case "Grades":
        return <GradesScreen />;
      case "Assignments":
        return <AssignmentsScreen />;
      case "Attendance":
        return <AttendanceScreen />;
      case "Placements":
        return <PlacementsScreen />;
      case "Finance":
        return <FinanceScreen />;
      case "Library":
        return <LibraryScreen />;
      case "Notifications":
        return (
          <NotificationsScreen 
            notifications={notifications} 
            onUpdateNotifications={setNotifications} 
          />
        );
      case "Profile":
        return <ProfileScreen isDark={isDark} onToggleTheme={handleToggleTheme} />;
      default:
        return <DashboardScreen onNavigate={handleTabChange} isDark={isDark} />;
    }
  };

  return (
    <div className="min-h-screen bg-brand-background dark:bg-brand-dark-bg text-brand-on-surface dark:text-gray-100 flex flex-col transition-colors duration-200">
      
      {/* 1. Header Navbar (Mobile top-bar, Desktop header) */}
      <header className="sticky top-0 z-45 glass-layer bg-white/85 dark:bg-slate-900/85 border-b border-brand-container dark:border-slate-800 px-4 md:px-6 py-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
        
        <div className="flex items-center justify-between md:justify-start gap-4 w-full md:w-auto">
          <div className="flex items-center gap-2">
            {/* Mobile hamburger menu toggle */}
            {selectedRole === "student" && (
              <button 
                onClick={() => setMobileMenuOpen(true)}
                className="md:hidden p-2 rounded-xl neu-flat text-brand-on-surface dark:text-gray-100 cursor-pointer"
                aria-label="Open navigation drawer"
              >
                <Menu size={18} />
              </button>
            )}

            <div className="w-8 h-8 rounded-xl bg-brand-primary dark:bg-indigo-500/10 flex items-center justify-center text-white dark:text-indigo-400 font-extrabold shadow-md">
              <Sparkles size={16} className="animate-pulse" />
            </div>
            <div>
              <span className="font-serif italic font-bold text-lg tracking-wide text-brand-primary dark:text-indigo-400">Pacific Portal</span>
              <span className="hidden sm:inline text-[10px] font-mono uppercase bg-indigo-500/10 text-brand-primary dark:text-indigo-300 px-2 py-0.5 rounded ml-2.5">
                {selectedRole === "student" ? "Student Terminal" : selectedRole === "teacher" ? "Instructor Portal" : selectedRole === "admin" ? "Operator Console" : "Advisory Desk"}
              </span>
            </div>
          </div>

          {/* Quick toggle dropdown for mobile role selector */}
          <div className="md:hidden">
            <select
              value={selectedRole}
              onChange={(e) => {
                setSelectedRole(e.target.value as any);
                setActiveTab("Dashboard");
              }}
              className="text-xs p-2 rounded-xl neu-flat text-brand-primary dark:text-indigo-400 font-bold bg-transparent outline-none cursor-pointer border-none"
            >
              <option value="student">Student role</option>
              <option value="teacher">Instructor role</option>
              <option value="advisor">Advisor role</option>
              <option value="admin">Admin role</option>
            </select>
          </div>
        </div>

        {/* 2. Interactive Neumorphic Role Selector for Desktop Viewports */}
        <div className="hidden md:flex items-center gap-2 p-1 rounded-2xl neu-inset bg-brand-surface/30" id="desktop-role-selector">
          <button
            onClick={() => { setSelectedRole("student"); setActiveTab("Dashboard"); }}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
              selectedRole === "student"
                ? "neu-flat text-brand-primary dark:text-indigo-400 scale-[1.02]"
                : "text-brand-on-variant dark:text-gray-400 hover:text-brand-on-surface"
            }`}
          >
            <GraduationCap size={14} /> Student
          </button>
          
          <button
            onClick={() => setSelectedRole("teacher")}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
              selectedRole === "teacher"
                ? "neu-flat text-brand-primary dark:text-indigo-400 scale-[1.02]"
                : "text-brand-on-variant dark:text-gray-400 hover:text-brand-on-surface"
            }`}
          >
            <Presentation size={14} /> Instructor
          </button>

          <button
            onClick={() => setSelectedRole("advisor")}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
              selectedRole === "advisor"
                ? "neu-flat text-brand-primary dark:text-indigo-400 scale-[1.02]"
                : "text-brand-on-variant dark:text-gray-400 hover:text-brand-on-surface"
            }`}
          >
            <Users size={14} /> Advisor/HOD
          </button>

          <button
            onClick={() => setSelectedRole("admin")}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
              selectedRole === "admin"
                ? "neu-flat text-brand-primary dark:text-indigo-400 scale-[1.02]"
                : "text-brand-on-variant dark:text-gray-400 hover:text-brand-on-surface"
            }`}
          >
            <ShieldCheck size={14} /> Operator Admin
          </button>
        </div>

        {/* Global theme toggle & notifications bell */}
        <div className="flex items-center gap-4 self-end md:self-auto">
          <button
            onClick={handleToggleTheme}
            className="w-9 h-9 rounded-full flex items-center justify-center neu-button dark:hover:bg-slate-800 text-brand-on-surface dark:text-gray-100 cursor-pointer"
            aria-label="Toggle display theme"
          >
            {isDark ? <Sun size={15} /> : <Moon size={15} />}
          </button>

          <button
            onClick={() => { setSelectedRole("student"); handleTabChange("Notifications"); }}
            className="w-9 h-9 rounded-full flex items-center justify-center neu-button text-brand-on-surface dark:text-gray-100 relative cursor-pointer"
            aria-label="Open notifications"
          >
            <Bell size={15} />
            {currentUnreadCount > 0 && (
              <span className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-rose-500 text-white text-[9px] font-bold flex items-center justify-center border-2 border-brand-background dark:border-brand-dark-bg">
                {currentUnreadCount}
              </span>
            )}
          </button>

          <div 
            onClick={() => { setSelectedRole("student"); handleTabChange("Profile"); }}
            className="w-9 h-9 rounded-full neu-inset p-0.5 flex items-center justify-center bg-brand-surface cursor-pointer hidden sm:flex"
          >
            <img 
              src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=100&auto=format&fit=crop" 
              alt="Profile" 
              className="w-8 h-8 rounded-full object-cover"
              referrerPolicy="no-referrer"
            />
          </div>
        </div>
      </header>

      {/* 2. Main Full-Height Scaffold Grid */}
      <div className="flex-1 flex w-full max-w-7xl mx-auto px-4 md:px-6 py-6 gap-6 relative">
        
        {/* Left Column Sidebar - ONLY rendered on student terminal mode, hidden on mobile */}
        {selectedRole === "student" && (
          <aside className="w-64 hidden md:flex flex-col gap-6 flex-shrink-0">
            <nav className="p-4 rounded-2xl neu-flat space-y-2 bg-brand-surface/70 dark:bg-brand-dark-surface/40">
              {NAV_ITEMS.map((item) => {
                const Icon = item.icon;
                const isActive = activeTab === item.name;

                return (
                  <button
                    key={item.name}
                    onClick={() => handleTabChange(item.name)}
                    className={`w-full p-3 rounded-xl flex items-center justify-between gap-3 transition-all cursor-pointer ${
                      isActive 
                        ? "neu-inset border-l-4 border-brand-primary text-brand-primary dark:text-indigo-400 font-extrabold" 
                        : "text-brand-on-variant dark:text-gray-400 hover:text-brand-on-surface dark:hover:text-gray-200"
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <Icon size={16} />
                      <span className="text-xs font-semibold">{item.label}</span>
                    </div>

                    {item.badge && currentUnreadCount > 0 && (
                      <span className="text-[9px] font-bold bg-rose-500 text-white px-1.5 py-0.5 rounded-full">
                        {currentUnreadCount}
                      </span>
                    )}
                  </button>
                );
              })}
            </nav>
          </aside>
        )}

        {/* Central Screen Renderer viewport with animated transitions */}
        <main className="flex-1 min-w-0" id="main-scaffold-viewport">
          <AnimatePresence mode="wait">
            <motion.div
              key={selectedRole === "student" ? activeTab : selectedRole}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
            >
              {renderScreen()}
            </motion.div>
          </AnimatePresence>
        </main>
      </div>

      {/* 3. Mobile Bottom tab bar quick access - ONLY on student terminal */}
      {selectedRole === "student" && (
        <nav className="sticky bottom-0 z-40 md:hidden bg-white/95 dark:bg-slate-950/95 border-t border-brand-container dark:border-slate-800 py-2.5 px-4 flex items-center justify-around shadow-lg">
          {NAV_ITEMS.filter((_, idx) => [0, 1, 2, 3, 9].includes(idx)).map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.name;

            return (
              <button
                key={item.name}
                onClick={() => handleTabChange(item.name)}
                className={`flex flex-col items-center justify-center p-2 rounded-lg transition-all cursor-pointer ${
                  isActive 
                    ? "text-brand-primary dark:text-indigo-400 scale-[1.05] font-bold" 
                    : "text-brand-on-variant dark:text-gray-400"
                }`}
              >
                <Icon size={18} />
                <span className="text-[9px] mt-1 font-semibold">{item.name}</span>
              </button>
            );
          })}
        </nav>
      )}

      {/* 4. Sliding hamburger mobile drawer - Glassmorphism sidebar (Student only) */}
      <AnimatePresence>
        {mobileMenuOpen && selectedRole === "student" && (
          <div className="fixed inset-0 z-50 flex md:hidden bg-black/40 backdrop-blur-xs">
            <div className="absolute inset-0" onClick={() => setMobileMenuOpen(false)} />

            <motion.div
              initial={{ x: "-100%" }}
              animate={{ x: 0 }}
              exit={{ x: "-100%" }}
              transition={{ type: "spring", damping: 25, stiffness: 220 }}
              className="relative w-72 h-full glass-layer p-6 flex flex-col justify-between border-r border-white/20"
            >
              <div className="space-y-6">
                {/* Header title */}
                <div className="flex items-center justify-between pb-4 border-b border-brand-container dark:border-slate-800">
                  <div className="flex items-center gap-2">
                    <Sparkles className="text-brand-primary" size={16} />
                    <span className="font-serif italic font-bold text-lg tracking-wide text-brand-primary dark:text-indigo-400">Pacific Portal</span>
                  </div>
                  <button 
                    id="close-drawer-btn"
                    onClick={() => setMobileMenuOpen(false)}
                    className="w-8 h-8 rounded-full flex items-center justify-center neu-button text-rose-500 font-bold cursor-pointer"
                  >
                    <X size={15} />
                  </button>
                </div>

                {/* Vertical item map */}
                <nav className="space-y-1.5" id="drawer-portal-screens">
                  {NAV_ITEMS.map((item) => {
                    const Icon = item.icon;
                    const isActive = activeTab === item.name;

                    return (
                      <button
                        key={item.name}
                        onClick={() => handleTabChange(item.name)}
                        className={`w-full p-3 rounded-xl flex items-center justify-between gap-3 transition-all cursor-pointer ${
                          isActive 
                            ? "neu-inset border-l-4 border-brand-primary text-brand-primary dark:text-indigo-400 font-bold" 
                            : "text-brand-on-variant dark:text-gray-400 hover:text-brand-on-surface dark:hover:text-gray-200"
                        }`}
                      >
                        <div className="flex items-center gap-3">
                          <Icon size={15} />
                          <span className="text-xs font-semibold">{item.label}</span>
                        </div>

                        {item.badge && currentUnreadCount > 0 && (
                          <span className="text-[9px] font-bold bg-rose-500 text-white px-1.5 py-0.5 rounded-full">
                            {currentUnreadCount}
                          </span>
                        )}
                      </button>
                    );
                  })}
                </nav>
              </div>

              {/* Drawer footer */}
              <div className="text-[10px] text-gray-400 font-mono border-t border-brand-container dark:border-slate-800 pt-4">
                {currentStudent?.name || "Student"} • {currentStudent?.rollNumber || "CSE-2024-048"}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
