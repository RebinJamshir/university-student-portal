import { 
  Department, 
  Subject, 
  Profile, 
  Enrollment, 
  AttendanceRecord, 
  AssignmentSubmission, 
  Exam, 
  ExamMark, 
  TimetableSlot, 
  AdvisorNote, 
  AuditLog 
} from "./types";

// 1. Initial Departments
export const INITIAL_DEPARTMENTS: Department[] = [
  { id: "dept-cse", name: "Computer Science & Engineering", code: "CSE" },
  { id: "dept-phy", name: "Physics & Applied Sciences", code: "PHY" },
  { id: "dept-neu", name: "Cognitive Neuroscience & Biology", code: "NEU" },
  { id: "dept-mth", name: "Mathematics & Statistics", code: "MTH" }
];

// 2. Initial Subjects
export const INITIAL_SUBJECTS: Subject[] = [
  { id: "sub-1", name: "Advanced Mathematics", code: "MTH-401", departmentId: "dept-mth", semester: 4, credits: 4 },
  { id: "sub-2", name: "Quantum Physics Lab", code: "PHY-402L", departmentId: "dept-phy", semester: 4, credits: 2 },
  { id: "sub-3", name: "Cognitive Neuroscience", code: "NEU-405", departmentId: "dept-neu", semester: 4, credits: 3 },
  { id: "sub-4", name: "Data Structures & Algorithms", code: "CSE-409", departmentId: "dept-cse", semester: 4, credits: 4 },
  { id: "sub-5", name: "Software Engineering", code: "SWE-412", departmentId: "dept-cse", semester: 4, credits: 3 }
];

// 3. Initial Profiles (Students, Teachers, Admin, Advisors)
export const INITIAL_PROFILES: Profile[] = [
  // Student 1 (Austin Reaves - Current logged in user)
  {
    id: "student-1",
    name: "Austin Reaves",
    email: "austin.reaves@pacific.edu",
    role: "student",
    departmentId: "dept-cse",
    rollNumber: "CSE-2024-048",
    registerNumber: "REG-99023412",
    semester: 4,
    batch: "2024 - 2028",
    advisorId: "advisor-ross",
    academicStatus: "Active"
  },
  // Student 2 (Chloe Bennett)
  {
    id: "student-2",
    name: "Chloe Bennett",
    email: "chloe.b@pacific.edu",
    role: "student",
    departmentId: "dept-cse",
    rollNumber: "CSE-2024-049",
    registerNumber: "REG-99023413",
    semester: 4,
    batch: "2024 - 2028",
    advisorId: "advisor-vance",
    academicStatus: "Active"
  },
  // Student 3 (Marcus Vance)
  {
    id: "student-3",
    name: "Marcus Vance",
    email: "marcus.v@pacific.edu",
    role: "student",
    departmentId: "dept-cse",
    rollNumber: "CSE-2024-050",
    registerNumber: "REG-99023414",
    semester: 4,
    batch: "2024 - 2028",
    advisorId: "advisor-ross",
    academicStatus: "Probation"
  },
  // Student 4 (Seraphina Sterling)
  {
    id: "student-4",
    name: "Seraphina Sterling",
    email: "seraphina.s@pacific.edu",
    role: "student",
    departmentId: "dept-phy",
    rollNumber: "PHY-2024-012",
    registerNumber: "REG-99023415",
    semester: 4,
    batch: "2024 - 2028",
    advisorId: "advisor-ross",
    academicStatus: "Active"
  },
  // Student 5 (Elena Rostova)
  {
    id: "student-5",
    name: "Elena Rostova",
    email: "elena.r@pacific.edu",
    role: "student",
    departmentId: "dept-neu",
    rollNumber: "NEU-2024-025",
    registerNumber: "REG-99023416",
    semester: 4,
    batch: "2024 - 2028",
    advisorId: "advisor-vance",
    academicStatus: "Active"
  },

  // Teachers
  {
    id: "teacher-ross",
    name: "Dr. Emily Ross",
    email: "emily.ross@pacific.edu",
    role: "teacher",
    departmentId: "dept-mth"
  },
  {
    id: "teacher-stern",
    name: "Prof. Albert Stern",
    email: "albert.stern@pacific.edu",
    role: "teacher",
    departmentId: "dept-phy"
  },
  {
    id: "teacher-vance",
    name: "Dr. Sarah Vance",
    email: "sarah.vance@pacific.edu",
    role: "teacher",
    departmentId: "dept-neu"
  },
  {
    id: "teacher-turing",
    name: "Prof. Alan Turing",
    email: "alan.turing@pacific.edu",
    role: "teacher",
    departmentId: "dept-cse"
  },

  // Advisors (Note: Dr. Emily Ross and Dr. Sarah Vance are both Teachers AND Advisors. We can represent them with Advisor accounts or dual profile. The spec mentions a distinct advisor role value)
  {
    id: "advisor-ross",
    name: "Dr. Emily Ross (HOD / Advisor)",
    email: "emily.ross@pacific.edu",
    role: "advisor",
    departmentId: "dept-mth"
  },
  {
    id: "advisor-vance",
    name: "Dr. Sarah Vance (Advisor)",
    email: "sarah.vance@pacific.edu",
    role: "advisor",
    departmentId: "dept-neu"
  },

  // Admin
  {
    id: "admin-1",
    name: "Administrator Console",
    email: "admin@pacific.edu",
    role: "admin"
  }
];

// 4. Initial Enrollments (Map our mock students to the subjects they are taking)
export const INITIAL_ENROLLMENTS: Enrollment[] = [
  // Austin Reaves
  { id: "enr-1", studentId: "student-1", subjectCode: "MTH-401", semester: 4 },
  { id: "enr-2", studentId: "student-1", subjectCode: "PHY-402L", semester: 4 },
  { id: "enr-3", studentId: "student-1", subjectCode: "NEU-405", semester: 4 },
  { id: "enr-4", studentId: "student-1", subjectCode: "CSE-409", semester: 4 },
  { id: "enr-5", studentId: "student-1", subjectCode: "SWE-412", semester: 4 },

  // Chloe Bennett
  { id: "enr-6", studentId: "student-2", subjectCode: "MTH-401", semester: 4 },
  { id: "enr-7", studentId: "student-2", subjectCode: "NEU-405", semester: 4 },
  { id: "enr-8", studentId: "student-2", subjectCode: "CSE-409", semester: 4 },
  { id: "enr-9", studentId: "student-2", subjectCode: "SWE-412", semester: 4 },

  // Marcus Vance
  { id: "enr-10", studentId: "student-3", subjectCode: "MTH-401", semester: 4 },
  { id: "enr-11", studentId: "student-3", subjectCode: "CSE-409", semester: 4 },
  { id: "enr-12", studentId: "student-3", subjectCode: "SWE-412", semester: 4 },

  // Seraphina Sterling
  { id: "enr-13", studentId: "student-4", subjectCode: "MTH-401", semester: 4 },
  { id: "enr-14", studentId: "student-4", subjectCode: "PHY-402L", semester: 4 },

  // Elena Rostova
  { id: "enr-15", studentId: "student-5", subjectCode: "MTH-401", semester: 4 },
  { id: "enr-16", studentId: "student-5", subjectCode: "NEU-405", semester: 4 }
];

// 5. Initial Timetable Slots
export const INITIAL_TIMETABLE: TimetableSlot[] = [
  {
    id: "slot-1",
    subjectCode: "MTH-401",
    subjectName: "Advanced Mathematics",
    dayOfWeek: "Monday",
    time: "09:00",
    period: "AM",
    duration: "1.5 hours",
    room: "Room 402-A",
    teacherId: "teacher-ross",
    teacherName: "Dr. Emily Ross",
    section: "Sec A"
  },
  {
    id: "slot-2",
    subjectCode: "PHY-402L",
    subjectName: "Quantum Physics Lab",
    dayOfWeek: "Tuesday",
    time: "11:00",
    period: "AM",
    duration: "2 hours",
    room: "Laser lab 3",
    teacherId: "teacher-stern",
    teacherName: "Prof. Albert Stern",
    section: "Sec A"
  },
  {
    id: "slot-3",
    subjectCode: "NEU-405",
    subjectName: "Cognitive Neuroscience",
    dayOfWeek: "Wednesday",
    time: "02:00",
    period: "PM",
    duration: "1.5 hours",
    room: "Seminar Room B",
    teacherId: "teacher-vance",
    teacherName: "Dr. Sarah Vance",
    section: "Sec A"
  },
  {
    id: "slot-4",
    subjectCode: "CSE-409",
    subjectName: "Data Structures & Algorithms",
    dayOfWeek: "Thursday",
    time: "04:00",
    period: "PM",
    duration: "1 hour",
    room: "Lecture Hall C",
    teacherId: "teacher-turing",
    teacherName: "Prof. Alan Turing",
    section: "Sec A"
  },
  {
    id: "slot-5",
    subjectCode: "SWE-412",
    subjectName: "Software Engineering",
    dayOfWeek: "Friday",
    time: "10:00",
    period: "AM",
    duration: "1.5 hours",
    room: "Room 101",
    teacherId: "teacher-turing",
    teacherName: "Prof. Alan Turing",
    section: "Sec B"
  }
];

// 6. Initial Attendance Records
export const INITIAL_ATTENDANCE: AttendanceRecord[] = [
  // Present for Austin Reaves
  { id: "att-1", studentId: "student-1", subjectCode: "MTH-401", date: "2026-06-29", status: "Present", recordedBy: "teacher-ross", recordedAt: "2026-06-29T09:30:00Z" },
  { id: "att-2", studentId: "student-1", subjectCode: "PHY-402L", date: "2026-06-30", status: "Present", recordedBy: "teacher-stern", recordedAt: "2026-06-30T11:15:00Z" },
  { id: "att-3", studentId: "student-1", subjectCode: "NEU-405", date: "2026-06-24", status: "Absent", recordedBy: "teacher-vance", recordedAt: "2026-06-24T14:05:00Z", disputed: true },
  
  // Chloe Bennett Attendance
  { id: "att-4", studentId: "student-2", subjectCode: "MTH-401", date: "2026-06-29", status: "Present", recordedBy: "teacher-ross", recordedAt: "2026-06-29T09:30:00Z" },
  { id: "att-5", studentId: "student-2", subjectCode: "NEU-405", date: "2026-06-24", status: "Present", recordedBy: "teacher-vance", recordedAt: "2026-06-24T14:05:00Z" },

  // Marcus Vance (Severe attendance shortage alert material)
  { id: "att-6", studentId: "student-3", subjectCode: "MTH-401", date: "2026-06-29", status: "Absent", recordedBy: "teacher-ross", recordedAt: "2026-06-29T09:35:00Z" },
  { id: "att-7", studentId: "student-3", subjectCode: "CSE-409", date: "2026-06-25", status: "Absent", recordedBy: "teacher-turing", recordedAt: "2026-06-25T16:10:00Z" },
  { id: "att-8", studentId: "student-3", subjectCode: "SWE-412", date: "2026-06-26", status: "Absent", recordedBy: "teacher-turing", recordedAt: "2026-06-26T10:15:00Z" }
];

// 7. Initial Assignment Submissions
export const INITIAL_SUBMISSIONS: AssignmentSubmission[] = [
  // For Austin Reaves
  { id: "subm-1", assignmentId: "assign-4", studentId: "student-1", studentName: "Austin Reaves", submittedAt: "2026-06-27T18:30:00Z", status: "Graded", fileUrl: "fMRI_report_reaves.pdf", score: 98, maxScore: 100, feedback: "Exceptional runtime performance. The dynamic programming cache is extremely clean.", gradedAt: "2026-06-28T10:00:00Z", gradedBy: "teacher-turing" },
  { id: "subm-2", assignmentId: "assign-5", studentId: "student-1", studentName: "Austin Reaves", submittedAt: "2026-06-24T22:15:00Z", status: "Graded", fileUrl: "microservices_reaves.pdf", score: 92, maxScore: 100, feedback: "Pristine domain boundaries. Adding a circuit breaker pattern is highly recommended next time.", gradedAt: "2026-06-25T15:00:00Z", gradedBy: "teacher-turing" },
  { id: "subm-3", assignmentId: "assign-6", studentId: "student-1", studentName: "Austin Reaves", submittedAt: "2026-06-19T14:00:00Z", status: "Completed", fileUrl: "algebra_vectors_reaves.pdf", maxScore: 100 },

  // For Chloe Bennett (Submitted but pending grade)
  { id: "subm-4", assignmentId: "assign-1", studentId: "student-2", studentName: "Chloe Bennett", submittedAt: "2026-06-30T10:00:00Z", status: "Submitted", fileUrl: "fourier_transform_chloe.pdf", maxScore: 100 },
  { id: "subm-5", assignmentId: "assign-4", studentId: "student-2", studentName: "Chloe Bennett", submittedAt: "2026-06-27T19:45:00Z", status: "Graded", fileUrl: "bst_chloe.pdf", score: 85, maxScore: 100, feedback: "Good effort, tree balancing works flawlessly.", gradedAt: "2026-06-28T11:00:00Z", gradedBy: "teacher-turing" },

  // For Marcus Vance (Overdue missing / pending submissions)
  { id: "subm-6", assignmentId: "assign-4", studentId: "student-3", studentName: "Marcus Vance", submittedAt: "2026-06-28T02:00:00Z", status: "Submitted", fileUrl: "bst_marcus_v.pdf", maxScore: 100 }
];

// 8. Initial Exams
export const INITIAL_EXAMS: Exam[] = [
  { id: "exam-1", subjectCode: "CSE-409", subjectName: "Data Structures & Algorithms", date: "2026-07-01", time: "09:00 AM", room: "Lecture Hall C", instructions: "No external materials or programmable calculators allowed.", hallTicketReady: true },
  { id: "exam-2", subjectCode: "MTH-401", subjectName: "Advanced Mathematics", date: "2026-07-05", time: "02:00 PM", room: "Room 402-A", instructions: "One handwritten cheat sheet (A4, double sided) permitted.", hallTicketReady: false },
  { id: "exam-3", subjectCode: "PHY-402L", subjectName: "Quantum Physics Lab Exam", date: "2026-07-07", time: "10:00 AM", room: "Laser lab 3", instructions: "Bring completed laboratory logbooks.", hallTicketReady: false }
];

// 9. Initial Exam Marks
export const INITIAL_EXAM_MARKS: ExamMark[] = [
  // Advanced Mathematics Mid-Term (Austin Reaves)
  { id: "mark-1", subjectCode: "MTH-401", studentId: "student-1", studentName: "Austin Reaves", examName: "Mid-Term Examination", score: 48, maxScore: 50, published: true },
  // Quantum Physics Lab Mid-Term
  { id: "mark-2", subjectCode: "PHY-402L", studentId: "student-1", studentName: "Austin Reaves", examName: "Mid-Term Examination", score: 45, maxScore: 50, published: true },
  // Cognitive Neuroscience Mid-Term
  { id: "mark-3", subjectCode: "NEU-405", studentId: "student-1", studentName: "Austin Reaves", examName: "Mid-Term Examination", score: 38, maxScore: 50, published: true },

  // Chloe Bennett
  { id: "mark-4", subjectCode: "MTH-401", studentId: "student-2", studentName: "Chloe Bennett", examName: "Mid-Term Examination", score: 42, maxScore: 50, published: true },
  { id: "mark-5", subjectCode: "NEU-405", studentId: "student-2", studentName: "Chloe Bennett", examName: "Mid-Term Examination", score: 46, maxScore: 50, published: true },

  // Marcus Vance (Low/Borderline grades)
  { id: "mark-6", subjectCode: "MTH-401", studentId: "student-3", studentName: "Marcus Vance", examName: "Mid-Term Examination", score: 18, maxScore: 50, published: true },
  { id: "mark-7", subjectCode: "CSE-409", studentId: "student-3", studentName: "Marcus Vance", examName: "Mid-Term Examination", score: 20, maxScore: 50, published: false } // Draft
];

// 10. Initial Advisor Notes
export const INITIAL_ADVISOR_NOTES: AdvisorNote[] = [
  {
    id: "note-1",
    studentId: "student-3",
    advisorId: "advisor-ross",
    advisorName: "Dr. Emily Ross",
    note: "Marcus is struggling with advanced calculus concepts. Recommended 2 hours of peer tutoring per week.",
    createdAt: "2026-06-25T14:30:00Z"
  },
  {
    id: "note-2",
    studentId: "student-3",
    advisorId: "advisor-ross",
    advisorName: "Dr. Emily Ross",
    note: "Meeting conducted. Marcus cited health difficulties for missing classes. Need medical certificate.",
    createdAt: "2026-06-28T16:00:00Z"
  }
];

// 11. Initial Audit Logs
export const INITIAL_AUDIT_LOGS: AuditLog[] = [
  {
    id: "log-1",
    actorName: "System Administrator",
    actorEmail: "admin@pacific.edu",
    action: "Seeded database tables for 2026 semester",
    entity: "Initial Seed",
    entityType: "System Setup",
    timestamp: "2026-06-20T08:00:00Z"
  },
  {
    id: "log-2",
    actorName: "Dr. Emily Ross",
    actorEmail: "emily.ross@pacific.edu",
    action: "Recorded Attendance for Advanced Mathematics",
    entity: "MTH-401 - June 29",
    entityType: "Attendance",
    timestamp: "2026-06-29T09:40:00Z"
  },
  {
    id: "log-3",
    actorName: "Prof. Alan Turing",
    actorEmail: "alan.turing@pacific.edu",
    action: "Published grades for Optimal BST Implementation",
    entity: "assign-4",
    entityType: "Grading",
    timestamp: "2026-06-28T11:05:00Z"
  }
];
