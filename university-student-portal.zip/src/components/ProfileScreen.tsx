import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  User, 
  Settings, 
  QrCode, 
  Award, 
  Mail, 
  Phone, 
  MapPin, 
  ShieldCheck, 
  Sun, 
  Moon, 
  Bell, 
  Fingerprint, 
  LogOut,
  Sparkles,
  CreditCard,
  UserCheck
} from "lucide-react";

interface ProfileScreenProps {
  isDark: boolean;
  onToggleTheme: () => void;
}

export default function ProfileScreen({ isDark, onToggleTheme }: ProfileScreenProps) {
  const [isFlipped, setIsFlipped] = useState(false);
  
  // App Toggles state
  const [emailNotif, setEmailNotif] = useState(true);
  const [biometric, setBiometric] = useState(false);
  const [examAlerts, setExamAlerts] = useState(true);

  // Edit Personal Details state
  const [bloodGroup, setBloodGroup] = useState("O+");
  const [phone, setPhone] = useState("+1 (555) 381-0421");
  const [address, setAddress] = useState("San Francisco, CA, USA");
  const [editSuccess, setEditSuccess] = useState(false);

  const handleSaveDetails = (e: React.FormEvent) => {
    e.preventDefault();
    setEditSuccess(true);
    setTimeout(() => setEditSuccess(false), 2500);
  };

  const achievements = [
    { name: "Dean's Merit List", desc: "Maintained a GPA of 3.80+ in Semester 3", icon: "🏆", color: "bg-amber-500/10 text-amber-500" },
    { name: "Hacker's Choice", desc: "1st Place in Inter-College Autumn Hackathon", icon: "💻", color: "bg-indigo-500/10 text-indigo-500" },
    { name: "Perfect Fortnight", desc: "100% attendance rate for consecutive classes", icon: "⚡", color: "bg-emerald-500/10 text-emerald-500" },
    { name: "Aura Explorer", desc: "Ran 50+ academic inquiries with AI Counselor", icon: "🤖", color: "bg-indigo-500/10 text-brand-primary" }
  ];

  return (
    <div className="space-y-8 pb-10" id="profile-root">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold font-sans text-brand-on-surface dark:text-gray-100 flex items-center gap-2">
          <User size={24} className="text-brand-primary dark:text-indigo-400" />
          Student Account &amp; Settings
        </h1>
        <p className="text-xs text-brand-on-variant dark:text-gray-400 mt-1">Manage interactive university identification credentials, customize layout themes, and verify security protocols.</p>
      </div>

      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left Column: Flip ID Card and Achievements */}
        <div className="space-y-8">
          <div className="space-y-3">
            <h3 className="text-xs font-mono font-bold uppercase tracking-wider text-brand-on-variant dark:text-gray-400">
              Interactive 3D Student ID
            </h3>
            <p className="text-[11px] text-brand-on-variant dark:text-gray-400">Click card below to rotate and scan secure QR/Barcode clearances.</p>
          </div>

          {/* FLIP CARD STRUCTURE */}
          <div 
            className={`flip-card w-full h-[230px] cursor-pointer ${isFlipped ? "flipped" : ""}`}
            onClick={() => setIsFlipped(!isFlipped)}
            id="flip-id-card"
          >
            <div className="flip-card-inner w-full h-full">
              {/* Card Front face */}
              <div className="flip-card-front rounded-2xl p-5 neu-flat bg-gradient-to-br from-brand-surface to-indigo-50/20 dark:from-brand-dark-surface dark:to-indigo-950/20 text-brand-on-surface dark:text-gray-100 border border-indigo-100/10 flex flex-col justify-between overflow-hidden relative shadow-lg">
                {/* Decorative holographic chip and seal */}
                <div className="absolute top-0 right-0 w-32 h-32 bg-brand-primary/5 rounded-full -mr-10 -mt-10" />
                <div className="absolute bottom-6 right-6 w-12 h-12 rounded-full border-2 border-dashed border-indigo-300/30 flex items-center justify-center">
                  <span className="text-[8px] font-mono font-bold text-indigo-400/50 uppercase tracking-widest leading-none">SEAL</span>
                </div>

                <div className="flex justify-between items-start">
                  <div>
                    <h2 className="text-xs font-bold font-serif tracking-widest text-brand-primary dark:text-indigo-400">PACIFIC UNIVERSITY</h2>
                    <p className="text-[8px] font-mono text-gray-400">STATE DIGITAL REGISTRAR</p>
                  </div>
                  <span className="text-[8px] font-mono bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 px-2 py-0.5 rounded-full uppercase tracking-widest font-extrabold">
                    ACTIVE
                  </span>
                </div>

                <div className="flex gap-4 items-center mt-3">
                  <img 
                    src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=150&auto=format&fit=crop" 
                    alt="Austin Reaves" 
                    className="w-16 h-16 rounded-xl object-cover shadow-inner border border-white dark:border-slate-800 p-0.5 bg-brand-surface dark:bg-brand-dark-surface flex-shrink-0"
                    referrerPolicy="no-referrer"
                  />
                  <div className="min-w-0">
                    <h3 className="text-sm font-bold font-serif italic text-base text-brand-on-surface dark:text-gray-100 truncate leading-tight">Austin Reaves</h3>
                    <p className="text-[10px] text-brand-on-variant dark:text-gray-400 truncate mt-0.5 font-medium">B.Tech Computer Science &amp; Eng.</p>
                    <p className="text-[10px] text-brand-primary dark:text-indigo-400 font-mono font-semibold mt-1">ID: CSE-2024-048</p>
                  </div>
                </div>

                <div className="flex justify-between items-end border-t border-indigo-100/10 pt-2 text-[9px] font-mono text-brand-on-variant dark:text-gray-400 mt-2">
                  <div>
                    <span className="block text-[8px] text-gray-400 font-sans">YEAR</span>
                    <span className="font-bold">2024 - 2028</span>
                  </div>
                  <div className="text-right">
                    <span className="block text-[8px] text-gray-400 font-sans">ISSUED</span>
                    <span className="font-bold">SEPT 2024</span>
                  </div>
                </div>
              </div>

              {/* Card Back face */}
              <div className="flip-card-back rounded-2xl p-5 neu-flat bg-brand-surface dark:bg-brand-dark-surface text-brand-on-surface dark:text-gray-100 border border-indigo-100/10 flex flex-col justify-between overflow-hidden relative shadow-lg">
                <div className="absolute top-2 right-4 text-gray-400 flex items-center gap-1 font-mono text-[8px]">
                  <ShieldCheck size={10} className="text-emerald-500" /> SECURE SECRETS
                </div>

                <div className="space-y-1">
                  <h4 className="text-[9px] font-mono font-bold text-gray-400">SCAN CARD FOR CLASS ATTENDANCE</h4>
                  <div className="w-full h-1 bg-gray-300 dark:bg-gray-800 rounded mt-1.5" />
                </div>

                {/* Simulated Barcode / QR Section */}
                <div className="flex items-center justify-between gap-4 py-3">
                  {/* Mock Barcode lines */}
                  <div className="flex-1 h-12 flex items-center gap-[2px] bg-white dark:bg-slate-900 p-2 rounded-lg border border-brand-container dark:border-slate-800">
                    {Array.from({ length: 28 }).map((_, i) => (
                      <div 
                        key={i} 
                        className="h-full bg-brand-on-surface dark:bg-gray-200" 
                        style={{ width: i % 3 === 0 ? "3px" : i % 5 === 0 ? "1px" : "2px" }} 
                      />
                    ))}
                  </div>

                  <div className="w-12 h-12 p-1 bg-white rounded-lg border border-brand-container flex items-center justify-center flex-shrink-0">
                    <QrCode className="text-black" size={32} />
                  </div>
                </div>

                <div className="text-[8px] font-mono text-brand-on-variant dark:text-gray-400 leading-normal text-left">
                  This card is the property of Pacific University. Scanner systems logs verify credential authorization upon entry gates scans.
                </div>
              </div>
            </div>
          </div>

          {/* Badge shelf achievements */}
          <div className="p-6 rounded-2xl neu-flat space-y-4">
            <h3 className="font-bold text-brand-on-surface dark:text-gray-100 flex items-center gap-2 text-md">
              <Award className="text-brand-primary dark:text-indigo-400" size={18} />
              Achievements &amp; Badges
            </h3>

            <div className="grid grid-cols-1 gap-3.5">
              {achievements.map((ach) => (
                <div key={ach.name} className="p-3 rounded-xl neu-inset flex items-center gap-3">
                  <span className={`w-9 h-9 rounded-xl flex items-center justify-center text-lg ${ach.color} neu-flat flex-shrink-0`}>
                    {ach.icon}
                  </span>
                  <div className="min-w-0">
                    <h4 className="text-xs font-bold text-brand-on-surface dark:text-gray-100 truncate">{ach.name}</h4>
                    <p className="text-[10px] text-brand-on-variant dark:text-gray-400 mt-0.5 leading-snug">{ach.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right Column: Profile Edits & Settings panel */}
        <div className="lg:col-span-2 space-y-8">
          {/* Edit personal info cards */}
          <div className="p-6 rounded-2xl neu-flat space-y-5">
            <h3 className="font-bold text-brand-on-surface dark:text-gray-100 flex items-center gap-2 text-md">
              <UserCheck size={18} className="text-brand-primary dark:text-indigo-400" />
              Personal Ledger Info
            </h3>

            <AnimatePresence>
              {editSuccess && (
                <motion.div
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0 }}
                  className="p-3.5 bg-emerald-500/10 border border-emerald-500/20 rounded-xl text-emerald-600 dark:text-emerald-400 text-xs font-bold text-center"
                >
                  ✓ Ledger particulars saved successfully in system registers.
                </motion.div>
              )}
            </AnimatePresence>

            <form onSubmit={handleSaveDetails} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-[10px] font-mono font-bold uppercase text-brand-on-variant dark:text-gray-400">Mobile Dial Number</label>
                  <input 
                    type="text" 
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full text-xs p-2.5 rounded-xl neu-inset bg-brand-surface dark:bg-brand-dark-surface dark:text-gray-100 focus:outline-none"
                    required
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] font-mono font-bold uppercase text-brand-on-variant dark:text-gray-400">Emergency Blood group</label>
                  <input 
                    type="text" 
                    value={bloodGroup}
                    onChange={(e) => setBloodGroup(e.target.value)}
                    className="w-full text-xs p-2.5 rounded-xl neu-inset bg-brand-surface dark:bg-brand-dark-surface dark:text-gray-100 focus:outline-none"
                    required
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-mono font-bold uppercase text-brand-on-variant dark:text-gray-400">Postal Address Location</label>
                <input 
                  type="text" 
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  className="w-full text-xs p-2.5 rounded-xl neu-inset bg-brand-surface dark:bg-brand-dark-surface dark:text-gray-100 focus:outline-none"
                  required
                />
              </div>

              <button
                type="submit"
                className="py-2.5 px-5 bg-brand-primary hover:bg-brand-primary-container text-white text-xs font-bold rounded-xl transition-all shadow-md cursor-pointer"
              >
                Save Details
              </button>
            </form>
          </div>

          {/* App Settings toggles */}
          <div className="p-6 rounded-2xl neu-flat space-y-5">
            <h3 className="font-bold text-brand-on-surface dark:text-gray-100 flex items-center gap-2 text-md">
              <Settings size={18} className="text-brand-primary dark:text-indigo-400" />
              Applet Preference Config
            </h3>

            <div className="space-y-4">
              {/* Dark mode trigger toggle */}
              <div className="flex items-center justify-between p-4 rounded-xl neu-inset bg-brand-surface/50 dark:bg-brand-dark-low">
                <div className="flex items-center gap-3">
                  <span className="w-8 h-8 rounded-lg flex items-center justify-center bg-indigo-500/10 text-brand-primary dark:text-indigo-400">
                    {isDark ? <Moon size={16} /> : <Sun size={16} />}
                  </span>
                  <div>
                    <h4 className="text-xs font-bold text-brand-on-surface dark:text-gray-100">Display Theme</h4>
                    <p className="text-[10px] text-brand-on-variant dark:text-gray-400 mt-0.5">Toggle high contrast dark neumorphic shadows.</p>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={onToggleTheme}
                  className={`w-12 h-6 rounded-full p-1 transition-all ${isDark ? "bg-indigo-600" : "bg-gray-300"}`}
                >
                  <div className={`w-4 h-4 bg-white rounded-full shadow transition-all transform ${isDark ? "translate-x-6" : ""}`} />
                </button>
              </div>

              {/* Email Notifications toggle */}
              <div className="flex items-center justify-between p-4 rounded-xl neu-inset bg-brand-surface/50 dark:bg-brand-dark-low">
                <div className="flex items-center gap-3">
                  <span className="w-8 h-8 rounded-lg flex items-center justify-center bg-indigo-500/10 text-brand-primary dark:text-indigo-400">
                    <Bell size={16} />
                  </span>
                  <div>
                    <h4 className="text-xs font-bold text-brand-on-surface dark:text-gray-100">Email Alerts</h4>
                    <p className="text-[10px] text-brand-on-variant dark:text-gray-400 mt-0.5">Dispatched alerts for final semester grades slips.</p>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => setEmailNotif(!emailNotif)}
                  className={`w-12 h-6 rounded-full p-1 transition-all ${emailNotif ? "bg-indigo-600" : "bg-gray-300"}`}
                >
                  <div className={`w-4 h-4 bg-white rounded-full shadow transition-all transform ${emailNotif ? "translate-x-6" : ""}`} />
                </button>
              </div>

              {/* Biometrics biometric toggle */}
              <div className="flex items-center justify-between p-4 rounded-xl neu-inset bg-brand-surface/50 dark:bg-brand-dark-low">
                <div className="flex items-center gap-3">
                  <span className="w-8 h-8 rounded-lg flex items-center justify-center bg-indigo-500/10 text-brand-primary dark:text-indigo-400">
                    <Fingerprint size={16} />
                  </span>
                  <div>
                    <h4 className="text-xs font-bold text-brand-on-surface dark:text-gray-100">Biometric Clearance</h4>
                    <p className="text-[10px] text-brand-on-variant dark:text-gray-400 mt-0.5">Scan finger for mobile logins bypass.</p>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => setBiometric(!biometric)}
                  className={`w-12 h-6 rounded-full p-1 transition-all ${biometric ? "bg-indigo-600" : "bg-gray-300"}`}
                >
                  <div className={`w-4 h-4 bg-white rounded-full shadow transition-all transform ${biometric ? "translate-x-6" : ""}`} />
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
