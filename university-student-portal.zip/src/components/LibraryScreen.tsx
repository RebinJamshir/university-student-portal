import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  BookOpen, 
  Clock, 
  ArrowRight, 
  Download, 
  Search, 
  DollarSign, 
  CheckCircle, 
  CreditCard, 
  Lock, 
  ExternalLink,
  ChevronRight
} from "lucide-react";
import { Book, DigitalAsset } from "../types";
import { BORROWED_BOOKS, DIGITAL_ASSETS } from "../data";

export default function LibraryScreen() {
  const [books, setBooks] = useState<Book[]>(BORROWED_BOOKS);
  const [digitalFiles, setDigitalFiles] = useState<DigitalAsset[]>(DIGITAL_ASSETS);
  const [libraryFine, setLibraryFine] = useState(4.50);
  
  // Checkout Modal State
  const [payModalOpen, setPayModalOpen] = useState(false);
  const [cardNumber, setCardNumber] = useState("");
  const [cardExpiry, setCardExpiry] = useState("");
  const [cardCvv, setCardCvv] = useState("");
  const [isProcessingPayment, setIsProcessingPayment] = useState(false);
  const [paymentDone, setPaymentDone] = useState(false);

  // Download simulation states
  const [downloadingId, setDownloadingId] = useState<string | null>(null);

  const handleRenewBook = (id: string) => {
    setBooks(prevBooks => 
      prevBooks.map(b => 
        b.id === id 
          ? { ...b, dueDate: "Extended 14 Days", daysLeft: b.daysLeft + 14, renewed: true } 
          : b
      )
    );
  };

  const handleDownloadFile = (id: string) => {
    setDownloadingId(id);
    setTimeout(() => {
      setDownloadingId(null);
      // Trigger a mock file download in browser
      const blob = new Blob(["Academic handout content compiled by Aura."], { type: "text/plain" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `Handout-${id}.pdf`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
    }, 1500);
  };

  const handleCheckoutSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!cardNumber || !cardExpiry || !cardCvv) return;

    setIsProcessingPayment(true);
    setTimeout(() => {
      setIsProcessingPayment(false);
      setPaymentDone(true);
      setLibraryFine(0);
      setTimeout(() => {
        setPayModalOpen(false);
        setPaymentDone(false);
        setCardNumber("");
        setCardExpiry("");
        setCardCvv("");
      }, 2000);
    }, 1800);
  };

  return (
    <div className="space-y-8 pb-10" id="library-root">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold font-sans text-brand-on-surface dark:text-gray-100 flex items-center gap-2">
            <BookOpen size={24} className="text-brand-primary dark:text-indigo-400" />
            Library &amp; Digital Repositories
          </h1>
          <p className="text-xs text-brand-on-variant dark:text-gray-400 mt-1">Renew borrowed physical textbooks, download exam handouts, and clear outstanding late fines.</p>
        </div>

        {/* Late Fee Indicator Panel */}
        <div className="p-4 rounded-xl neu-flat flex items-center gap-4 border border-rose-100/10 w-full sm:w-auto">
          <div>
            <span className="text-[9px] font-mono font-bold text-brand-on-variant dark:text-gray-400 uppercase">Outstanding Fine</span>
            <div className="text-lg font-extrabold text-rose-500 mt-0.5">${libraryFine.toFixed(2)}</div>
          </div>
          {libraryFine > 0 ? (
            <button 
              onClick={() => setPayModalOpen(true)}
              className="text-xs px-3.5 py-2 rounded-lg bg-rose-500 hover:bg-rose-600 text-white font-bold transition-all shadow-md cursor-pointer"
            >
              Pay Now
            </button>
          ) : (
            <div className="text-xs font-bold text-emerald-600 dark:text-emerald-400 flex items-center gap-1">
              <CheckCircle size={14} /> Clear Status
            </div>
          )}
        </div>
      </div>

      {/* Main Grid split */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left column physical borrow status */}
        <div className="lg:col-span-2 space-y-6">
          <h2 className="text-md font-bold text-brand-on-surface dark:text-gray-100 flex items-center gap-2">
            <Clock size={16} className="text-brand-primary dark:text-indigo-400" />
            Active Textbooks Borrowed
          </h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            {books.map((book) => (
              <div key={book.id} className="p-5 rounded-2xl neu-flat flex gap-4 transition-all hover:scale-[1.01]">
                <img 
                  src={book.coverUrl} 
                  alt={book.title} 
                  className="w-16 h-22 rounded-lg object-cover shadow-sm neu-inset p-0.5"
                  referrerPolicy="no-referrer"
                />

                <div className="flex flex-col justify-between py-1 min-w-0 flex-1">
                  <div>
                    <h3 className="text-xs font-bold text-brand-on-surface dark:text-gray-100 leading-snug truncate">{book.title}</h3>
                    <p className="text-[10px] text-brand-on-variant dark:text-gray-400 mt-0.5 truncate">by {book.author}</p>
                  </div>

                  <div className="mt-2">
                    <div className="text-[9px] font-mono text-brand-on-variant dark:text-gray-400">
                      Due: <span className={book.daysLeft <= 1 ? "text-rose-500 font-bold" : "font-semibold"}>{book.dueDate}</span>
                    </div>

                    {book.renewed ? (
                      <span className="text-[9px] font-mono font-bold text-emerald-600 dark:text-emerald-400 block mt-2">
                        ✓ Renewed Once
                      </span>
                    ) : (
                      <button 
                        onClick={() => handleRenewBook(book.id)}
                        className="text-[9px] font-bold px-2.5 py-1 rounded bg-brand-primary/10 hover:bg-brand-primary text-brand-primary hover:text-white dark:text-indigo-400 transition-all font-sans cursor-pointer mt-2"
                      >
                        Renew Hand-out
                      </button>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right column Digital Assets Download */}
        <div className="space-y-6">
          <h2 className="text-md font-bold text-brand-on-surface dark:text-gray-100 flex items-center gap-2">
            <Download size={16} className="text-brand-primary dark:text-indigo-400" />
            Digital Handout Repository
          </h2>

          <div className="p-5 rounded-2xl neu-flat space-y-4">
            <div className="space-y-3.5">
              {digitalFiles.map((file) => (
                <div key={file.id} className="p-3.5 rounded-xl neu-inset flex items-center justify-between gap-3">
                  <div className="min-w-0">
                    <div className="text-xs font-bold text-brand-on-surface dark:text-gray-100 truncate">{file.name}</div>
                    <div className="text-[10px] text-brand-on-variant dark:text-gray-400 mt-0.5 font-mono">
                      {file.size} • Uploaded {file.date}
                    </div>
                  </div>

                  <button
                    onClick={() => handleDownloadFile(file.id)}
                    disabled={downloadingId === file.id}
                    className="w-8 h-8 rounded-full flex items-center justify-center neu-button hover:bg-indigo-50 text-brand-primary dark:text-indigo-400 cursor-pointer flex-shrink-0"
                  >
                    {downloadingId === file.id ? (
                      <span className="w-4 h-4 border-2 border-brand-primary border-t-transparent rounded-full animate-spin" />
                    ) : (
                      <Download size={14} />
                    )}
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* READING HISTORY SUMMARY */}
      <div className="p-6 rounded-2xl neu-flat space-y-4">
        <h3 className="font-bold text-brand-on-surface dark:text-gray-100 text-sm">Past Textbook Returns Log</h3>
        <div className="space-y-3">
          <div className="flex items-center justify-between text-xs p-3 rounded-xl neu-inset">
            <div className="flex items-center gap-3">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
              <span className="font-semibold text-brand-on-surface dark:text-gray-100">Electromagnetic Field Lines</span>
            </div>
            <span className="text-[10px] font-mono text-gray-400">Returned June 12, 2026</span>
          </div>
          <div className="flex items-center justify-between text-xs p-3 rounded-xl neu-inset">
            <div className="flex items-center gap-3">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
              <span className="font-semibold text-brand-on-surface dark:text-gray-100">Advanced Discrete Mathematical Logic</span>
            </div>
            <span className="text-[10px] font-mono text-gray-400">Returned June 05, 2026</span>
          </div>
        </div>
      </div>

      {/* 4. Secure Payment Checkout Modal */}
      <AnimatePresence>
        {payModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-xs">
            <motion.div 
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="w-full max-w-md rounded-2xl p-6 neu-flat bg-brand-surface dark:bg-brand-dark-surface space-y-6 relative border border-white/10 shadow-2xl"
              id="payment-modal"
            >
              {/* Header */}
              <div className="flex items-center justify-between pb-3 border-b border-brand-container dark:border-slate-800">
                <div className="flex items-center gap-2">
                  <Lock className="text-emerald-500" size={16} />
                  <h3 className="font-bold text-brand-on-surface dark:text-gray-100 text-base">Secure Gateway Checkout</h3>
                </div>
                <button 
                  onClick={() => setPayModalOpen(false)}
                  className="w-7 h-7 rounded-full flex items-center justify-center neu-button hover:bg-rose-50 text-rose-600 font-bold cursor-pointer"
                >
                  &times;
                </button>
              </div>

              {paymentDone ? (
                <div className="py-6 text-center space-y-3 text-emerald-600 dark:text-emerald-400">
                  <CheckCircle size={40} className="mx-auto" />
                  <div className="text-md font-bold">Late Fine Cleared!</div>
                  <p className="text-xs">Your library fine has been successfully paid and your library standing is fully restored.</p>
                </div>
              ) : (
                <form onSubmit={handleCheckoutSubmit} className="space-y-4">
                  <div className="p-3 rounded-xl neu-inset text-center bg-indigo-50/20 dark:bg-slate-900/45">
                    <span className="text-[10px] font-mono text-brand-on-variant dark:text-gray-400 uppercase">Settlement Fine Amount</span>
                    <div className="text-xl font-extrabold text-rose-500">${libraryFine.toFixed(2)}</div>
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-mono font-bold uppercase text-brand-on-variant dark:text-gray-400">Card Number</label>
                    <div className="relative">
                      <CreditCard className="absolute left-3.5 top-3.5 text-gray-400" size={16} />
                      <input 
                        type="text" 
                        value={cardNumber}
                        onChange={(e) => setCardNumber(e.target.value)}
                        placeholder="4111 2222 3333 4444" 
                        maxLength={19}
                        className="w-full text-xs py-3 pl-10 pr-3.5 rounded-xl neu-inset bg-brand-surface dark:bg-brand-dark-surface dark:text-gray-100 focus:outline-none font-mono"
                        required
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <label className="text-[10px] font-mono font-bold uppercase text-brand-on-variant dark:text-gray-400 font-sans">Expiry</label>
                      <input 
                        type="text" 
                        value={cardExpiry}
                        onChange={(e) => setCardExpiry(e.target.value)}
                        placeholder="MM/YY" 
                        maxLength={5}
                        className="w-full text-xs p-3 rounded-xl neu-inset bg-brand-surface dark:bg-brand-dark-surface dark:text-gray-100 focus:outline-none text-center font-mono"
                        required
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[10px] font-mono font-bold uppercase text-brand-on-variant dark:text-gray-400 font-sans">CVV</label>
                      <input 
                        type="password" 
                        value={cardCvv}
                        onChange={(e) => setCardCvv(e.target.value)}
                        placeholder="•••" 
                        maxLength={3}
                        className="w-full text-xs p-3 rounded-xl neu-inset bg-brand-surface dark:bg-brand-dark-surface dark:text-gray-100 focus:outline-none text-center font-mono"
                        required
                      />
                    </div>
                  </div>

                  <button
                    type="submit"
                    disabled={isProcessingPayment}
                    className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-80 text-white rounded-xl text-xs font-bold transition-all shadow-md flex items-center justify-center gap-2 cursor-pointer"
                  >
                    {isProcessingPayment ? (
                      <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    ) : (
                      <>
                        <Lock size={13} /> Authorize Late Fine Payment
                      </>
                    )}
                  </button>
                </form>
              )}
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
