import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Bell, 
  Trash2, 
  Check, 
  AlertCircle, 
  BookOpen, 
  DollarSign, 
  Briefcase, 
  Clock,
  Sparkles
} from "lucide-react";
import { Notification } from "../types";
import { INITIAL_NOTIFICATIONS } from "../data";

interface NotificationsScreenProps {
  notifications: Notification[];
  onUpdateNotifications: (list: Notification[]) => void;
}

export default function NotificationsScreen({ notifications, onUpdateNotifications }: NotificationsScreenProps) {
  
  const handleMarkAsRead = (id: string) => {
    onUpdateNotifications(
      notifications.map(n => n.id === id ? { ...n, read: true } : n)
    );
  };

  const handleDelete = (id: string) => {
    onUpdateNotifications(
      notifications.filter(n => n.id !== id)
    );
  };

  const handleMarkAllRead = () => {
    onUpdateNotifications(
      notifications.map(n => ({ ...n, read: true }))
    );
  };

  const handleClearAll = () => {
    onUpdateNotifications([]);
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case "Academic": return <BookOpen size={16} className="text-indigo-600 dark:text-indigo-400" />;
      case "Exam": return <AlertCircle size={16} className="text-rose-500" />;
      case "Fee": return <DollarSign size={16} className="text-amber-500" />;
      case "Placement": return <Briefcase size={16} className="text-emerald-500" />;
      default: return <Bell size={16} />;
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case "Academic": return "bg-indigo-500/10 text-indigo-600 dark:text-indigo-400";
      case "Exam": return "bg-rose-500/10 text-rose-500";
      case "Fee": return "bg-amber-500/10 text-amber-500";
      case "Placement": return "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400";
      default: return "bg-gray-500/10 text-gray-500";
    }
  };

  const unreadCount = notifications.filter(n => !n.read).length;

  return (
    <div className="space-y-8 pb-10" id="notifications-root">
      {/* Header and top tool actions */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold font-sans text-brand-on-surface dark:text-gray-100 flex items-center gap-2">
            <Bell size={24} className="text-brand-primary dark:text-indigo-400" />
            University Notifications Center
          </h1>
          <p className="text-xs text-brand-on-variant dark:text-gray-400 mt-1">Manage urgent class announcements, financial holds, exam slips, and career shortlists.</p>
        </div>

        {notifications.length > 0 && (
          <div className="flex items-center gap-3">
            <button
              onClick={handleMarkAllRead}
              className="text-xs font-semibold px-3 py-2 rounded-lg neu-flat hover:neu-inset text-indigo-600 dark:text-indigo-400 flex items-center gap-1 cursor-pointer"
            >
              <Check size={13} /> Mark All Read
            </button>
            <button
              onClick={handleClearAll}
              className="text-xs font-semibold px-3 py-2 rounded-lg neu-flat hover:neu-inset text-rose-600 dark:text-rose-400 flex items-center gap-1 cursor-pointer"
            >
              <Trash2 size={13} /> Clear Inbox
            </button>
          </div>
        )}
      </div>

      {/* Main Container */}
      <div className="p-6 rounded-2xl neu-flat space-y-6">
        {/* Unread tab tracker */}
        <div className="flex items-center justify-between border-b border-brand-container dark:border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-brand-on-surface dark:text-gray-100">All Notices</span>
            {unreadCount > 0 && (
              <span className="text-[10px] font-mono bg-rose-500 text-white font-extrabold px-2 py-0.5 rounded-full uppercase tracking-wider">
                {unreadCount} Urgent New
              </span>
            )}
          </div>
        </div>

        {/* List mapping */}
        <div className="space-y-4">
          <AnimatePresence initial={false}>
            {notifications.map((notif) => (
              <motion.div
                key={notif.id}
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: "auto" }}
                exit={{ opacity: 0, height: 0 }}
                className={`p-4 rounded-xl flex items-start gap-4 transition-all relative ${
                  notif.read 
                    ? "neu-inset opacity-80" 
                    : "neu-flat border-l-4 border-brand-primary bg-indigo-50/15 dark:bg-slate-900/40"
                }`}
              >
                {/* Category Icon */}
                <div className={`w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0 ${getCategoryColor(notif.category)} neu-inset`}>
                  {getCategoryIcon(notif.category)}
                </div>

                {/* Message body */}
                <div className="flex-1 min-w-0 pr-12">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-xs font-bold text-brand-on-surface dark:text-gray-100">{notif.title}</span>
                    <span className={`text-[9px] font-mono font-bold px-1.5 py-0.5 rounded uppercase ${getCategoryColor(notif.category)}`}>
                      {notif.category}
                    </span>
                  </div>
                  <p className="text-xs text-brand-on-variant dark:text-gray-300 mt-1 leading-relaxed">
                    {notif.description}
                  </p>
                  <div className="flex items-center gap-1.5 text-[10px] text-gray-400 mt-2 font-mono">
                    <Clock size={12} />
                    <span>{notif.time}</span>
                  </div>
                </div>

                {/* Hover control actions absolute to the right edge */}
                <div className="absolute right-4 top-4 flex items-center gap-1.5">
                  {!notif.read && (
                    <button
                      onClick={() => handleMarkAsRead(notif.id)}
                      title="Mark as Read"
                      className="w-7 h-7 rounded-full flex items-center justify-center neu-button hover:bg-emerald-50 text-emerald-600 dark:text-emerald-400 cursor-pointer"
                    >
                      <Check size={12} />
                    </button>
                  )}
                  <button
                    onClick={() => handleDelete(notif.id)}
                    title="Delete Notice"
                    className="w-7 h-7 rounded-full flex items-center justify-center neu-button hover:bg-rose-50 text-rose-500 cursor-pointer"
                  >
                    <Trash2 size={12} />
                  </button>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>

          {/* Empty Notices State */}
          {notifications.length === 0 && (
            <div className="py-12 text-center space-y-3">
              <div className="w-16 h-16 rounded-full bg-brand-container dark:bg-brand-dark-container mx-auto flex items-center justify-center text-gray-400 neu-inset">
                <Bell size={24} />
              </div>
              <div>
                <h4 className="font-bold text-brand-on-surface dark:text-gray-100 text-sm">Inbox Fully Cleared!</h4>
                <p className="text-xs text-brand-on-variant dark:text-gray-400 leading-relaxed max-w-xs mx-auto mt-1">
                  You have cleared your active notifications drawer. Check back later for administrative updates or grades slips.
                </p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
