import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Building2, 
  BookOpen, 
  Users, 
  Calendar, 
  Activity, 
  Plus, 
  AlertTriangle, 
  Search, 
  UserCheck, 
  GraduationCap, 
  ShieldCheck, 
  Trash2, 
  ChevronRight, 
  Briefcase, 
  X,
  FileSpreadsheet,
  Check
} from "lucide-react";
import { 
  Profile, 
  Subject, 
  Department, 
  Enrollment, 
  AttendanceRecord, 
  Assignment, 
  AssignmentSubmission, 
  Exam, 
  ExamMark, 
  TimetableSlot, 
  AdvisorNote, 
  AuditLog 
} from "../types";

interface AdminDashboardProps {
  currentAdmin: Profile;
  profiles: Profile[];
  onAddProfile: (profile: Profile) => void;
  departments: Department[];
  onAddDepartment: (dept: Department) => void;
  subjects: Subject[];
  onAddSubject: (subj: Subject) => void;
  enrollments: Enrollment[];
  onAddEnrollment: (enr: Enrollment) => void;
  timetable: TimetableSlot[];
  onAddTimetableSlot: (slot: TimetableSlot) => void;
  auditLogs: AuditLog[];
  onAddAuditLog: (action: string, entity: string, entityType: string, metadata?: string) => void;
}

export default function AdminDashboard({
  currentAdmin,
  profiles,
  onAddProfile,
  departments,
  onAddDepartment,
  subjects,
  onAddSubject,
  enrollments,
  onAddEnrollment,
  timetable,
  onAddTimetableSlot,
  auditLogs,
  onAddAuditLog
}: AdminDashboardProps) {
  const [activeSubTab, setActiveSubTab] = useState<string>("Overview");

  // Form states
  const [deptName, setDeptName] = useState("");
  const [deptCode, setDeptCode] = useState("");
  const [deptMsg, setDeptMsg] = useState<string | null>(null);

  const [subjName, setSubjName] = useState("");
  const [subjCode, setSubjCode] = useState("");
  const [subjDeptId, setSubjDeptId] = useState("");
  const [subjSem, setSubjSem] = useState(4);
  const [subjCredits, setSubjCredits] = useState(3);
  const [subjMsg, setSubjMsg] = useState<string | null>(null);

  // User management form states
  const [newUserRole, setNewUserRole] = useState<"student" | "teacher" | "advisor">("student");
  const [newUserName, setNewUserName] = useState("");
  const [newUserEmail, setNewUserEmail] = useState("");
  const [newUserDeptId, setNewUserDeptId] = useState("");
  // student specific
  const [newUserRoll, setNewUserRoll] = useState("");
  const [newUserReg, setNewUserReg] = useState("");
  const [newUserBatch, setNewUserBatch] = useState("2024 - 2028");
  const [newUserSem, setNewUserSem] = useState(4);
  const [newUserAdvisor, setNewUserAdvisor] = useState("");
  const [userMsg, setUserMsg] = useState<string | null>(null);

  // User list filter states
  const [userRoleFilter, setUserRoleFilter] = useState<string>("all");
  const [userDeptFilter, setUserDeptFilter] = useState<string>("all");
  const [userSearchText, setUserSearchText] = useState("");

  // Enrollment state
  const [enrStudentId, setEnrStudentId] = useState("");
  const [enrSubjCode, setEnrSubjCode] = useState("");
  const [enrSem, setEnrSem] = useState(4);
  const [enrMsg, setEnrMsg] = useState<string | null>(null);
  const [enrError, setEnrError] = useState<string | null>(null);

  // Timetable Slot form state
  const [ttSubjCode, setTtSubjCode] = useState("");
  const [ttDay, setTtDay] = useState<"Monday" | "Tuesday" | "Wednesday" | "Thursday" | "Friday">("Monday");
  const [ttTime, setTtTime] = useState("");
  const [ttPeriod, setTtPeriod] = useState<"AM" | "PM">("AM");
  const [ttDuration, setTtDuration] = useState("1.5 hours");
  const [ttRoom, setTtRoom] = useState("");
  const [ttTeacherId, setTtTeacherId] = useState("");
  const [ttSection, setTtSection] = useState("Sec A");
  const [ttMsg, setTtMsg] = useState<string | null>(null);
  const [ttCollisionWarning, setTtCollisionWarning] = useState<string | null>(null);

  // Audit Logs Filter
  const [auditActorFilter, setAuditActorFilter] = useState("");
  const [auditTypeFilter, setAuditTypeFilter] = useState("all");

  // Health data calculation
  // 1. Students with zero enrollments
  const studentsWithNoEnrollments = profiles
    .filter(p => p.role === "student")
    .filter(student => !enrollments.some(e => e.studentId === student.id));

  // 2. Subjects with no timetable slot
  const subjectsWithNoTimetable = subjects.filter(
    subj => !timetable.some(t => t.subjectCode === subj.code)
  );

  // 3. Subjects with no teacher assigned in the timetable
  const subjectsWithNoTeacher = subjects.filter(
    subj => !timetable.some(t => t.subjectCode === subj.code && t.teacherId)
  );

  // Form Submissions
  const handleAddDept = (e: React.FormEvent) => {
    e.preventDefault();
    if (!deptName || !deptCode) return;

    const newDept: Department = {
      id: `dept-${deptCode.toLowerCase()}`,
      name: deptName,
      code: deptCode.toUpperCase()
    };

    onAddDepartment(newDept);
    onAddAuditLog(
      `Created department: ${deptName} (${deptCode})`,
      newDept.id,
      "Department"
    );

    setDeptMsg("Department added successfully!");
    setDeptName("");
    setDeptCode("");
    setTimeout(() => setDeptMsg(null), 3000);
  };

  const handleAddSubjectSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!subjName || !subjCode || !subjDeptId) return;

    const newSubj: Subject = {
      id: `sub-${Date.now()}`,
      name: subjName,
      code: subjCode.toUpperCase(),
      departmentId: subjDeptId,
      semester: Number(subjSem),
      credits: Number(subjCredits)
    };

    onAddSubject(newSubj);
    onAddAuditLog(
      `Created subject: ${subjName} [${subjCode}]`,
      newSubj.id,
      "Subject"
    );

    setSubjMsg("Subject registered successfully!");
    setSubjName("");
    setSubjCode("");
    setTimeout(() => setSubjMsg(null), 3000);
  };

  const handleAddUserSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newUserName || !newUserEmail) return;

    const newUser: Profile = {
      id: `user-${Date.now()}`,
      name: newUserName,
      email: newUserEmail,
      role: newUserRole,
      departmentId: newUserDeptId || undefined,
      ...(newUserRole === "student" ? {
        rollNumber: newUserRoll,
        registerNumber: newUserReg,
        semester: Number(newUserSem),
        batch: newUserBatch,
        advisorId: newUserAdvisor || undefined,
        academicStatus: "Active"
      } : {})
    };

    onAddProfile(newUser);
    onAddAuditLog(
      `Registered user profile: ${newUserName} [Role: ${newUserRole}]`,
      newUser.id,
      "User Registry"
    );

    setUserMsg(`Profile registered successfully for ${newUserName}!`);
    setNewUserName("");
    setNewUserEmail("");
    setNewUserRoll("");
    setNewUserReg("");
    setTimeout(() => setUserMsg(null), 3000);
  };

  const handleAddEnrollmentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!enrStudentId || !enrSubjCode) return;

    // Check duplicate enrollment
    const isDuplicate = enrollments.some(
      en => en.studentId === enrStudentId && en.subjectCode === enrSubjCode && en.semester === Number(enrSem)
    );

    if (isDuplicate) {
      setEnrError("Collision Warning: Student is already registered for this subject this semester!");
      setTimeout(() => setEnrError(null), 4000);
      return;
    }

    const newEnr: Enrollment = {
      id: `enr-${Date.now()}`,
      studentId: enrStudentId,
      subjectCode: enrSubjCode,
      semester: Number(enrSem)
    };

    onAddEnrollment(newEnr);
    
    const studentName = profiles.find(p => p.id === enrStudentId)?.name || enrStudentId;
    onAddAuditLog(
      `Enrolled student ${studentName} in course ${enrSubjCode}`,
      newEnr.id,
      "Enrollment"
    );

    setEnrMsg("Student course registration created successfully!");
    setTimeout(() => setEnrMsg(null), 3000);
  };

  // Timetable slot collision checker
  const checkTimetableCollision = (room: string, teacherId: string, day: string, timeStr: string, periodStr: string) => {
    if (!room || !teacherId) return null;

    // Check room collision: same room + day + time
    const roomCollision = timetable.find(
      t => t.room.toLowerCase() === room.toLowerCase() && t.dayOfWeek === day && t.time === timeStr && t.period === periodStr
    );

    if (roomCollision) {
      return `Room Collision detected: ${room} is already booked for ${roomCollision.subjectName} (${roomCollision.section}) on ${day} at ${timeStr} ${periodStr}`;
    }

    // Check teacher collision: same teacher + day + time
    const teacherCollision = timetable.find(
      t => t.teacherId === teacherId && t.dayOfWeek === day && t.time === timeStr && t.period === periodStr
    );

    if (teacherCollision) {
      return `Teacher Double-Booking warning: ${teacherCollision.teacherName} is already teaching ${teacherCollision.subjectName} on ${day} at ${timeStr} ${periodStr}`;
    }

    return null;
  };

  const handleAddTimetableSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!ttSubjCode || !ttTime || !ttRoom || !ttTeacherId) return;

    // Execute collision checks
    const collision = checkTimetableCollision(ttRoom, ttTeacherId, ttDay, ttTime, ttPeriod);
    if (collision) {
      setTtCollisionWarning(collision);
      // We log but still let the admin decide or force if they want to override, 
      // or we can prevent them. The spec says: "warns on room/teacher double-booking before save... collision check with clear inline warning before save, not a silent failure."
      // Let's prevent and show warning, but if they click again we can let them. Or we show the warning.
      // Let's show the warning and block unless resolved.
      return;
    }

    const matchingSubj = subjects.find(s => s.code === ttSubjCode);
    const matchingTeacher = profiles.find(p => p.id === ttTeacherId);

    const newSlot: TimetableSlot = {
      id: `slot-${Date.now()}`,
      subjectCode: ttSubjCode,
      subjectName: matchingSubj?.name || ttSubjCode,
      dayOfWeek: ttDay,
      time: ttTime,
      period: ttPeriod,
      duration: ttDuration,
      room: ttRoom,
      teacherId: ttTeacherId,
      teacherName: matchingTeacher?.name || ttTeacherId,
      section: ttSection
    };

    onAddTimetableSlot(newSlot);
    onAddAuditLog(
      `Added timetable slot for ${newSlot.subjectName} in ${ttRoom} (${ttSection})`,
      newSlot.id,
      "Timetable Slot"
    );

    setTtMsg("Timetable slot logged and active on portal calendar!");
    setTtCollisionWarning(null);
    setTtRoom("");
    setTtTime("");
    setTimeout(() => setTtMsg(null), 3000);
  };

  // Filtered lists
  const filteredUsers = profiles.filter(user => {
    if (user.role === "admin") return false; // hide admins
    const roleMatch = userRoleFilter === "all" ? true : user.role === userRoleFilter;
    const deptMatch = userDeptFilter === "all" ? true : user.departmentId === userDeptFilter;
    const searchMatch = userSearchText === "" ? true : 
      user.name.toLowerCase().includes(userSearchText.toLowerCase()) || 
      user.email.toLowerCase().includes(userSearchText.toLowerCase()) || 
      (user.rollNumber && user.rollNumber.toLowerCase().includes(userSearchText.toLowerCase()));
    
    return roleMatch && deptMatch && searchMatch;
  });

  const filteredAuditLogs = auditLogs.filter(log => {
    const actorMatch = auditActorFilter === "" ? true : log.actorName.toLowerCase().includes(auditActorFilter.toLowerCase()) || log.actorEmail.toLowerCase().includes(auditActorFilter.toLowerCase());
    const typeMatch = auditTypeFilter === "all" ? true : log.entityType === auditTypeFilter;
    return actorMatch && typeMatch;
  });

  return (
    <div className="space-y-8 pb-10" id="admin-dashboard-root">
      {/* Title */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold font-sans text-brand-on-surface dark:text-gray-100 flex items-center gap-2">
            <ShieldCheck size={24} className="text-brand-primary dark:text-indigo-400" />
            Operator Admin Console
          </h1>
          <p className="text-xs text-brand-on-variant dark:text-gray-400 mt-1">
            System administration console: manage structures, users, enrollments, schedules, and view complete audit records.
          </p>
        </div>

        {/* Console navigation tabs */}
        <div className="flex flex-wrap gap-2" id="admin-subtabs">
          {["Overview", "Users", "Curriculum", "Enrollments", "Schedules", "Audit Log"].map((tab) => (
            <button
              key={tab}
              id={`admin-tab-${tab.toLowerCase().replace(/ /g, "-")}`}
              onClick={() => setActiveSubTab(tab)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold cursor-pointer transition-all ${
                activeSubTab === tab
                  ? "neu-inset border border-brand-primary/20 text-brand-primary dark:text-indigo-400 font-extrabold"
                  : "neu-flat text-brand-on-variant dark:text-gray-400 hover:text-brand-on-surface"
              }`}
            >
              {tab}
            </button>
          ))}
        </div>
      </div>

      <AnimatePresence mode="wait">
        <motion.div
          key={activeSubTab}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -10 }}
          transition={{ duration: 0.15 }}
          className="space-y-8"
        >
          {/* ==================== 1. OVERVIEW SCREEN ==================== */}
          {activeSubTab === "Overview" && (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              {/* Institution snapshot counts */}
              <div className="lg:col-span-2 space-y-8">
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                  <div className="p-4 rounded-xl neu-flat bg-brand-surface/20">
                    <span className="text-[10px] font-mono font-bold text-gray-400 block uppercase">Students</span>
                    <span className="text-2xl font-extrabold font-serif italic text-brand-primary dark:text-indigo-400 mt-1 block">
                      {profiles.filter(p => p.role === "student").length}
                    </span>
                  </div>
                  <div className="p-4 rounded-xl neu-flat bg-brand-surface/20">
                    <span className="text-[10px] font-mono font-bold text-gray-400 block uppercase">Instructors</span>
                    <span className="text-2xl font-extrabold font-serif italic text-emerald-500 mt-1 block">
                      {profiles.filter(p => p.role === "teacher").length}
                    </span>
                  </div>
                  <div className="p-4 rounded-xl neu-flat bg-brand-surface/20">
                    <span className="text-[10px] font-mono font-bold text-gray-400 block uppercase">Departments</span>
                    <span className="text-2xl font-extrabold font-serif italic text-indigo-400 mt-1 block">
                      {departments.length}
                    </span>
                  </div>
                  <div className="p-4 rounded-xl neu-flat bg-brand-surface/20">
                    <span className="text-[10px] font-mono font-bold text-gray-400 block uppercase">Enrollments</span>
                    <span className="text-2xl font-extrabold font-serif italic text-amber-500 mt-1 block">
                      {enrollments.length}
                    </span>
                  </div>
                </div>

                {/* Data Health Flags checker */}
                <div className="p-6 rounded-2xl neu-flat space-y-4">
                  <h3 className="font-bold text-md text-brand-on-surface dark:text-gray-100 flex items-center gap-2">
                    <AlertTriangle size={18} className="text-brand-primary dark:text-indigo-400" />
                    Portal Core Data Health Flags
                  </h3>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    {/* Health Item 1: Student enrollment */}
                    <div className="p-4 rounded-xl neu-inset border border-brand-container/35 flex flex-col justify-between h-[120px]">
                      <div>
                        <span className="text-[9px] font-mono text-gray-400 block">ENROLLMENT GAP</span>
                        <span className="text-lg font-bold text-brand-on-surface dark:text-gray-200 mt-1 block">
                          {studentsWithNoEnrollments.length} Students
                        </span>
                        <span className="text-[9px] text-gray-500 mt-1 block">Zero active subject enrollments found</span>
                      </div>
                      {studentsWithNoEnrollments.length > 0 && (
                        <span className="text-[8px] font-mono text-rose-400 uppercase font-extrabold">⚠️ Action Required</span>
                      )}
                    </div>

                    {/* Health Item 2: Subjects with no schedules */}
                    <div className="p-4 rounded-xl neu-inset border border-brand-container/35 flex flex-col justify-between h-[120px]">
                      <div>
                        <span className="text-[9px] font-mono text-gray-400 block">TIMETABLE GAP</span>
                        <span className="text-lg font-bold text-brand-on-surface dark:text-gray-200 mt-1 block">
                          {subjectsWithNoTimetable.length} Courses
                        </span>
                        <span className="text-[9px] text-gray-500 mt-1 block">Registered courses with no calendar timetable</span>
                      </div>
                      {subjectsWithNoTimetable.length > 0 && (
                        <span className="text-[8px] font-mono text-rose-400 uppercase font-extrabold">⚠️ Action Required</span>
                      )}
                    </div>

                    {/* Health Item 3: Subjects with no teacher assigned */}
                    <div className="p-4 rounded-xl neu-inset border border-brand-container/35 flex flex-col justify-between h-[120px]">
                      <div>
                        <span className="text-[9px] font-mono text-gray-400 block">STAFFING GAP</span>
                        <span className="text-lg font-bold text-brand-on-surface dark:text-gray-200 mt-1 block">
                          {subjectsWithNoTeacher.length} Subjects
                        </span>
                        <span className="text-[9px] text-gray-500 mt-1 block">Classes lacking an instructor teaching profile</span>
                      </div>
                      {subjectsWithNoTeacher.length > 0 && (
                        <span className="text-[8px] font-mono text-rose-400 uppercase font-extrabold">⚠️ Action Required</span>
                      )}
                    </div>
                  </div>

                  {/* List out data health details */}
                  {(studentsWithNoEnrollments.length > 0 || subjectsWithNoTimetable.length > 0) && (
                    <div className="p-4 bg-rose-500/5 rounded-xl border border-rose-500/10 space-y-2 text-[10px] font-mono">
                      <span className="text-rose-400 font-bold block uppercase">Action Log Suggestions:</span>
                      {studentsWithNoEnrollments.map(s => (
                        <div key={s.id} className="text-gray-400">
                          • Student <strong>{s.name} ({s.rollNumber})</strong> has no class courses enrolled this semester. Go to "Enrollments" tab.
                        </div>
                      ))}
                      {subjectsWithNoTimetable.map(s => (
                        <div key={s.id} className="text-gray-400">
                          • Subject <strong>{s.name} ({s.code})</strong> lacks a timetable slot assignment. Go to "Schedules" tab.
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>

              {/* Sidebar: FAB Actions & Recent log entries */}
              <div className="space-y-8">
                <div className="p-6 rounded-2xl neu-flat bg-brand-primary-container/20 space-y-4">
                  <h3 className="font-bold text-xs font-mono uppercase text-brand-primary tracking-widest">Admin Quick Actions</h3>
                  
                  <div className="grid grid-cols-1 gap-2.5">
                    <button
                      onClick={() => {
                        setNewUserRole("student");
                        setActiveSubTab("Users");
                      }}
                      className="p-3 rounded-xl neu-button flex items-center gap-3 text-left cursor-pointer"
                    >
                      <Plus size={16} className="text-brand-primary" />
                      <div>
                        <span className="text-xs font-bold block leading-none">Register New Student</span>
                        <span className="text-[9px] text-gray-400 font-mono mt-1 block">Induct individual roll number</span>
                      </div>
                    </button>

                    <button
                      onClick={() => {
                        setActiveSubTab("Enrollments");
                      }}
                      className="p-3 rounded-xl neu-button flex items-center gap-3 text-left cursor-pointer"
                    >
                      <FileSpreadsheet size={16} className="text-emerald-500" />
                      <div>
                        <span className="text-xs font-bold block leading-none">Manage Enrollments</span>
                        <span className="text-[9px] text-gray-400 font-mono mt-1 block">Register student to subject</span>
                      </div>
                    </button>

                    <button
                      onClick={() => {
                        setActiveSubTab("Schedules");
                      }}
                      className="p-3 rounded-xl neu-button flex items-center gap-3 text-left cursor-pointer"
                    >
                      <Calendar size={16} className="text-indigo-400" />
                      <div>
                        <span className="text-xs font-bold block leading-none">Schedule Timetable</span>
                        <span className="text-[9px] text-gray-400 font-mono mt-1 block">Assign rooms and instructors</span>
                      </div>
                    </button>
                  </div>
                </div>

                {/* Local audits panel */}
                <div className="p-6 rounded-2xl neu-flat space-y-4">
                  <h3 className="font-bold text-sm text-brand-on-surface dark:text-gray-100">Audit Footprint (Last 5)</h3>
                  <div className="space-y-3">
                    {auditLogs.slice(0, 5).map(log => (
                      <div key={log.id} className="border-l-2 border-indigo-400 pl-3 py-0.5 space-y-1">
                        <p className="text-[11px] text-brand-on-surface dark:text-gray-200 font-medium leading-snug">{log.action}</p>
                        <span className="text-[8px] text-gray-400 font-mono block">
                          Actor: {log.actorName} • {new Date(log.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* ==================== 2. USERS MANAGEMENT ==================== */}
          {activeSubTab === "Users" && (
            <div className="space-y-8">
              {/* Form to Create New User */}
              <div className="p-6 rounded-2xl neu-flat space-y-5">
                <h3 className="font-bold text-md text-brand-on-surface dark:text-gray-100 flex items-center gap-2">
                  <Plus size={18} className="text-brand-primary dark:text-indigo-400" />
                  Individual User Induction Form (No Bulk CSV MVP)
                </h3>

                {userMsg && (
                  <div className="p-3 bg-emerald-500/10 border border-emerald-500/20 text-emerald-600 dark:text-emerald-400 text-xs font-bold text-center rounded-xl">
                    ✓ {userMsg}
                  </div>
                )}

                <form onSubmit={handleAddUserSubmit} className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <div className="space-y-1">
                      <label className="text-[10px] font-mono font-bold uppercase text-gray-400">Institutional Role</label>
                      <select
                        value={newUserRole}
                        onChange={(e) => setNewUserRole(e.target.value as any)}
                        className="w-full text-xs p-2.5 rounded-xl neu-inset bg-brand-surface dark:bg-brand-dark-surface text-brand-on-surface dark:text-gray-100 outline-none cursor-pointer"
                      >
                        <option value="student">Student Profile</option>
                        <option value="teacher">Instructor Profile</option>
                        <option value="advisor">Advisor Profile</option>
                      </select>
                    </div>

                    <div className="space-y-1">
                      <label className="text-[10px] font-mono font-bold uppercase text-gray-400">Full Name</label>
                      <input
                        type="text"
                        required
                        value={newUserName}
                        onChange={(e) => setNewUserName(e.target.value)}
                        placeholder="e.g. Richard Feynman"
                        className="w-full text-xs p-2.5 rounded-xl neu-inset bg-brand-surface dark:bg-brand-dark-surface text-brand-on-surface dark:text-gray-100 outline-none"
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="text-[10px] font-mono font-bold uppercase text-gray-400">Portal Email Access</label>
                      <input
                        type="email"
                        required
                        value={newUserEmail}
                        onChange={(e) => setNewUserEmail(e.target.value)}
                        placeholder="e.g. feynman@pacific.edu"
                        className="w-full text-xs p-2.5 rounded-xl neu-inset bg-brand-surface dark:bg-brand-dark-surface text-brand-on-surface dark:text-gray-100 outline-none"
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="text-[10px] font-mono font-bold uppercase text-gray-400">Academic Department</label>
                      <select
                        value={newUserDeptId}
                        onChange={(e) => setNewUserDeptId(e.target.value)}
                        className="w-full text-xs p-2.5 rounded-xl neu-inset bg-brand-surface dark:bg-brand-dark-surface text-brand-on-surface dark:text-gray-100 outline-none cursor-pointer"
                      >
                        <option value="">Select Department...</option>
                        {departments.map(dept => (
                          <option key={dept.id} value={dept.id}>{dept.name} ({dept.code})</option>
                        ))}
                      </select>
                    </div>
                  </div>

                  {/* Student Specific Fields */}
                  {newUserRole === "student" && (
                    <div className="p-4 bg-brand-surface-bright dark:bg-slate-900 rounded-xl border border-brand-container/40 grid grid-cols-1 md:grid-cols-5 gap-4">
                      <div className="space-y-1">
                        <label className="text-[10px] font-mono font-bold uppercase text-gray-400">Roll Number</label>
                        <input
                          type="text"
                          required
                          value={newUserRoll}
                          onChange={(e) => setNewUserRoll(e.target.value)}
                          placeholder="e.g. CSE-2024-080"
                          className="w-full text-xs p-2 rounded neu-inset bg-brand-surface dark:bg-brand-dark-surface text-brand-on-surface dark:text-gray-100 outline-none"
                        />
                      </div>

                      <div className="space-y-1">
                        <label className="text-[10px] font-mono font-bold uppercase text-gray-400">Register Number</label>
                        <input
                          type="text"
                          required
                          value={newUserReg}
                          onChange={(e) => setNewUserReg(e.target.value)}
                          placeholder="e.g. REG-9912034"
                          className="w-full text-xs p-2 rounded neu-inset bg-brand-surface dark:bg-brand-dark-surface text-brand-on-surface dark:text-gray-100 outline-none"
                        />
                      </div>

                      <div className="space-y-1">
                        <label className="text-[10px] font-mono font-bold uppercase text-gray-400">Batch Year</label>
                        <input
                          type="text"
                          value={newUserBatch}
                          onChange={(e) => setNewUserBatch(e.target.value)}
                          className="w-full text-xs p-2 rounded neu-inset bg-brand-surface dark:bg-brand-dark-surface text-brand-on-surface dark:text-gray-100 outline-none"
                        />
                      </div>

                      <div className="space-y-1">
                        <label className="text-[10px] font-mono font-bold uppercase text-gray-400">Semester Term</label>
                        <input
                          type="number"
                          value={newUserSem}
                          onChange={(e) => setNewUserSem(Number(e.target.value))}
                          className="w-full text-xs p-2 rounded neu-inset bg-brand-surface dark:bg-brand-dark-surface text-brand-on-surface dark:text-gray-100 outline-none"
                        />
                      </div>

                      <div className="space-y-1">
                        <label className="text-[10px] font-mono font-bold uppercase text-gray-400">Pastoral Advisor</label>
                        <select
                          value={newUserAdvisor}
                          onChange={(e) => setNewUserAdvisor(e.target.value)}
                          className="w-full text-xs p-2 rounded neu-inset bg-brand-surface dark:bg-brand-dark-surface text-brand-on-surface dark:text-gray-100 outline-none cursor-pointer"
                        >
                          <option value="">Choose Advisor...</option>
                          {profiles.filter(p => p.role === "advisor").map(adv => (
                            <option key={adv.id} value={adv.id}>{adv.name}</option>
                          ))}
                        </select>
                      </div>
                    </div>
                  )}

                  <div className="flex justify-end pt-2">
                    <button
                      type="submit"
                      className="py-2.5 px-6 bg-brand-primary hover:bg-brand-primary-container text-white text-xs font-bold rounded-xl shadow-md cursor-pointer transition-all flex items-center gap-1.5"
                    >
                      <Plus size={14} /> Register System User
                    </button>
                  </div>
                </form>
              </div>

              {/* Users Directory List */}
              <div className="p-6 rounded-2xl neu-flat space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 border-b border-brand-container pb-4">
                  <h3 className="font-bold text-md text-brand-on-surface dark:text-gray-100">Registered System Directory</h3>
                  
                  {/* Filters search */}
                  <div className="flex flex-wrap items-center gap-3">
                    <div className="relative">
                      <Search size={14} className="absolute left-3 top-2.5 text-gray-400" />
                      <input
                        type="text"
                        placeholder="Search name, email, roll..."
                        value={userSearchText}
                        onChange={(e) => setUserSearchText(e.target.value)}
                        className="p-2 pl-9 text-xs rounded-xl neu-inset bg-brand-surface dark:bg-brand-dark-surface text-brand-on-surface dark:text-gray-100 outline-none w-[180px] sm:w-[240px]"
                      />
                    </div>

                    <select
                      value={userRoleFilter}
                      onChange={(e) => setUserRoleFilter(e.target.value)}
                      className="p-2 text-xs rounded-xl neu-inset bg-brand-surface dark:bg-brand-dark-surface text-brand-on-surface dark:text-gray-100 outline-none cursor-pointer"
                    >
                      <option value="all">All Roles</option>
                      <option value="student">Students</option>
                      <option value="teacher">Instructors</option>
                      <option value="advisor">Advisors</option>
                    </select>

                    <select
                      value={userDeptFilter}
                      onChange={(e) => setUserDeptFilter(e.target.value)}
                      className="p-2 text-xs rounded-xl neu-inset bg-brand-surface dark:bg-brand-dark-surface text-brand-on-surface dark:text-gray-100 outline-none cursor-pointer"
                    >
                      <option value="all">All Depts</option>
                      {departments.map(dept => (
                        <option key={dept.id} value={dept.id}>{dept.code}</option>
                      ))}
                    </select>
                  </div>
                </div>

                <div className="overflow-x-auto rounded-xl border border-brand-container/20">
                  <table className="w-full text-left text-xs">
                    <thead>
                      <tr className="bg-brand-surface-bright dark:bg-slate-900 border-b border-brand-container">
                        <th className="p-3 font-mono text-[10px] uppercase font-bold text-gray-400">Name / Email</th>
                        <th className="p-3 font-mono text-[10px] uppercase font-bold text-gray-400">Department</th>
                        <th className="p-3 font-mono text-[10px] uppercase font-bold text-gray-400">Roll/Register</th>
                        <th className="p-3 font-mono text-[10px] uppercase font-bold text-gray-400">Advisor Note</th>
                        <th className="p-3 font-mono text-[10px] uppercase font-bold text-gray-400">Role Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-brand-container/40">
                      {filteredUsers.map(user => {
                        const userDept = departments.find(d => d.id === user.departmentId);
                        const userAdvisorName = profiles.find(p => p.id === user.advisorId)?.name || "Not Assigned";

                        return (
                          <tr key={user.id} className="hover:bg-brand-surface-dim/30">
                            <td className="p-3">
                              <span className="font-bold text-brand-on-surface dark:text-gray-200 block">{user.name}</span>
                              <span className="text-[10px] text-gray-400 font-mono block mt-0.5">{user.email}</span>
                            </td>
                            <td className="p-3 font-mono text-[11px] text-brand-on-surface dark:text-gray-200">
                              {userDept ? `${userDept.name} (${userDept.code})` : "N/A"}
                            </td>
                            <td className="p-3 font-mono text-[11px] text-brand-on-surface dark:text-gray-200">
                              {user.rollNumber ? (
                                <>
                                  <span className="block font-bold">{user.rollNumber}</span>
                                  <span className="text-[9px] text-gray-400 block mt-0.5">{user.registerNumber}</span>
                                </>
                              ) : "N/A"}
                            </td>
                            <td className="p-3 font-mono text-[10px] text-gray-400">
                              {user.role === "student" ? `Advisor: ${userAdvisorName}` : "N/A"}
                            </td>
                            <td className="p-3">
                              <span className={`text-[9px] font-mono font-extrabold px-2 py-0.5 rounded uppercase tracking-wider ${
                                user.role === "student"
                                  ? "bg-emerald-500/10 text-emerald-500"
                                  : user.role === "teacher"
                                    ? "bg-indigo-500/10 text-brand-primary"
                                    : "bg-amber-500/10 text-amber-500"
                              }`}>
                                {user.role}
                              </span>
                            </td>
                          </tr>
                        );
                      })}
                      {filteredUsers.length === 0 && (
                        <tr>
                          <td colSpan={5} className="p-6 text-center text-xs text-gray-400 font-serif italic">
                            No system profiles matching active filter keywords.
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* ==================== 3. CURRICULUM ==================== */}
          {activeSubTab === "Curriculum" && (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {/* Departments Management */}
              <div className="p-6 rounded-2xl neu-flat space-y-5">
                <h3 className="font-bold text-md text-brand-on-surface dark:text-gray-100 flex items-center gap-2">
                  <Building2 size={18} className="text-brand-primary dark:text-indigo-400" />
                  Departments Registry
                </h3>

                {deptMsg && (
                  <div className="p-2 bg-emerald-500/10 border border-emerald-500/20 text-emerald-500 text-xs font-bold text-center rounded">
                    ✓ {deptMsg}
                  </div>
                )}

                <form onSubmit={handleAddDept} className="flex gap-3">
                  <input
                    type="text"
                    required
                    value={deptName}
                    onChange={(e) => setDeptName(e.target.value)}
                    placeholder="e.g. Mechanical Engineering"
                    className="flex-1 text-xs p-2.5 rounded-xl neu-inset bg-brand-surface dark:bg-brand-dark-surface text-brand-on-surface dark:text-gray-100 outline-none"
                  />
                  <input
                    type="text"
                    required
                    value={deptCode}
                    onChange={(e) => setDeptCode(e.target.value)}
                    placeholder="e.g. MECH"
                    className="w-20 text-xs p-2.5 rounded-xl neu-inset bg-brand-surface dark:bg-brand-dark-surface text-brand-on-surface dark:text-gray-100 outline-none text-center"
                  />
                  <button
                    type="submit"
                    className="py-2.5 px-4 bg-brand-primary hover:bg-brand-primary-container text-white text-xs font-bold rounded-xl shadow cursor-pointer transition-all"
                  >
                    Add
                  </button>
                </form>

                <div className="space-y-2 max-h-[250px] overflow-y-auto pr-1">
                  {departments.map(dept => (
                    <div key={dept.id} className="p-3 rounded-xl neu-inset flex items-center justify-between">
                      <span className="text-xs font-bold text-brand-on-surface dark:text-gray-200">{dept.name}</span>
                      <span className="text-[10px] font-mono font-bold bg-indigo-500/10 text-brand-primary px-2 py-0.5 rounded uppercase">
                        {dept.code}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Subjects / Courses Management */}
              <div className="p-6 rounded-2xl neu-flat space-y-5">
                <h3 className="font-bold text-md text-brand-on-surface dark:text-gray-100 flex items-center gap-2">
                  <BookOpen size={18} className="text-brand-primary dark:text-indigo-400" />
                  Subject syllabus Catalogue
                </h3>

                {subjMsg && (
                  <div className="p-2 bg-emerald-500/10 border border-emerald-500/20 text-emerald-500 text-xs font-bold text-center rounded">
                    ✓ {subjMsg}
                  </div>
                )}

                <form onSubmit={handleAddSubjectSubmit} className="space-y-3">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <input
                      type="text"
                      required
                      value={subjName}
                      onChange={(e) => setSubjName(e.target.value)}
                      placeholder="Course Name e.g. Electromagnetics"
                      className="text-xs p-2.5 rounded-xl neu-inset bg-brand-surface dark:bg-brand-dark-surface text-brand-on-surface dark:text-gray-100 outline-none"
                    />
                    <input
                      type="text"
                      required
                      value={subjCode}
                      onChange={(e) => setSubjCode(e.target.value)}
                      placeholder="Code e.g. PHY-410"
                      className="text-xs p-2.5 rounded-xl neu-inset bg-brand-surface dark:bg-brand-dark-surface text-brand-on-surface dark:text-gray-100 outline-none"
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <select
                      required
                      value={subjDeptId}
                      onChange={(e) => setSubjDeptId(e.target.value)}
                      className="text-xs p-2.5 rounded-xl neu-inset bg-brand-surface dark:bg-brand-dark-surface text-brand-on-surface dark:text-gray-100 outline-none cursor-pointer"
                    >
                      <option value="">Department...</option>
                      {departments.map(dept => (
                        <option key={dept.id} value={dept.id}>{dept.code}</option>
                      ))}
                    </select>

                    <input
                      type="number"
                      placeholder="Sem e.g. 4"
                      value={subjSem}
                      onChange={(e) => setSubjSem(Number(e.target.value))}
                      className="text-xs p-2.5 rounded-xl neu-inset bg-brand-surface dark:bg-brand-dark-surface text-brand-on-surface dark:text-gray-100 outline-none"
                    />

                    <input
                      type="number"
                      placeholder="Credits e.g. 3"
                      value={subjCredits}
                      onChange={(e) => setSubjCredits(Number(e.target.value))}
                      className="text-xs p-2.5 rounded-xl neu-inset bg-brand-surface dark:bg-brand-dark-surface text-brand-on-surface dark:text-gray-100 outline-none"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full py-2 bg-brand-primary hover:bg-brand-primary-container text-white text-xs font-bold rounded-xl shadow cursor-pointer transition-all flex items-center justify-center gap-1.5"
                  >
                    <Plus size={14} /> Register syllabus Syllabus
                  </button>
                </form>

                <div className="space-y-2 max-h-[160px] overflow-y-auto pr-1">
                  {subjects.map(subj => (
                    <div key={subj.id} className="p-3 rounded-xl neu-inset flex items-center justify-between text-xs font-semibold">
                      <div>
                        <span className="font-bold text-brand-on-surface dark:text-gray-200">{subj.name}</span>
                        <span className="text-[10px] text-gray-400 block mt-0.5">Sem {subj.semester} • Credits {subj.credits}</span>
                      </div>
                      <span className="text-[10px] font-mono font-bold bg-indigo-500/10 text-brand-primary px-2 py-0.5 rounded uppercase">
                        {subj.code}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* ==================== 4. ENROLLMENTS SYSTEM ==================== */}
          {activeSubTab === "Enrollments" && (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              {/* Enrollment Registration Form */}
              <div className="p-6 rounded-2xl neu-flat space-y-4">
                <h3 className="font-bold text-md text-brand-on-surface dark:text-gray-100 flex items-center gap-2">
                  <UserCheck size={18} className="text-brand-primary dark:text-indigo-400" />
                  Course Registration form
                </h3>

                {enrMsg && (
                  <div className="p-3 bg-emerald-500/10 border border-emerald-500/20 text-emerald-600 dark:text-emerald-400 text-xs font-bold text-center rounded-xl">
                    ✓ {enrMsg}
                  </div>
                )}

                {enrError && (
                  <div className="p-3 bg-rose-500/10 border border-rose-500/20 text-rose-500 text-xs font-bold text-center rounded-xl">
                    ⚠️ {enrError}
                  </div>
                )}

                <form onSubmit={handleAddEnrollmentSubmit} className="space-y-4">
                  <div className="space-y-1">
                    <label className="text-[10px] font-mono font-bold uppercase text-gray-400">Enrolling Student</label>
                    <select
                      required
                      value={enrStudentId}
                      onChange={(e) => setEnrStudentId(e.target.value)}
                      className="w-full text-xs p-2.5 rounded-xl neu-inset bg-brand-surface dark:bg-brand-dark-surface text-brand-on-surface dark:text-gray-100 outline-none cursor-pointer"
                    >
                      <option value="">Choose Student...</option>
                      {profiles.filter(p => p.role === "student").map(stud => (
                        <option key={stud.id} value={stud.id}>{stud.name} ({stud.rollNumber})</option>
                      ))}
                    </select>
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-mono font-bold uppercase text-gray-400">Class Subject</label>
                    <select
                      required
                      value={enrSubjCode}
                      onChange={(e) => setEnrSubjCode(e.target.value)}
                      className="w-full text-xs p-2.5 rounded-xl neu-inset bg-brand-surface dark:bg-brand-dark-surface text-brand-on-surface dark:text-gray-100 outline-none cursor-pointer"
                    >
                      <option value="">Select Class...</option>
                      {subjects.map(subj => (
                        <option key={subj.id} value={subj.code}>{subj.code} - {subj.name}</option>
                      ))}
                    </select>
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-mono font-bold uppercase text-gray-400">Active Term Semester</label>
                    <input
                      type="number"
                      required
                      value={enrSem}
                      onChange={(e) => setEnrSem(Number(e.target.value))}
                      className="w-full text-xs p-2.5 rounded-xl neu-inset bg-brand-surface dark:bg-brand-dark-surface text-brand-on-surface dark:text-gray-100 outline-none"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full py-2.5 bg-brand-primary hover:bg-brand-primary-container text-white text-xs font-bold rounded-xl shadow transition-all cursor-pointer flex items-center justify-center gap-1.5"
                  >
                    <Plus size={14} /> Register Enrollment Row
                  </button>
                </form>
              </div>

              {/* Course Registry directory list */}
              <div className="lg:col-span-2 p-6 rounded-2xl neu-flat space-y-4">
                <h3 className="font-bold text-md text-brand-on-surface dark:text-gray-100">Live Course Registrations</h3>

                <div className="overflow-x-auto rounded-xl border border-brand-container/20">
                  <table className="w-full text-left text-xs">
                    <thead>
                      <tr className="bg-brand-surface-bright dark:bg-slate-900 border-b border-brand-container">
                        <th className="p-3 font-mono text-[10px] uppercase font-bold text-gray-400">Registered Student</th>
                        <th className="p-3 font-mono text-[10px] uppercase font-bold text-gray-400">Subject Code</th>
                        <th className="p-3 font-mono text-[10px] uppercase font-bold text-gray-400">Course Subject</th>
                        <th className="p-3 font-mono text-[10px] uppercase font-bold text-gray-400 text-center">Semester Term</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-brand-container/40">
                      {enrollments.map(enr => {
                        const studProfile = profiles.find(p => p.id === enr.studentId);
                        const subjName = subjects.find(s => s.code === enr.subjectCode)?.name || enr.subjectCode;

                        return (
                          <tr key={enr.id} className="hover:bg-brand-surface-dim/30">
                            <td className="p-3 font-bold text-brand-on-surface dark:text-gray-200">
                              {studProfile?.name || enr.studentId}
                            </td>
                            <td className="p-3 font-mono text-[11px] text-brand-primary dark:text-indigo-400 font-bold">
                              {enr.subjectCode}
                            </td>
                            <td className="p-3 text-brand-on-surface dark:text-gray-200">
                              {subjName}
                            </td>
                            <td className="p-3 text-center font-mono font-bold text-brand-on-surface dark:text-gray-200">
                              Sem {enr.semester}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* ==================== 5. TIMETABLE SCHEDULES ==================== */}
          {activeSubTab === "Schedules" && (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              {/* Add Timetable slot with double booking check */}
              <div className="p-6 rounded-2xl neu-flat space-y-4">
                <h3 className="font-bold text-md text-brand-on-surface dark:text-gray-100 flex items-center gap-2">
                  <Calendar size={18} className="text-brand-primary dark:text-indigo-400" />
                  Map Timetable Slot
                </h3>

                {ttMsg && (
                  <div className="p-3 bg-emerald-500/10 border border-emerald-500/20 text-emerald-600 dark:text-emerald-400 text-xs font-bold text-center rounded-xl">
                    ✓ {ttMsg}
                  </div>
                )}

                {ttCollisionWarning && (
                  <div className="p-3 bg-rose-500/10 border border-rose-500/25 text-rose-500 text-xs font-bold rounded-xl flex items-start gap-2">
                    <AlertTriangle size={16} className="flex-shrink-0 mt-0.5" />
                    <p className="leading-tight">{ttCollisionWarning}</p>
                  </div>
                )}

                <form onSubmit={handleAddTimetableSubmit} className="space-y-3.5">
                  <div className="space-y-1">
                    <label className="text-[10px] font-mono font-bold uppercase text-gray-400">Syllabus Subject</label>
                    <select
                      required
                      value={ttSubjCode}
                      onChange={(e) => {
                        setTtSubjCode(e.target.value);
                        setTtCollisionWarning(null);
                      }}
                      className="w-full text-xs p-2.5 rounded-xl neu-inset bg-brand-surface dark:bg-brand-dark-surface text-brand-on-surface dark:text-gray-100 outline-none cursor-pointer"
                    >
                      <option value="">Select subject...</option>
                      {subjects.map(subj => (
                        <option key={subj.id} value={subj.code}>{subj.code} - {subj.name}</option>
                      ))}
                    </select>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-1">
                      <label className="text-[10px] font-mono font-bold uppercase text-gray-400">Class Day</label>
                      <select
                        value={ttDay}
                        onChange={(e) => {
                          setTtDay(e.target.value as any);
                          setTtCollisionWarning(null);
                        }}
                        className="w-full text-xs p-2.5 rounded-xl neu-inset bg-brand-surface dark:bg-brand-dark-surface text-brand-on-surface dark:text-gray-100 outline-none cursor-pointer"
                      >
                        {["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"].map(d => (
                          <option key={d} value={d}>{d}</option>
                        ))}
                      </select>
                    </div>

                    <div className="space-y-1">
                      <label className="text-[10px] font-mono font-bold uppercase text-gray-400">Room Location</label>
                      <input
                        type="text"
                        required
                        value={ttRoom}
                        onChange={(e) => {
                          setTtRoom(e.target.value);
                          setTtCollisionWarning(null);
                        }}
                        placeholder="e.g. Room 402-A"
                        className="w-full text-xs p-2.5 rounded-xl neu-inset bg-brand-surface dark:bg-brand-dark-surface text-brand-on-surface dark:text-gray-100 outline-none"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-2">
                    <div className="space-y-1 col-span-2">
                      <label className="text-[10px] font-mono font-bold uppercase text-gray-400">Time e.g. 09:00</label>
                      <input
                        type="text"
                        required
                        placeholder="e.g. 09:00"
                        value={ttTime}
                        onChange={(e) => {
                          setTtTime(e.target.value);
                          setTtCollisionWarning(null);
                        }}
                        className="w-full text-xs p-2.5 rounded-xl neu-inset bg-brand-surface dark:bg-brand-dark-surface text-brand-on-surface dark:text-gray-100 outline-none"
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="text-[10px] font-mono font-bold uppercase text-gray-400">Period</label>
                      <select
                        value={ttPeriod}
                        onChange={(e) => {
                          setTtPeriod(e.target.value as any);
                          setTtCollisionWarning(null);
                        }}
                        className="w-full text-xs p-2.5 rounded-xl neu-inset bg-brand-surface dark:bg-brand-dark-surface text-brand-on-surface dark:text-gray-100 outline-none cursor-pointer"
                      >
                        <option value="AM">AM</option>
                        <option value="PM">PM</option>
                      </select>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-1">
                      <label className="text-[10px] font-mono font-bold uppercase text-gray-400">Duration</label>
                      <input
                        type="text"
                        value={ttDuration}
                        onChange={(e) => setTtDuration(e.target.value)}
                        className="w-full text-xs p-2.5 rounded-xl neu-inset bg-brand-surface dark:bg-brand-dark-surface text-brand-on-surface dark:text-gray-100 outline-none"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[10px] font-mono font-bold uppercase text-gray-400">Batch Section</label>
                      <input
                        type="text"
                        value={ttSection}
                        onChange={(e) => setTtSection(e.target.value)}
                        className="w-full text-xs p-2.5 rounded-xl neu-inset bg-brand-surface dark:bg-brand-dark-surface text-brand-on-surface dark:text-gray-100 outline-none"
                      />
                    </div>
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-mono font-bold uppercase text-gray-400">Instructor assigned</label>
                    <select
                      required
                      value={ttTeacherId}
                      onChange={(e) => {
                        setTtTeacherId(e.target.value);
                        setTtCollisionWarning(null);
                      }}
                      className="w-full text-xs p-2.5 rounded-xl neu-inset bg-brand-surface dark:bg-brand-dark-surface text-brand-on-surface dark:text-gray-100 outline-none cursor-pointer"
                    >
                      <option value="">Assign Instructor...</option>
                      {profiles.filter(p => p.role === "teacher").map(teach => (
                        <option key={teach.id} value={teach.id}>{teach.name}</option>
                      ))}
                    </select>
                  </div>

                  <button
                    type="submit"
                    className="w-full py-2.5 bg-brand-primary hover:bg-brand-primary-container text-white text-xs font-bold rounded-xl shadow transition-all cursor-pointer flex items-center justify-center gap-1.5"
                  >
                    <Plus size={14} /> Map Timetable Row
                  </button>
                </form>
              </div>

              {/* Timetable slots listing */}
              <div className="lg:col-span-2 p-6 rounded-2xl neu-flat space-y-4">
                <h3 className="font-bold text-md text-brand-on-surface dark:text-gray-100">Portal Calendar Timetable</h3>

                <div className="space-y-3.5 max-h-[500px] overflow-y-auto pr-1">
                  {["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"].map(day => {
                    const daySlots = timetable.filter(s => s.dayOfWeek === day);
                    if (daySlots.length === 0) return null;

                    return (
                      <div key={day} className="space-y-2">
                        <span className="text-[10px] font-mono font-bold text-brand-primary block border-b border-brand-container pb-1 uppercase">
                          {day} Classes
                        </span>

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                          {daySlots.map(slot => (
                            <div key={slot.id} className="p-3.5 rounded-xl neu-inset space-y-2 text-xs">
                              <div className="flex items-center justify-between">
                                <span className="text-[9px] font-mono font-extrabold bg-indigo-500/10 text-brand-primary px-1.5 py-0.5 rounded">
                                  {slot.subjectCode}
                                </span>
                                <span className="text-[9px] font-mono text-gray-400">{slot.room}</span>
                              </div>

                              <h4 className="font-bold text-brand-on-surface dark:text-gray-100 leading-snug">{slot.subjectName}</h4>
                              
                              <div className="flex justify-between items-center text-[10px] font-mono text-gray-400 pt-1 border-t border-brand-container/20">
                                <span>{slot.time} {slot.period} ({slot.duration})</span>
                                <span className="font-bold text-brand-on-surface dark:text-gray-300">{slot.teacherName}</span>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          )}

          {/* ==================== 6. AUDIT LOGS VIEW ==================== */}
          {activeSubTab === "Audit Log" && (
            <div className="p-6 rounded-2xl neu-flat space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 border-b border-brand-container pb-4">
                <div>
                  <h3 className="font-bold text-md text-brand-on-surface dark:text-gray-100">Portal Security Write Logs</h3>
                  <p className="text-[11px] text-brand-on-variant dark:text-gray-400 mt-0.5">
                    Immutable activity logs detailing user, timestamps, actions, and security checksum entities.
                  </p>
                </div>

                {/* Filters */}
                <div className="flex flex-wrap items-center gap-3">
                  <input
                    type="text"
                    placeholder="Filter actor email..."
                    value={auditActorFilter}
                    onChange={(e) => setAuditActorFilter(e.target.value)}
                    className="p-2 text-xs rounded-xl neu-inset bg-brand-surface dark:bg-brand-dark-surface text-brand-on-surface dark:text-gray-100 outline-none w-[180px]"
                  />

                  <select
                    value={auditTypeFilter}
                    onChange={(e) => setAuditTypeFilter(e.target.value)}
                    className="p-2 text-xs rounded-xl neu-inset bg-brand-surface dark:bg-brand-dark-surface text-brand-on-surface dark:text-gray-100 outline-none cursor-pointer"
                  >
                    <option value="all">All Logs</option>
                    <option value="System Setup">System Setup</option>
                    <option value="Attendance">Attendance</option>
                    <option value="Assignment">Assignment</option>
                    <option value="Grading">Grading</option>
                    <option value="Marks Draft">Marks Draft</option>
                    <option value="Marks Publish">Marks Publish</option>
                    <option value="User Registry">User Registry</option>
                    <option value="Enrollment">Enrollment</option>
                    <option value="Timetable Slot">Timetable Slot</option>
                    <option value="Resource Upload">Resource Upload</option>
                    <option value="Advisor Note">Advisor Note</option>
                  </select>
                </div>
              </div>

              <div className="overflow-x-auto rounded-xl border border-brand-container/20">
                <table className="w-full text-left text-xs">
                  <thead>
                    <tr className="bg-brand-surface-bright dark:bg-slate-900 border-b border-brand-container">
                      <th className="p-3 font-mono text-[10px] uppercase font-bold text-gray-400">Timestamp</th>
                      <th className="p-3 font-mono text-[10px] uppercase font-bold text-gray-400">Actor Profile</th>
                      <th className="p-3 font-mono text-[10px] uppercase font-bold text-gray-400">Action logged</th>
                      <th className="p-3 font-mono text-[10px] uppercase font-bold text-gray-400">Module Scope</th>
                      <th className="p-3 font-mono text-[10px] uppercase font-bold text-gray-400">Reference Token</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-brand-container/40">
                    {filteredAuditLogs.map(log => (
                      <tr key={log.id} className="hover:bg-brand-surface-dim/30">
                        <td className="p-3 font-mono text-[10px] text-brand-on-surface dark:text-gray-200">
                          {new Date(log.timestamp).toLocaleString()}
                        </td>
                        <td className="p-3">
                          <span className="font-bold text-brand-on-surface dark:text-gray-200 block">{log.actorName}</span>
                          <span className="text-[10px] text-gray-400 font-mono block mt-0.5">{log.actorEmail}</span>
                        </td>
                        <td className="p-3 text-brand-on-surface dark:text-gray-200 font-medium">
                          {log.action}
                        </td>
                        <td className="p-3">
                          <span className="text-[9px] font-mono font-bold bg-indigo-500/10 text-brand-primary px-2 py-0.5 rounded-full uppercase">
                            {log.entityType}
                          </span>
                        </td>
                        <td className="p-3 font-mono text-[10px] text-gray-400">
                          {log.entity}
                        </td>
                      </tr>
                    ))}
                    {filteredAuditLogs.length === 0 && (
                      <tr>
                        <td colSpan={5} className="p-6 text-center text-xs text-gray-400 font-serif italic">
                          No write transactions matches in register.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </motion.div>
      </AnimatePresence>
    </div>
  );
}
