import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Calendar, 
  Clock, 
  MapPin, 
  User, 
  Coffee, 
  Send, 
  CheckCircle, 
  ChevronRight, 
  Award, 
  MessageSquare,
  Sparkles
} from "lucide-react";
import { WEEKLY_SCHEDULE } from "../data";

export default function ScheduleScreen() {
  const [scheduleView, setScheduleView] = useState<"daily" | "weekly">("daily");
  const [selectedDay, setSelectedDay] = useState(30); // Today is Tuesday June 30th
  
  // Memo to tutor form state
  const [selectedTutor, setSelectedTutor] = useState("");
  const [memoSubject, setMemoSubject] = useState("");
  const [memoText, setMemoText] = useState("");
  const [sendSuccess, setSendSuccess] = useState(false);

  const tutors = [
    { name: "Dr. Emily Ross", subject: "Advanced Mathematics" },
    { name: "Prof. Albert Stern", subject: "Quantum Physics Lab" },
    { name: "Dr. Sarah Vance", subject: "Cognitive Neuroscience" },
    { name: "Prof. Alan Turing", subject: "Data Structures & Algorithms" }
  ];

  const handleSendMemo = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedTutor || !memoSubject || !memoText) return;
    
    setSendSuccess(true);
    setTimeout(() => {
      setSendSuccess(false);
      setSelectedTutor("");
      setMemoSubject("");
      setMemoText("");
    }, 3000);
  };

  const dates = [
    { day: "Sun", date: 28, current: false },
    { day: "Mon", date: 29, current: false },
    { day: "Tue", date: 30, current: true }, // Today
    { day: "Wed", date: 1, current: false, nextMonth: true },
    { day: "Thu", date: 2, current: false, nextMonth: true },
    { day: "Fri", date: 3, current: false, nextMonth: true },
    { day: "Sat", date: 4, current: false, nextMonth: true }
  ];

  return (
    <div className="space-y-8 pb-10" id="schedule-root">
      {/* Header and View Selector */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold font-sans text-brand-on-surface dark:text-gray-100 flex items-center gap-2">
            <Calendar size={24} className="text-brand-primary dark:text-indigo-400" />
            Academic Calendar &amp; Schedule
          </h1>
          <p className="text-xs text-brand-on-variant dark:text-gray-400 mt-1">Manage your lecture halls, lab bookings, and tutor communications.</p>
        </div>

        {/* Neumorphic View Selector Segment */}
        <div className="flex p-1.5 rounded-xl neu-inset gap-1 bg-brand-surface dark:bg-brand-dark-low">
          <button
            onClick={() => setScheduleView("daily")}
            className={`px-4 py-2 text-xs font-bold rounded-lg transition-all cursor-pointer ${
              scheduleView === "daily"
                ? "neu-flat bg-brand-primary text-brand-primary dark:text-indigo-400 font-extrabold"
                : "text-brand-on-variant dark:text-gray-400 hover:text-brand-on-surface dark:hover:text-gray-200"
            }`}
          >
            Daily Classes
          </button>
          <button
            onClick={() => setScheduleView("weekly")}
            className={`px-4 py-2 text-xs font-bold rounded-lg transition-all cursor-pointer ${
              scheduleView === "weekly"
                ? "neu-flat bg-brand-primary text-brand-primary dark:text-indigo-400 font-extrabold"
                : "text-brand-on-variant dark:text-gray-400 hover:text-brand-on-surface dark:hover:text-gray-200"
            }`}
          >
            Weekly Schedule
          </button>
        </div>
      </div>

      {/* Date Navigation Bar Strip */}
      <div className="p-4 rounded-2xl neu-flat space-y-3">
        <div className="flex items-center justify-between">
          <span className="text-xs font-mono font-bold uppercase text-brand-on-variant dark:text-gray-400">June &amp; July 2026</span>
          <span className="text-xs font-semibold text-brand-primary dark:text-indigo-400 font-sans">GMT -07:00 • Pacific Standard</span>
        </div>

        {/* Days Scroll Strip */}
        <div className="grid grid-cols-7 gap-2">
          {dates.map((d) => (
            <button
              key={d.date}
              onClick={() => setSelectedDay(d.date)}
              className={`p-3 rounded-xl flex flex-col items-center justify-center gap-1 transition-all cursor-pointer ${
                selectedDay === d.date
                  ? "neu-inset border-t-2 border-brand-primary bg-indigo-50/15 dark:bg-indigo-950/20 scale-[1.03]"
                  : "neu-flat hover:neu-inset text-brand-on-variant dark:text-gray-400"
              }`}
            >
              <span className="text-[10px] font-medium uppercase font-mono tracking-wider">{d.day}</span>
              <span className={`text-base font-extrabold ${selectedDay === d.date ? "text-brand-primary dark:text-indigo-400" : "text-brand-on-surface dark:text-gray-100"}`}>
                {d.date}
              </span>
              {d.current && (
                <div className="w-1.5 h-1.5 rounded-full bg-rose-500 animate-ping" />
              )}
            </button>
          ))}
        </div>
      </div>

      {/* Classes Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left Columns - Timeline Classes */}
        <div className="lg:col-span-2 space-y-6">
          <div className="p-6 rounded-2xl neu-flat space-y-6">
            <h2 className="text-lg font-bold text-brand-on-surface dark:text-gray-100 flex items-center gap-2">
              <Clock size={18} className="text-brand-primary dark:text-indigo-400" />
              {selectedDay === 30 ? "Today's Timetable" : `Classes for July ${selectedDay}`}
            </h2>

            {scheduleView === "daily" ? (
              <div className="relative border-l border-brand-container dark:border-brand-dark-container ml-3 pl-6 space-y-8 py-2">
                {WEEKLY_SCHEDULE.map((cls) => (
                  <div key={cls.id} className="relative">
                    {/* Circle bullet node */}
                    <div className={`absolute -left-[30px] top-1.5 w-4 h-4 rounded-full border-4 border-brand-surface dark:border-brand-dark-bg ${
                      cls.active ? "bg-brand-primary dark:bg-indigo-400 ring-4 ring-indigo-500/20" : "bg-brand-surface-dim dark:bg-slate-700"
                    }`} />

                    <div className={`p-5 rounded-xl transition-all ${
                      cls.active ? "neu-inset border-l-4 border-brand-primary" : "neu-flat hover:neu-inset"
                    }`}>
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                        <div>
                          <div className="text-xs font-mono font-bold uppercase tracking-wide text-brand-on-variant dark:text-gray-400 flex items-center gap-2">
                            {cls.time} {cls.period} • {cls.duration}
                            {cls.active && (
                              <span className="text-[9px] bg-rose-500 text-white font-extrabold px-1.5 py-0.5 rounded-full uppercase tracking-wider animate-pulse">
                                Live Now
                              </span>
                            )}
                          </div>
                          <h3 className="text-base font-bold text-brand-on-surface dark:text-gray-100 mt-1">{cls.subject}</h3>
                        </div>

                        {cls.active ? (
                          <a
                            href="https://meet.google.com"
                            target="_blank"
                            rel="noreferrer"
                            className="text-xs font-bold px-3 py-2 rounded-lg bg-brand-primary hover:bg-brand-primary-container text-white shadow-md transition-all flex items-center gap-1.5 cursor-pointer self-start sm:self-auto"
                          >
                            Join Online Session
                          </a>
                        ) : (
                          <button className="text-[10px] font-bold px-2.5 py-1.5 rounded-md neu-flat hover:neu-inset text-indigo-600 dark:text-indigo-400 cursor-pointer">
                            Lecture Slides
                          </button>
                        )}
                      </div>

                      <div className="grid grid-cols-2 gap-4 mt-4 pt-3 border-t border-brand-container/50 dark:border-brand-dark-container/50 text-xs">
                        <div className="flex items-center gap-1.5 text-brand-on-variant dark:text-gray-400">
                          <User size={14} className="text-gray-400" />
                          <span>{cls.instructor}</span>
                        </div>
                        <div className="flex items-center gap-1.5 text-brand-on-variant dark:text-gray-400 font-mono">
                          <MapPin size={14} className="text-gray-400" />
                          <span>{cls.room}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              // Weekly grid view
              <div className="space-y-4">
                <div className="grid grid-cols-5 gap-3 text-center text-xs font-mono font-bold text-brand-on-variant dark:text-gray-400 border-b pb-2">
                  <div>Mon</div>
                  <div>Tue</div>
                  <div>Wed</div>
                  <div>Thu</div>
                  <div>Fri</div>
                </div>
                <div className="grid grid-cols-5 gap-3">
                  {/* Mock grid blocks */}
                  {Array.from({ length: 15 }).map((_, idx) => (
                    <div 
                      key={idx} 
                      className={`p-2.5 rounded-lg text-[10px] text-center font-semibold ${
                        idx === 1 || idx === 6 || idx === 11 
                          ? "neu-inset border-l-2 border-brand-primary text-brand-primary dark:text-indigo-400 bg-indigo-50/10 dark:bg-indigo-950/25" 
                          : "neu-flat opacity-60 hover:opacity-100"
                      }`}
                    >
                      {idx === 1 ? "Math" : idx === 6 ? "Physics" : idx === 11 ? "Neuro" : "Free"}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Right Column - Holidays, attendance streak, message tutor */}
        <div className="space-y-8">
          {/* Attendance Streak Circle Indicator */}
          <div className="p-6 rounded-2xl neu-flat text-center space-y-4 relative overflow-hidden">
            <div className="absolute top-2 right-2">
              <Award className="text-amber-500 animate-pulse-slow" size={24} />
            </div>
            <div className="space-y-1">
              <span className="text-[10px] font-mono font-bold bg-amber-500/10 text-amber-600 dark:text-amber-400 px-2 py-0.5 rounded-full uppercase tracking-wider">
                Fortnight Streak
              </span>
              <h3 className="font-extrabold text-base text-brand-on-surface dark:text-gray-100 mt-2">Attendance Milestone</h3>
              <p className="text-xs text-brand-on-variant dark:text-gray-400 leading-relaxed px-2">
                Incredible discipline! You have completed **14 consecutive classes** in a row without missing a roll call. Keep it up!
              </p>
            </div>

            {/* Attendance Milestone Streak Badge layout */}
            <div className="flex items-center justify-center gap-4 mt-2">
              <div className="px-3 py-1.5 rounded-xl neu-inset text-center">
                <span className="text-[9px] text-brand-on-variant dark:text-gray-400 uppercase font-bold font-mono">Streak</span>
                <div className="text-base font-extrabold text-amber-500">14 Days</div>
              </div>
              <div className="px-3 py-1.5 rounded-xl neu-inset text-center">
                <span className="text-[9px] text-brand-on-variant dark:text-gray-400 uppercase font-bold font-mono">Efficiency</span>
                <div className="text-base font-extrabold text-emerald-600 dark:text-emerald-400">100%</div>
              </div>
            </div>
          </div>

          {/* Next Holidays list */}
          <div className="p-6 rounded-2xl neu-flat space-y-4">
            <h3 className="font-bold text-brand-on-surface dark:text-gray-100 flex items-center gap-2 text-md">
              <Coffee size={16} className="text-brand-primary dark:text-indigo-400" />
              Upcoming Campus Holidays
            </h3>

            <div className="space-y-3">
              <div className="p-3 rounded-xl neu-inset flex items-center justify-between">
                <div>
                  <h4 className="text-xs font-bold text-brand-on-surface dark:text-gray-100">Independence Day Recess</h4>
                  <p className="text-[10px] text-brand-on-variant dark:text-gray-400 font-mono mt-0.5">July 04, 2026 • Saturday</p>
                </div>
                <span className="text-[9px] font-mono font-semibold bg-indigo-500/10 text-brand-primary dark:text-indigo-400 px-2 py-0.5 rounded">
                  1 day
                </span>
              </div>

              <div className="p-3 rounded-xl neu-inset flex items-center justify-between">
                <div>
                  <h4 className="text-xs font-bold text-brand-on-surface dark:text-gray-100">Mid-Semester Summer Break</h4>
                  <p className="text-[10px] text-brand-on-variant dark:text-gray-400 font-mono mt-0.5">July 15 - July 20, 2026</p>
                </div>
                <span className="text-[9px] font-mono font-semibold bg-indigo-500/10 text-brand-primary dark:text-indigo-400 px-2 py-0.5 rounded">
                  6 days
                </span>
              </div>
            </div>
          </div>

          {/* Secure Message to Tutor form */}
          <div className="p-6 rounded-2xl neu-flat space-y-4" id="tutor-form">
            <h3 className="font-bold text-brand-on-surface dark:text-gray-100 flex items-center gap-2 text-md">
              <MessageSquare size={16} className="text-brand-primary dark:text-indigo-400" />
              Secure Memo to Tutor
            </h3>

            <AnimatePresence>
              {sendSuccess ? (
                <motion.div
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  className="p-4 bg-emerald-500/10 border border-emerald-500/20 rounded-xl text-center space-y-1.5 text-emerald-600 dark:text-emerald-400"
                >
                  <CheckCircle size={24} className="mx-auto" />
                  <div className="text-xs font-bold">Memo Transmitted Successfully!</div>
                  <div className="text-[10px]">A secure academic log copy has been routed to your portal mailbox.</div>
                </motion.div>
              ) : (
                <form onSubmit={handleSendMemo} className="space-y-3.5">
                  <div className="space-y-1">
                    <label className="text-[10px] font-mono font-bold uppercase text-brand-on-variant dark:text-gray-400">Target Instructor</label>
                    <select
                      value={selectedTutor}
                      onChange={(e) => setSelectedTutor(e.target.value)}
                      className="w-full text-xs p-2.5 rounded-xl neu-inset bg-brand-surface dark:bg-brand-dark-surface dark:text-gray-100 focus:outline-none"
                      required
                    >
                      <option value="">Select a tutor...</option>
                      {tutors.map((t) => (
                        <option key={t.name} value={t.name}>{t.name} ({t.subject})</option>
                      ))}
                    </select>
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-mono font-bold uppercase text-brand-on-variant dark:text-gray-400">Subject Log</label>
                    <input
                      type="text"
                      value={memoSubject}
                      onChange={(e) => setMemoSubject(e.target.value)}
                      placeholder="e.g. Leave request, doubt clearance request..."
                      className="w-full text-xs p-2.5 rounded-xl neu-inset bg-brand-surface dark:bg-brand-dark-surface dark:text-gray-100 focus:outline-none"
                      required
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-mono font-bold uppercase text-brand-on-variant dark:text-gray-400">Secure Message Payload</label>
                    <textarea
                      value={memoText}
                      onChange={(e) => setMemoText(e.target.value)}
                      rows={3}
                      placeholder="Write your brief academic message here..."
                      className="w-full text-xs p-2.5 rounded-xl neu-inset bg-brand-surface dark:bg-brand-dark-surface dark:text-gray-100 focus:outline-none resize-none"
                      required
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full py-2.5 bg-brand-primary hover:bg-brand-primary-container text-white text-xs font-bold rounded-xl transition-all shadow-md flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <Send size={13} /> Transmit Encrypted Memo
                  </button>
                </form>
              )}
            </AnimatePresence>
          </div>
        </div>
      </div>
    </div>
  );
}
