import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Award, 
  TrendingUp, 
  BookOpen, 
  Download, 
  ChevronDown, 
  ChevronUp, 
  Sparkles, 
  BrainCircuit, 
  Activity, 
  Sliders, 
  Lightbulb,
  CheckCircle2
} from "lucide-react";
import { SUBJECT_ATTENDANCE } from "../data";

export default function GradesScreen() {
  const [expandedSem, setExpandedSem] = useState<number | null>(4); // Sem 4 expanded by default
  
  // CGPA Predictor states
  const [targetGpa, setTargetGpa] = useState(3.85);
  const [studyHours, setStudyHours] = useState(20);
  const [attendance, setAttendance] = useState(88);
  const [predictionResult, setPredictionResult] = useState<string>("");
  const [isPredicting, setIsPredicting] = useState(false);

  // Run initial mock prediction on load to populate the tip
  useEffect(() => {
    handleRunPrediction();
  }, []);

  const handleRunPrediction = async () => {
    setIsPredicting(true);
    setPredictionResult("");
    
    try {
      const response = await fetch("/api/predict-gpa", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          targetGpa,
          studyHours,
          currentGpa: 3.72,
          attendance
        })
      });
      const data = await response.json();
      setIsPredicting(false);
      
      if (data.error) {
        setPredictionResult(`💡 Counsel Hint: To hit your target CGPA of ${targetGpa.toFixed(2)}, focus on scoring consistent A grades in Advanced Mathematics and maintaining at least 90% attendance. Your current pacing is solid!`);
      } else {
        setPredictionResult(data.tip || "Prediction failed.");
      }
    } catch (err) {
      setIsPredicting(false);
      setPredictionResult(`💡 Counsel Hint: Achieving ${targetGpa.toFixed(2)} requires roughly ${Math.ceil(studyHours * 1.15)} hours of structured review weekly. Focus heavily on your high-weightage math midterm.`);
    }
  };

  const semGrades = [
    {
      semester: 4,
      gpa: 3.72,
      credits: 22,
      courses: [
        { name: "Advanced Mathematics", code: "MTH-401", grade: "A-", credits: 4, type: "Theory" },
        { name: "Quantum Physics Lab", code: "PHY-402L", grade: "A+", credits: 2, type: "Practical" },
        { name: "Cognitive Neuroscience", code: "NEU-405", grade: "B+", credits: 3, type: "Theory" },
        { name: "Data Structures & Algorithms", code: "CSE-409", grade: "A", credits: 4, type: "Theory" },
        { name: "Software Engineering", code: "SWE-412", grade: "A", credits: 4, type: "Theory" }
      ]
    },
    {
      semester: 3,
      gpa: 3.81,
      credits: 20,
      courses: [
        { name: "Discrete Structures", code: "CSE-301", grade: "A+", credits: 4 },
        { name: "Database Management Systems", code: "CSE-303", grade: "A", credits: 4 },
        { name: "Computer Architecture", code: "CSE-305", grade: "A-", credits: 3 },
        { name: "Operating Systems Lab", code: "CSE-307L", grade: "A+", credits: 2 },
        { name: "Human Psychology Intro", code: "NEU-311", grade: "A", credits: 3 }
      ]
    },
    {
      semester: 2,
      gpa: 3.65,
      credits: 22,
      courses: [
        { name: "Calculus & Algebra", code: "MTH-201", grade: "B+", credits: 4 },
        { name: "Digital Logic Design", code: "CSE-202", grade: "A", credits: 4 },
        { name: "Object Oriented Programming", code: "CSE-204", grade: "A+", credits: 4 },
        { name: "Physics of Semiconductors", code: "PHY-201", grade: "A-", credits: 3 }
      ]
    },
    {
      semester: 1,
      gpa: 3.54,
      credits: 20,
      courses: [
        { name: "Basic Electrical Eng", code: "EE-101", grade: "B", credits: 4 },
        { name: "Programming in C", code: "CSE-101", grade: "A+", credits: 4 },
        { name: "Engineering Chemistry", code: "CHY-101", grade: "A-", credits: 3 },
        { name: "Environmental Sciences", code: "EVS-101", grade: "A", credits: 2 }
      ]
    }
  ];

  // SVG Line Chart coordinates for GPA Trend
  // Coordinates are designed to scale smoothly on an 400x120 viewport
  // Data: Sem 1 (3.54), Sem 2 (3.65), Sem 3 (3.81), Sem 4 (3.72)
  const chartPoints = "30,90  140,75  250,45  360,60";

  return (
    <div className="space-y-8 pb-10" id="grades-root">
      {/* Header section */}
      <div>
        <h1 className="text-2xl font-bold font-sans text-brand-on-surface dark:text-gray-100 flex items-center gap-2">
          <Award size={24} className="text-brand-primary dark:text-indigo-400" />
          Academics &amp; Grade Management
        </h1>
        <p className="text-xs text-brand-on-variant dark:text-gray-400 mt-1">Track final evaluations, transcript status, and run intelligent performance forecasts.</p>
      </div>

      {/* Overview stats block & trend line graph */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left Column: Stats & Trend Chart */}
        <div className="lg:col-span-2 space-y-6">
          <div className="p-6 rounded-2xl neu-flat space-y-6">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-brand-on-surface dark:text-gray-100 flex items-center gap-2 text-md">
                <TrendingUp size={18} className="text-brand-primary dark:text-indigo-400" />
                Semester GPA Trend
              </h3>
              <span className="text-[10px] font-mono font-bold bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 px-2 py-0.5 rounded-full uppercase">
                CGPA Progress Track
              </span>
            </div>

            {/* Custom SVG Line Chart */}
            <div className="p-4 rounded-xl neu-inset bg-brand-surface dark:bg-brand-dark-low relative h-44 flex items-end">
              <svg className="w-full h-full" viewBox="0 0 400 120" preserveAspectRatio="none">
                {/* Horizontal reference lines */}
                <line x1="10" y1="20" x2="390" y2="20" stroke="rgba(163, 177, 198, 0.15)" strokeWidth="1" strokeDasharray="4" />
                <line x1="10" y1="55" x2="390" y2="55" stroke="rgba(163, 177, 198, 0.15)" strokeWidth="1" strokeDasharray="4" />
                <line x1="10" y1="90" x2="390" y2="90" stroke="rgba(163, 177, 198, 0.15)" strokeWidth="1" strokeDasharray="4" />

                {/* Shaded Area under the line */}
                <path 
                  d="M 30,120 L 30,90 L 140,75 L 250,45 L 360,60 L 360,120 Z" 
                  fill="url(#gpaGrad)" 
                  opacity="0.15"
                />

                {/* Line Path */}
                <polyline
                  fill="none"
                  stroke="var(--color-brand-primary)"
                  strokeWidth="3.5"
                  strokeLinecap="round"
                  points={chartPoints}
                  className="drop-shadow-md"
                />

                {/* Data point dots and text overlays */}
                <g>
                  {/* Sem 1 */}
                  <circle cx="30" cy="90" r="5" fill="var(--color-brand-primary)" stroke="#ffffff" strokeWidth="1.5" />
                  <text x="30" y="115" className="text-[9px] font-mono font-bold" fill="var(--color-brand-on-surface)" textAnchor="middle">SEM 1</text>
                  <text x="30" y="75" className="text-[10px] font-bold" fill="var(--color-brand-primary)" textAnchor="middle">3.54</text>

                  {/* Sem 2 */}
                  <circle cx="140" cy="75" r="5" fill="var(--color-brand-primary)" stroke="#ffffff" strokeWidth="1.5" />
                  <text x="140" y="115" className="text-[9px] font-mono font-bold" fill="var(--color-brand-on-surface)" textAnchor="middle">SEM 2</text>
                  <text x="140" y="60" className="text-[10px] font-bold" fill="var(--color-brand-primary)" textAnchor="middle">3.65</text>

                  {/* Sem 3 */}
                  <circle cx="250" cy="45" r="5" fill="var(--color-brand-primary)" stroke="#ffffff" strokeWidth="1.5" />
                  <text x="250" y="115" className="text-[9px] font-mono font-bold" fill="var(--color-brand-on-surface)" textAnchor="middle">SEM 3</text>
                  <text x="250" y="30" className="text-[10px] font-extrabold" fill="var(--color-brand-primary)" textAnchor="middle">3.81</text>

                  {/* Sem 4 */}
                  <circle cx="360" cy="60" r="5" fill="var(--color-brand-primary)" stroke="#ffffff" strokeWidth="1.5" />
                  <text x="360" y="115" className="text-[9px] font-mono font-bold" fill="var(--color-brand-on-surface)" textAnchor="middle">SEM 4</text>
                  <text x="360" y="45" className="text-[10px] font-bold" fill="var(--color-brand-primary)" textAnchor="middle">3.72</text>
                </g>

                {/* Gradient Definition */}
                <defs>
                  <linearGradient id="gpaGrad" x1="0%" y1="0%" x2="0%" y2="100%">
                    <stop offset="0%" stopColor="var(--color-brand-primary)" />
                    <stop offset="100%" stopColor="rgba(255, 255, 255, 0)" />
                  </linearGradient>
                </defs>
              </svg>
            </div>

            {/* GPA indicators breakdown */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 pt-2">
              <div className="p-3.5 rounded-xl neu-inset text-center">
                <div className="text-[9px] font-bold uppercase tracking-wider text-brand-on-variant dark:text-gray-400 font-mono">Current CGPA</div>
                <div className="text-xl font-extrabold text-brand-primary dark:text-indigo-400 mt-1">3.72</div>
              </div>
              <div className="p-3.5 rounded-xl neu-inset text-center">
                <div className="text-[9px] font-bold uppercase tracking-wider text-brand-on-variant dark:text-gray-400 font-mono">Total Credits</div>
                <div className="text-xl font-extrabold text-brand-on-surface dark:text-gray-100 mt-1">84 / 160</div>
              </div>
              <div className="p-3.5 rounded-xl neu-inset text-center">
                <div className="text-[9px] font-bold uppercase tracking-wider text-brand-on-variant dark:text-gray-400 font-mono">Major Ranking</div>
                <div className="text-xl font-extrabold text-amber-500 mt-1">#12 / 128</div>
              </div>
              <div className="p-3.5 rounded-xl neu-inset text-center">
                <div className="text-[9px] font-bold uppercase tracking-wider text-brand-on-variant dark:text-gray-400 font-mono">Honors Standing</div>
                <div className="text-xs font-extrabold text-emerald-600 dark:text-emerald-400 mt-2 flex items-center justify-center gap-1">
                  <CheckCircle2 size={12} /> First Class
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: AI-Enabled CGPA Predictor */}
        <div className="space-y-6">
          <div className="p-6 rounded-2xl neu-flat space-y-4">
            <h3 className="font-bold text-brand-on-surface dark:text-gray-100 flex items-center gap-2 text-md">
              <BrainCircuit size={18} className="text-brand-primary dark:text-indigo-400" />
              Smart CGPA Forecast
            </h3>
            <p className="text-[11px] text-brand-on-variant dark:text-gray-400 leading-relaxed">
              Adjust sliders below to input your planned targets. Gemini acts as an academic counselor modeling your performance probability.
            </p>

            <div className="space-y-4 pt-2">
              {/* Target GPA Slider */}
              <div className="space-y-1.5">
                <div className="flex justify-between text-[10px] font-mono font-bold text-brand-on-variant dark:text-gray-400">
                  <span>TARGET CGPA</span>
                  <span className="text-brand-primary dark:text-indigo-400">{targetGpa.toFixed(2)}</span>
                </div>
                <input 
                  type="range" 
                  min="3.00" 
                  max="4.00" 
                  step="0.01"
                  value={targetGpa} 
                  onChange={(e) => setTargetGpa(parseFloat(e.target.value))}
                  className="w-full accent-brand-primary h-1 rounded-full bg-gray-200 dark:bg-gray-800"
                />
              </div>

              {/* Study Hours Slider */}
              <div className="space-y-1.5">
                <div className="flex justify-between text-[10px] font-mono font-bold text-brand-on-variant dark:text-gray-400">
                  <span>WEEKLY STUDY HOURS</span>
                  <span className="text-brand-primary dark:text-indigo-400">{studyHours} Hours</span>
                </div>
                <input 
                  type="range" 
                  min="5" 
                  max="40" 
                  step="1"
                  value={studyHours} 
                  onChange={(e) => setStudyHours(parseInt(e.target.value))}
                  className="w-full accent-brand-primary h-1 rounded-full bg-gray-200 dark:bg-gray-800"
                />
              </div>

              {/* Planned Attendance Slider */}
              <div className="space-y-1.5">
                <div className="flex justify-between text-[10px] font-mono font-bold text-brand-on-variant dark:text-gray-400">
                  <span>TARGET ATTENDANCE</span>
                  <span className="text-brand-primary dark:text-indigo-400">{attendance}%</span>
                </div>
                <input 
                  type="range" 
                  min="75" 
                  max="100" 
                  step="1"
                  value={attendance} 
                  onChange={(e) => setAttendance(parseInt(e.target.value))}
                  className="w-full accent-brand-primary h-1 rounded-full bg-gray-200 dark:bg-gray-800"
                />
              </div>

              {/* Forecast trigger */}
              <button 
                onClick={handleRunPrediction}
                disabled={isPredicting}
                className="w-full py-2.5 bg-brand-primary hover:bg-brand-primary-container disabled:opacity-75 text-white text-xs font-bold rounded-xl transition-all shadow-md flex items-center justify-center gap-1.5 cursor-pointer"
              >
                {isPredicting ? (
                  <span className="w-4.5 h-4.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                ) : (
                  <>
                    <Sliders size={13} /> Compute Counselor Forecast
                  </>
                )}
              </button>

              {/* Forecast response smart tip */}
              <AnimatePresence mode="wait">
                {predictionResult && (
                  <motion.div 
                    initial={{ opacity: 0, y: 5 }} 
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0 }}
                    className="p-3.5 rounded-xl neu-inset bg-amber-500/5 border border-amber-500/10 flex gap-3 text-[11px] text-brand-on-surface dark:text-gray-200 leading-relaxed"
                  >
                    <Lightbulb className="text-amber-500 flex-shrink-0 mt-0.5" size={16} />
                    <div>
                      {predictionResult}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>
        </div>
      </div>

      {/* Semester lists */}
      <div className="space-y-4">
        <h3 className="font-bold text-brand-on-surface dark:text-gray-100 text-md flex items-center gap-2">
          <BookOpen size={18} className="text-brand-primary dark:text-indigo-400" />
          Detailed Academic Transcripts
        </h3>

        <div className="space-y-4">
          {semGrades.map((sem) => (
            <div key={sem.semester} className="rounded-2xl neu-flat overflow-hidden transition-all">
              {/* Header trigger block */}
              <button
                onClick={() => setExpandedSem(expandedSem === sem.semester ? null : sem.semester)}
                className="w-full p-5 flex items-center justify-between bg-brand-surface dark:bg-brand-dark-surface cursor-pointer text-left focus:outline-none"
              >
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 rounded-xl neu-inset flex items-center justify-center font-extrabold text-brand-primary dark:text-indigo-400">
                    S{sem.semester}
                  </div>
                  <div>
                    <h4 className="font-bold text-brand-on-surface dark:text-gray-100 text-sm">Semester {sem.semester} Transcript</h4>
                    <p className="text-[10px] text-brand-on-variant dark:text-gray-400 font-mono mt-0.5">{sem.credits} Total Credits Earned</p>
                  </div>
                </div>

                <div className="flex items-center gap-4">
                  <div className="px-3 py-1.5 rounded-lg neu-inset text-center">
                    <span className="text-[8px] text-brand-on-variant dark:text-gray-400 font-bold font-mono">GPA</span>
                    <div className="text-sm font-extrabold text-brand-primary dark:text-indigo-400">{sem.gpa.toFixed(2)}</div>
                  </div>
                  {expandedSem === sem.semester ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
                </div>
              </button>

              {/* Course list drawer */}
              <AnimatePresence>
                {expandedSem === sem.semester && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: "auto", opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    className="border-t border-brand-container dark:border-brand-dark-container bg-brand-surface-bright dark:bg-brand-dark-low"
                  >
                    <div className="p-5 space-y-3.5">
                      {sem.courses.map((course) => (
                        <div 
                          key={course.code} 
                          className="p-3.5 rounded-xl neu-inset flex items-center justify-between gap-4 text-xs"
                        >
                          <div>
                            <div className="font-semibold text-brand-on-surface dark:text-gray-100">{course.name}</div>
                            <div className="text-[10px] font-mono text-brand-on-variant dark:text-gray-400 mt-1">
                              {course.code} • {course.credits} Credits
                            </div>
                          </div>

                          <div className="flex items-center gap-4">
                            <span className="w-8 h-8 rounded-lg flex items-center justify-center font-bold bg-brand-primary/10 text-brand-primary dark:text-indigo-400 text-sm">
                              {course.grade}
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
