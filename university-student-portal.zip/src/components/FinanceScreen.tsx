import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  CreditCard, 
  DollarSign, 
  CheckCircle, 
  Lock, 
  ChevronRight, 
  Sparkles, 
  Download, 
  HelpCircle, 
  TrendingUp,
  Award
} from "lucide-react";
import { FinanceInstallment } from "../types";
import { FINANCE_INSTALLMENTS } from "../data";

export default function FinanceScreen() {
  const [installments, setInstallments] = useState<FinanceInstallment[]>(FINANCE_INSTALLMENTS);
  const [paidBalance, setPaidBalance] = useState(12500);
  const totalAnnual = 15000;

  // Pay checkout state
  const [payModalOpen, setPayModalOpen] = useState(false);
  const [selectedInst, setSelectedInst] = useState<FinanceInstallment | null>(null);
  const [cardNumber, setCardNumber] = useState("");
  const [cardExpiry, setCardExpiry] = useState("");
  const [cardCvv, setCardCvv] = useState("");
  const [isProcessing, setIsProcessing] = useState(false);
  const [isPaidSuccess, setIsPaidSuccess] = useState(false);

  const handleOpenPayment = (inst: FinanceInstallment) => {
    setSelectedInst(inst);
    setPayModalOpen(true);
  };

  const handlePaymentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!cardNumber || !cardExpiry || !cardCvv || !selectedInst) return;

    setIsProcessing(true);
    setTimeout(() => {
      setIsProcessing(false);
      setIsPaidSuccess(true);
      
      // Update local finance state
      setTimeout(() => {
        setInstallments(prevInsts => 
          prevInsts.map(inst => 
            inst.id === selectedInst.id 
              ? { ...inst, status: "Paid" as const } 
              : inst
          )
        );
        setPaidBalance(prev => prev + selectedInst.amount);
        setPayModalOpen(false);
        setIsPaidSuccess(false);
        setCardNumber("");
        setCardExpiry("");
        setCardCvv("");
        setSelectedInst(null);
      }, 1500);
    }, 1800);
  };

  return (
    <div className="space-y-8 pb-10" id="finance-root">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold font-sans text-brand-on-surface dark:text-gray-100 flex items-center gap-2">
          <DollarSign size={24} className="text-brand-primary dark:text-indigo-400" />
          Finance &amp; Fee Ledger
        </h1>
        <p className="text-xs text-brand-on-variant dark:text-gray-400 mt-1">Settle university tuition fees, track scholarships, and access electronic payment slips.</p>
      </div>

      {/* Main progress bar tuition tracker */}
      <div className="p-6 rounded-2xl neu-flat space-y-6">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
          <div>
            <span className="text-xs font-mono font-bold text-brand-on-variant dark:text-gray-400 uppercase">Annual Tuition Summary</span>
            <h2 className="text-xl font-bold text-brand-on-surface dark:text-gray-100 mt-1">83.3% Settle Rate</h2>
          </div>
          <div className="text-right sm:text-right">
            <span className="text-[10px] font-mono text-gray-400">Paid to date / Annual total</span>
            <div className="text-base font-extrabold text-brand-primary dark:text-indigo-400">
              ${paidBalance.toLocaleString()} <span className="text-brand-on-variant dark:text-gray-400 font-medium">/ ${totalAnnual.toLocaleString()}</span>
            </div>
          </div>
        </div>

        {/* Custom Progress Bar */}
        <div className="space-y-2">
          <div className="w-full bg-gray-200 dark:bg-gray-800 h-4 rounded-full overflow-hidden neu-inset p-0.5">
            <div 
              className="bg-brand-primary h-full rounded-full transition-all duration-1000"
              style={{ width: `${(paidBalance / totalAnnual) * 100}%` }}
            />
          </div>
          <div className="flex justify-between text-[10px] font-mono text-brand-on-variant dark:text-gray-400 font-bold">
            <span>START SEPT 2025</span>
            <span>MERIT AID DEDUCTION APPLIED</span>
            <span>END JULY 2026</span>
          </div>
        </div>
      </div>

      {/* Grid splits */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left Column: Tuition Installments Table */}
        <div className="lg:col-span-2 space-y-6">
          <div className="p-6 rounded-2xl neu-flat space-y-4">
            <h3 className="font-bold text-brand-on-surface dark:text-gray-100 text-md">Installment Schedule &amp; Dues</h3>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="border-b border-brand-container dark:border-slate-800 text-brand-on-variant dark:text-gray-400 font-bold">
                    <th className="py-3 px-2">Installment Term</th>
                    <th className="py-3 px-2 text-center">Amount Due</th>
                    <th className="py-3 px-2 text-center">Due Deadline</th>
                    <th className="py-3 px-2 text-right">Settlement State</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-brand-container/40 dark:divide-slate-800/40">
                  {installments.map((inst) => (
                    <tr key={inst.id} className="text-brand-on-surface dark:text-gray-200 hover:bg-slate-50/20 dark:hover:bg-slate-900/10">
                      <td className="py-3 px-2 font-semibold">{inst.name}</td>
                      <td className="py-3 px-2 text-center font-bold font-mono">${inst.amount.toLocaleString()}</td>
                      <td className="py-3 px-2 text-center font-mono text-[11px] text-gray-400">{inst.dueDate}</td>
                      <td className="py-3 px-2 text-right">
                        {inst.status === "Paid" ? (
                          <span className="text-[10px] font-bold bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 px-2 py-0.5 rounded-full uppercase">
                            ✓ Paid Settle
                          </span>
                        ) : (
                          <button
                            onClick={() => handleOpenPayment(inst)}
                            className="text-[10px] font-bold bg-rose-500 hover:bg-rose-600 text-white px-3 py-1 rounded-lg transition-all shadow cursor-pointer"
                          >
                            Pay Dues
                          </button>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Right Column: Scholarship Aid & upcoming timelines */}
        <div className="space-y-8">
          {/* Merit Scholarship Details card */}
          <div className="p-6 rounded-2xl neu-flat space-y-4 relative overflow-hidden">
            <div className="absolute top-2 right-2">
              <Award className="text-amber-500 animate-pulse-slow" size={24} />
            </div>
            <div className="space-y-1">
              <span className="text-[10px] font-mono font-bold bg-amber-500/10 text-amber-600 dark:text-amber-400 px-2 py-0.5 rounded-full uppercase tracking-wider">
                Merit Award Holder
              </span>
              <h3 className="font-extrabold text-base text-brand-on-surface dark:text-gray-100 mt-2">Academic Scholarship</h3>
              <p className="text-xs text-brand-on-variant dark:text-gray-400 leading-relaxed">
                Congratulations! Due to maintaining a CGPA above 3.50, a **$1,200 credit discount** has been pre-applied towards your semester tuition fee records.
              </p>
            </div>

            <div className="p-3.5 rounded-xl neu-inset bg-amber-500/5 text-center text-xs font-mono font-bold text-amber-600 dark:text-amber-400 border border-amber-500/10">
              SCHOLARSHIP CREDIT: -$1,200.00
            </div>
          </div>

          {/* Secure gateway trust indicator */}
          <div className="p-6 rounded-2xl neu-flat space-y-4">
            <h3 className="font-bold text-brand-on-surface dark:text-gray-100 flex items-center gap-2 text-md">
              <Lock size={16} className="text-emerald-500" />
              Secure Digital Invoices
            </h3>
            <p className="text-xs text-brand-on-variant dark:text-gray-400 leading-relaxed">
              All electronic transactions are processed with 256-bit bank-grade encryption protocols.
            </p>

            <button
              onClick={() => {
                const blob = new Blob(["Tuition ledger details Austin Reaves -CSE-2024-048"], { type: "text/plain" });
                const url = URL.createObjectURL(blob);
                const a = document.createElement("a");
                a.href = url;
                a.download = "Tuition-Invoice-AustinReaves.pdf";
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
              }}
              className="w-full py-2.5 rounded-xl neu-button hover:bg-slate-50 text-brand-primary dark:text-indigo-400 text-xs font-bold transition-all shadow flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <Download size={13} /> Download PDF Receipt
            </button>
          </div>
        </div>
      </div>

      {/* SECURE GATEWAY CHECKOUT OVERLAY */}
      <AnimatePresence>
        {payModalOpen && selectedInst && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-xs">
            <motion.div 
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="w-full max-w-md rounded-2xl p-6 neu-flat bg-brand-surface dark:bg-brand-dark-surface space-y-6 relative border border-white/10 shadow-2xl"
              id="checkout-panel"
            >
              <div className="flex items-center justify-between pb-3 border-b border-brand-container dark:border-slate-800">
                <div className="flex items-center gap-2">
                  <Lock className="text-emerald-500" size={16} />
                  <h3 className="font-bold text-brand-on-surface dark:text-gray-100 text-base">Authorize Payment Session</h3>
                </div>
                <button 
                  onClick={() => setPayModalOpen(false)}
                  className="w-7 h-7 rounded-full flex items-center justify-center neu-button hover:bg-rose-50 text-rose-600 font-bold cursor-pointer"
                >
                  &times;
                </button>
              </div>

              {isPaidSuccess ? (
                <div className="py-6 text-center space-y-3 text-emerald-600 dark:text-emerald-400">
                  <CheckCircle size={40} className="mx-auto" />
                  <div className="text-md font-bold">Transaction Confirmed!</div>
                  <p className="text-xs">Installment successfully processed. Your Tuition Balance is updated in real time.</p>
                </div>
              ) : (
                <form onSubmit={handlePaymentSubmit} className="space-y-4">
                  <div className="p-3 rounded-xl neu-inset text-center bg-indigo-50/20 dark:bg-slate-900/45">
                    <span className="text-[10px] font-mono text-brand-on-variant dark:text-gray-400 uppercase">{selectedInst.name} Dues</span>
                    <div className="text-xl font-extrabold text-brand-primary dark:text-indigo-400">${selectedInst.amount.toLocaleString()}</div>
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-mono font-bold uppercase text-brand-on-variant dark:text-gray-400">Credit Card Number</label>
                    <div className="relative">
                      <CreditCard className="absolute left-3.5 top-3.5 text-gray-400" size={16} />
                      <input 
                        type="text" 
                        value={cardNumber}
                        onChange={(e) => setCardNumber(e.target.value)}
                        placeholder="4111 2222 3333 4444" 
                        maxLength={19}
                        className="w-full text-xs py-3 pl-10 pr-3.5 rounded-xl neu-inset bg-brand-surface dark:bg-brand-dark-surface dark:text-gray-100 focus:outline-none font-mono"
                        required
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <label className="text-[10px] font-mono font-bold uppercase text-brand-on-variant dark:text-gray-400">Expiry</label>
                      <input 
                        type="text" 
                        value={cardExpiry}
                        onChange={(e) => setCardExpiry(e.target.value)}
                        placeholder="MM/YY" 
                        maxLength={5}
                        className="w-full text-xs p-3 rounded-xl neu-inset bg-brand-surface dark:bg-brand-dark-surface dark:text-gray-100 focus:outline-none text-center font-mono"
                        required
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[10px] font-mono font-bold uppercase text-brand-on-variant dark:text-gray-400">CVV Code</label>
                      <input 
                        type="password" 
                        value={cardCvv}
                        onChange={(e) => setCardCvv(e.target.value)}
                        placeholder="•••" 
                        maxLength={3}
                        className="w-full text-xs p-3 rounded-xl neu-inset bg-brand-surface dark:bg-brand-dark-surface dark:text-gray-100 focus:outline-none text-center font-mono"
                        required
                      />
                    </div>
                  </div>

                  <button
                    type="submit"
                    disabled={isProcessing}
                    className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-80 text-white rounded-xl text-xs font-bold transition-all shadow-md flex items-center justify-center gap-2 cursor-pointer"
                  >
                    {isProcessing ? (
                      <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    ) : (
                      <>
                        <Lock size={13} /> Authorize Tuition Fee Remit
                      </>
                    )}
                  </button>
                </form>
              )}
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
