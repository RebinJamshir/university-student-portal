import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Home, 
  Calendar, 
  UserCheck, 
  FileText, 
  Award, 
  Upload, 
  BookOpen, 
  Plus, 
  CheckCircle, 
  Clock, 
  AlertCircle, 
  Sparkles, 
  ChevronRight, 
  Save, 
  BookOpenCheck,
  ExternalLink,
  ChevronLeft,
  X,
  Send,
  Eye,
  Trash2,
  Lock,
  Check
} from "lucide-react";
import { 
  Profile, 
  Subject, 
  Department, 
  Enrollment, 
  AttendanceRecord, 
  Assignment, 
  AssignmentSubmission, 
  Exam, 
  ExamMark, 
  AuditLog 
} from "../types";

interface TeacherDashboardProps {
  currentTeacher: Profile;
  profiles: Profile[];
  subjects: Subject[];
  departments: Department[];
  enrollments: Enrollment[];
  attendance: AttendanceRecord[];
  onAddAttendance: (records: AttendanceRecord[]) => void;
  assignments: Assignment[];
  onAddAssignment: (assignment: Assignment) => void;
  submissions: AssignmentSubmission[];
  onGradeSubmission: (submissionId: string, score: number, feedback: string, teacherName: string) => void;
  exams: Exam[];
  onAddExam: (exam: Exam) => void;
  examMarks: ExamMark[];
  onSaveExamMark: (marks: ExamMark[]) => void;
  onPublishExamMarks: (subjectCode: string, examName: string) => void;
  digitalAssets: any[];
  onAddDigitalAsset: (asset: any) => void;
  auditLogs: AuditLog[];
  onAddAuditLog: (action: string, entity: string, entityType: string, metadata?: string) => void;
}

export default function TeacherDashboard({
  currentTeacher,
  profiles,
  subjects,
  departments,
  enrollments,
  attendance,
  onAddAttendance,
  assignments,
  onAddAssignment,
  submissions,
  onGradeSubmission,
  exams,
  onAddExam,
  examMarks,
  onSaveExamMark,
  onPublishExamMarks,
  digitalAssets,
  onAddDigitalAsset,
  auditLogs,
  onAddAuditLog
}: TeacherDashboardProps) {
  const [activeSubTab, setActiveSubTab] = useState<string>("Overview");

  // State for forms/selectors
  const [selectedSubject, setSelectedSubject] = useState<string>("");
  const [selectedDate, setSelectedDate] = useState<string>(new Date().toISOString().split("T")[0]);
  const [attendanceRoster, setAttendanceRoster] = useState<{ studentId: string; name: string; roll: string; status: "Present" | "Absent" | "No Class" }[]>([]);
  const [attendanceSavedNote, setAttendanceSavedNote] = useState<string | null>(null);

  // New Assignment State
  const [newAssignTitle, setNewAssignTitle] = useState("");
  const [newAssignSubject, setNewAssignSubject] = useState("");
  const [newAssignDesc, setNewAssignDesc] = useState("");
  const [newAssignDueDate, setNewAssignDueDate] = useState("");
  const [newAssignMaxScore, setNewAssignMaxScore] = useState(100);
  const [newAssignAllowLate, setNewAssignAllowLate] = useState(true);
  const [assignFormMsg, setAssignFormMsg] = useState<string | null>(null);

  // Active Assignment Submissions grading state
  const [selectedAssignmentId, setSelectedAssignmentId] = useState<string | null>(null);
  const [activeSubmissionId, setActiveSubmissionId] = useState<string | null>(null);
  const [gradeScore, setGradeScore] = useState<number>(0);
  const [gradeFeedback, setGradeFeedback] = useState<string>("");
  const [gradeSuccessMsg, setGradeSuccessMsg] = useState<string | null>(null);

  // Mark entry sheet state
  const [marksSubjectCode, setMarksSubjectCode] = useState<string>("");
  const [marksExamName, setMarksExamName] = useState<string>("Mid-Term Examination");
  const [marksRoster, setMarksRoster] = useState<{ studentId: string; name: string; score: number; maxScore: number }[]>([]);
  const [marksStatusMsg, setMarksStatusMsg] = useState<string | null>(null);
  const [confirmPublish, setConfirmPublish] = useState<boolean>(false);

  // Resource Upload State
  const [resourceName, setResourceName] = useState("");
  const [resourceFormat, setResourceFormat] = useState<"pdf" | "epub" | "doc">("pdf");
  const [resourceSubject, setResourceSubject] = useState("");
  const [resourceSize, setResourceSize] = useState("1.8 MB");
  const [resourceMsg, setResourceMsg] = useState<string | null>(null);

  // Exam Scheduling State
  const [examSubject, setExamSubject] = useState("");
  const [examDate, setExamDate] = useState("");
  const [examTime, setExamTime] = useState("09:00 AM");
  const [examRoom, setExamRoom] = useState("Lecture Hall C");
  const [examInst, setExamInst] = useState("");
  const [examMsg, setExamMsg] = useState<string | null>(null);

  // Teacher specific subjects list (Dr. Emily Ross teaches Advanced Mathematics, Sarah Vance teaches Cognitive Neuroscience, Turing teaches SWE & DSA, Stern teaches Quantum Physics)
  const teacherSubjects = subjects.filter(sub => {
    if (currentTeacher.id === "teacher-ross") return sub.code === "MTH-401";
    if (currentTeacher.id === "teacher-vance") return sub.code === "NEU-405";
    if (currentTeacher.id === "teacher-stern") return sub.code === "PHY-402L";
    if (currentTeacher.id === "teacher-turing") return sub.code === "CSE-409" || sub.code === "SWE-412";
    return true; // fallback
  });

  const allStudents = profiles.filter(p => p.role === "student");

  // Attendance loading helper
  const loadAttendanceRoster = (subjectCode: string, dateStr: string) => {
    if (!subjectCode) return;
    // Get students enrolled in this subject
    const enrolledStudents = enrollments
      .filter(e => e.subjectCode === subjectCode)
      .map(e => profiles.find(p => p.id === e.studentId))
      .filter(p => p !== undefined) as Profile[];

    // Check if attendance already recorded for this subject + date
    const recordedMap = new Map<string, "Present" | "Absent" | "No Class" | undefined>();
    const recordedRecords = attendance.filter(a => a.subjectCode === subjectCode && a.date === dateStr);
    recordedRecords.forEach(rec => {
      recordedMap.set(rec.studentId, rec.status);
    });

    const roster = enrolledStudents.map(student => ({
      studentId: student.id,
      name: student.name,
      roll: student.rollNumber || "N/A",
      status: recordedMap.get(student.id) || "Present" // bulk present by default!
    }));

    setAttendanceRoster(roster);
  };

  // Mark Roster Loader
  const loadMarksRoster = (subjectCode: string, examName: string) => {
    if (!subjectCode) return;
    const enrolledStudents = enrollments
      .filter(e => e.subjectCode === subjectCode)
      .map(e => profiles.find(p => p.id === e.studentId))
      .filter(p => p !== undefined) as Profile[];

    const roster = enrolledStudents.map(student => {
      // Check if mark already exists
      const existing = examMarks.find(m => m.subjectCode === subjectCode && m.studentId === student.id && m.examName === examName);
      return {
        studentId: student.id,
        name: student.name,
        score: existing ? existing.score : 0,
        maxScore: existing ? existing.maxScore : 50
      };
    });

    setMarksRoster(roster);
  };

  // Submit attendance
  const handleSaveAttendance = () => {
    if (!selectedSubject) return;
    
    const recordsToInsert: AttendanceRecord[] = attendanceRoster.map(r => ({
      id: `att-rec-${Date.now()}-${r.studentId}`,
      studentId: r.studentId,
      subjectCode: selectedSubject,
      date: selectedDate,
      status: r.status,
      recordedBy: currentTeacher.id,
      recordedAt: new Date().toISOString()
    }));

    onAddAttendance(recordsToInsert);
    onAddAuditLog(
      `Marked attendance for ${selectedSubject} on ${selectedDate}`,
      `${selectedSubject} - ${selectedDate}`,
      "Attendance"
    );

    setAttendanceSavedNote(`Attendance records saved for ${attendanceRoster.length} students!`);
    setTimeout(() => setAttendanceSavedNote(null), 3500);
  };

  // Add Assignment
  const handleAddAssignmentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAssignTitle || !newAssignSubject || !newAssignDueDate) return;

    const newAssign: Assignment = {
      id: `assign-${Date.now()}`,
      subject: subjects.find(s => s.code === newAssignSubject)?.name || newAssignSubject,
      title: newAssignTitle,
      description: newAssignDesc,
      dueDate: newAssignDueDate,
      status: "Pending",
      timeLeft: "Soon",
      countdownSeconds: 86400 * 3
    };

    onAddAssignment(newAssign);
    onAddAuditLog(
      `Created new assignment: "${newAssignTitle}" for ${newAssignSubject}`,
      newAssign.id,
      "Assignment"
    );

    setAssignFormMsg("Assignment created successfully and students notified!");
    setNewAssignTitle("");
    setNewAssignDesc("");
    setNewAssignDueDate("");
    setTimeout(() => setAssignFormMsg(null), 3000);
  };

  // Grade Submission
  const handleGradeSubmissionSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeSubmissionId) return;

    onGradeSubmission(activeSubmissionId, gradeScore, gradeFeedback, currentTeacher.name);
    
    // Log audit trail
    onAddAuditLog(
      `Graded submission of student for assignment (${gradeScore} marks)`,
      activeSubmissionId,
      "Grading"
    );

    setGradeSuccessMsg("Grade and feedback saved and published successfully!");
    setTimeout(() => {
      setGradeSuccessMsg(null);
      setActiveSubmissionId(null);
    }, 2000);
  };

  // Save draft marks
  const handleSaveDraftMarks = () => {
    const listToSave: ExamMark[] = marksRoster.map(r => ({
      id: `mark-${marksSubjectCode}-${r.studentId}-${marksExamName}`,
      subjectCode: marksSubjectCode,
      studentId: r.studentId,
      studentName: r.name,
      examName: marksExamName,
      score: Number(r.score),
      maxScore: Number(r.maxScore),
      published: false // remains draft
    }));

    onSaveExamMark(listToSave);
    onAddAuditLog(
      `Saved draft marks for ${marksSubjectCode} - ${marksExamName}`,
      `${marksSubjectCode} - ${marksExamName}`,
      "Marks Draft"
    );

    setMarksStatusMsg("Draft marks saved in ledger. You can review and publish them when ready.");
    setTimeout(() => setMarksStatusMsg(null), 3000);
  };

  // Publish marks
  const handlePublishMarks = () => {
    // First save latest scores from roster
    const listToSave: ExamMark[] = marksRoster.map(r => ({
      id: `mark-${marksSubjectCode}-${r.studentId}-${marksExamName}`,
      subjectCode: marksSubjectCode,
      studentId: r.studentId,
      studentName: r.name,
      examName: marksExamName,
      score: Number(r.score),
      maxScore: Number(r.maxScore),
      published: true // marked as published
    }));

    onSaveExamMark(listToSave);
    onPublishExamMarks(marksSubjectCode, marksExamName);
    
    onAddAuditLog(
      `Published exam results for ${marksSubjectCode} - ${marksExamName}`,
      `${marksSubjectCode} - ${marksExamName}`,
      "Marks Publish"
    );

    setConfirmPublish(false);
    setMarksStatusMsg(`Success! Exam results published and ${marksRoster.length} students have been notified.`);
    setTimeout(() => setMarksStatusMsg(null), 3500);
  };

  // Upload Digital Asset Resource
  const handleUploadResource = (e: React.FormEvent) => {
    e.preventDefault();
    if (!resourceName || !resourceSubject) return;

    const asset = {
      id: `asset-${Date.now()}`,
      name: resourceName + ".pdf",
      size: resourceSize || "1.5 MB",
      date: new Date().toLocaleDateString("en-US", { month: "long", day: "numeric", year: "numeric" }),
      format: resourceFormat
    };

    onAddDigitalAsset(asset);
    onAddAuditLog(
      `Uploaded resource slide: "${asset.name}" for ${resourceSubject}`,
      asset.id,
      "Resource Upload"
    );

    setResourceMsg(`Resource "${asset.name}" uploaded to classroom database successfully.`);
    setResourceName("");
    setTimeout(() => setResourceMsg(null), 3000);
  };

  // Schedule Exam
  const handleScheduleExam = (e: React.FormEvent) => {
    e.preventDefault();
    if (!examSubject || !examDate || !examTime) return;

    const subj = subjects.find(s => s.code === examSubject);
    const newExam: Exam = {
      id: `exam-${Date.now()}`,
      subjectCode: examSubject,
      subjectName: subj?.name || examSubject,
      date: examDate,
      time: examTime,
      room: examRoom,
      instructions: examInst,
      hallTicketReady: false
    };

    onAddExam(newExam);
    onAddAuditLog(
      `Scheduled new midterm exam for ${newExam.subjectName} on ${examDate}`,
      newExam.id,
      "Exam Schedule"
    );

    setExamMsg(`Exam scheduled and calendar updated. Hall tickets automatic release scheduled.`);
    setExamDate("");
    setExamInst("");
    setTimeout(() => setExamMsg(null), 3000);
  };

  // Counts for the teacher widgets
  const totalStudentsTaught = enrollments.filter(e => teacherSubjects.some(ts => ts.code === e.subjectCode)).length;
  const pendingGradingCount = submissions.filter(s => s.status === "Submitted" && teacherSubjects.some(ts => {
    const matchingAssign = assignments.find(a => a.id === s.assignmentId);
    return matchingAssign?.subject === ts.name;
  })).length;

  return (
    <div className="space-y-8 pb-10" id="teacher-dashboard-root">
      {/* Top Welcome Title & Role Scoped Navigation Sidebar */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold font-sans text-brand-on-surface dark:text-gray-100 flex items-center gap-2">
            <Sparkles size={24} className="text-brand-primary dark:text-indigo-400" />
            Instructor Central: {currentTeacher.name}
          </h1>
          <p className="text-xs text-brand-on-variant dark:text-gray-400 mt-1">
            Department: {departments.find(d => d.id === currentTeacher.departmentId)?.name || "Academic Department"}
          </p>
        </div>

        {/* Dynamic Navigation Tabs inside Operator Console */}
        <div className="flex flex-wrap gap-2" id="teacher-subtabs">
          {["Overview", "Mark Attendance", "Assignments", "Exams & Marks", "Resources & Class"].map((tab) => (
            <button
              key={tab}
              id={`teacher-tab-${tab.toLowerCase().replace(/ /g, "-")}`}
              onClick={() => setActiveSubTab(tab)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold cursor-pointer transition-all ${
                activeSubTab === tab
                  ? "neu-inset border border-brand-primary/20 text-brand-primary dark:text-indigo-400 font-extrabold"
                  : "neu-flat text-brand-on-variant dark:text-gray-400 hover:text-brand-on-surface"
              }`}
            >
              {tab}
            </button>
          ))}
        </div>
      </div>

      <AnimatePresence mode="wait">
        <motion.div
          key={activeSubTab}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -10 }}
          transition={{ duration: 0.15 }}
          className="space-y-8"
        >
          {/* ==================== 1. OVERVIEW SCREEN ==================== */}
          {activeSubTab === "Overview" && (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              {/* Left 2 Columns: Actionable Widgets */}
              <div className="lg:col-span-2 space-y-8">
                {/* 3 Quick KPI Cards */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div className="p-4 rounded-xl neu-flat bg-brand-surface/20">
                    <span className="text-[10px] font-mono font-bold text-gray-400 block uppercase">Students Taught</span>
                    <span className="text-2xl font-extrabold font-serif italic text-brand-primary dark:text-indigo-400 mt-1 block">{totalStudentsTaught}</span>
                    <span className="text-[9px] text-brand-on-variant dark:text-gray-400 mt-0.5 block">Across {teacherSubjects.length} subjects</span>
                  </div>
                  <div className="p-4 rounded-xl neu-flat bg-brand-surface/20">
                    <span className="text-[10px] font-mono font-bold text-gray-400 block uppercase">Grading Queue</span>
                    <span className="text-2xl font-extrabold font-serif italic text-rose-500 mt-1 block">{pendingGradingCount}</span>
                    <span className="text-[9px] text-brand-on-variant dark:text-gray-400 mt-0.5 block">Pending feedback</span>
                  </div>
                  <div className="p-4 rounded-xl neu-flat bg-brand-surface/20">
                    <span className="text-[10px] font-mono font-bold text-gray-400 block uppercase">Active Subjects</span>
                    <span className="text-2xl font-extrabold font-serif italic text-emerald-500 mt-1 block">{teacherSubjects.length}</span>
                    <span className="text-[9px] text-brand-on-variant dark:text-gray-400 mt-0.5 block">Registered syllabus</span>
                  </div>
                </div>

                {/* Today's Classes & Pending Attendance */}
                <div className="p-6 rounded-2xl neu-flat space-y-4">
                  <h3 className="font-bold text-md text-brand-on-surface dark:text-gray-100 flex items-center gap-2">
                    <Clock size={18} className="text-brand-primary dark:text-indigo-400" />
                    Today's Slot &amp; Attendance Actions
                  </h3>
                  <div className="space-y-3">
                    {teacherSubjects.map(sub => {
                      // Check if attendance already taken for today
                      const todayStr = new Date().toISOString().split("T")[0];
                      const attendanceTaken = attendance.some(a => a.subjectCode === sub.code && a.date === todayStr);

                      return (
                        <div key={sub.id} className="p-4 rounded-xl neu-inset flex items-center justify-between gap-4">
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="text-[9px] font-mono font-bold uppercase tracking-wider bg-indigo-500/10 text-brand-primary px-1.5 py-0.5 rounded">
                                {sub.code}
                              </span>
                              <h4 className="text-xs font-bold text-brand-on-surface dark:text-gray-100">{sub.name}</h4>
                            </div>
                            <p className="text-[10px] text-gray-400 mt-1 font-mono">Room: 402-A | Scheduled: Mon 09:00 AM</p>
                          </div>

                          <button
                            onClick={() => {
                              setSelectedSubject(sub.code);
                              loadAttendanceRoster(sub.code, selectedDate);
                              setActiveSubTab("Mark Attendance");
                            }}
                            className={`px-3 py-1.5 rounded-lg text-[10px] font-bold cursor-pointer transition-all flex items-center gap-1 ${
                              attendanceTaken
                                ? "bg-emerald-500/10 text-emerald-500 border border-emerald-500/20 hover:bg-emerald-500/20"
                                : "bg-brand-primary hover:bg-brand-primary-container text-white shadow-md"
                            }`}
                          >
                            {attendanceTaken ? (
                              <>
                                <CheckCircle size={12} /> Marked (Update)
                              </>
                            ) : (
                              <>
                                <UserCheck size={12} /> Mark Attendance
                              </>
                            )}
                          </button>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Grading Queue Widget */}
                <div className="p-6 rounded-2xl neu-flat space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="font-bold text-md text-brand-on-surface dark:text-gray-100 flex items-center gap-2">
                      <FileText size={18} className="text-brand-primary dark:text-indigo-400" />
                      Pending Evaluation Submissions
                    </h3>
                    <span className="text-[10px] font-mono font-extrabold bg-rose-500/10 text-rose-500 px-2 py-0.5 rounded-full">
                      {pendingGradingCount} URGENT
                    </span>
                  </div>

                  <div className="space-y-3">
                    {submissions.filter(s => s.status === "Submitted").slice(0, 3).map(subm => {
                      const matchingAssign = assignments.find(a => a.id === subm.assignmentId);
                      return (
                        <div key={subm.id} className="p-4 rounded-xl neu-inset flex items-center justify-between gap-4">
                          <div>
                            <h4 className="text-xs font-bold text-brand-on-surface dark:text-gray-100">{subm.studentName}</h4>
                            <p className="text-[10px] text-brand-on-variant dark:text-gray-400 mt-0.5">
                              Submitted: {matchingAssign?.title || "Assignment"} ({matchingAssign?.subject})
                            </p>
                            <p className="text-[9px] text-rose-400 font-mono mt-1">Submitted at {new Date(subm.submittedAt).toLocaleDateString()}</p>
                          </div>

                          <button
                            onClick={() => {
                              setSelectedAssignmentId(subm.assignmentId);
                              setActiveSubmissionId(subm.id);
                              setGradeScore(subm.maxScore);
                              setGradeFeedback("");
                              setActiveSubTab("Assignments");
                            }}
                            className="px-3 py-1.5 rounded-lg bg-brand-surface dark:bg-slate-900 border border-brand-primary/20 hover:border-transparent hover:bg-brand-primary hover:text-white dark:hover:bg-indigo-600 text-[10px] font-bold text-brand-primary dark:text-indigo-400 cursor-pointer transition-all flex items-center gap-1"
                          >
                            Evaluate <ChevronRight size={10} />
                          </button>
                        </div>
                      );
                    })}
                    {pendingGradingCount === 0 && (
                      <div className="p-4 text-center text-xs text-gray-400 font-serif italic">
                        ✓ Excellent! No submissions are waiting in your grading queue today.
                      </div>
                    )}
                  </div>
                </div>
              </div>

              {/* Right Column Sidebar: Recent Activity & Action FAB */}
              <div className="space-y-8">
                {/* Instant FAB / Quick Actions Panel */}
                <div className="p-6 rounded-2xl neu-flat bg-brand-primary-container/20 space-y-4">
                  <h3 className="font-bold text-xs font-mono uppercase text-brand-primary tracking-widest">Quick Actions FAB</h3>
                  
                  <div className="grid grid-cols-1 gap-2.5">
                    <button
                      onClick={() => {
                        setSelectedSubject(teacherSubjects[0]?.code || "");
                        loadAttendanceRoster(teacherSubjects[0]?.code || "", selectedDate);
                        setActiveSubTab("Mark Attendance");
                      }}
                      className="p-3 rounded-xl neu-button flex items-center gap-3 text-left cursor-pointer"
                    >
                      <UserCheck size={16} className="text-brand-primary" />
                      <div>
                        <span className="text-xs font-bold block leading-none">Record Attendance</span>
                        <span className="text-[9px] text-gray-400 font-mono mt-1 block">Mark today's slots</span>
                      </div>
                    </button>

                    <button
                      onClick={() => {
                        setActiveSubTab("Assignments");
                      }}
                      className="p-3 rounded-xl neu-button flex items-center gap-3 text-left cursor-pointer"
                    >
                      <Plus size={16} className="text-emerald-500" />
                      <div>
                        <span className="text-xs font-bold block leading-none">New Assignment</span>
                        <span className="text-[9px] text-gray-400 font-mono mt-1 block">Publish syllabus tasks</span>
                      </div>
                    </button>

                    <button
                      onClick={() => {
                        setMarksSubjectCode(teacherSubjects[0]?.code || "");
                        loadMarksRoster(teacherSubjects[0]?.code || "", marksExamName);
                        setActiveSubTab("Exams & Marks");
                      }}
                      className="p-3 rounded-xl neu-button flex items-center gap-3 text-left cursor-pointer"
                    >
                      <Award size={16} className="text-indigo-400" />
                      <div>
                        <span className="text-xs font-bold block leading-none">Enter Exam Marks</span>
                        <span className="text-[9px] text-gray-400 font-mono mt-1 block">Save draft or publish</span>
                      </div>
                    </button>
                  </div>
                </div>

                {/* Recent Activities Audit List */}
                <div className="p-6 rounded-2xl neu-flat space-y-4">
                  <h3 className="font-bold text-sm text-brand-on-surface dark:text-gray-100">Recent Class Logs</h3>
                  <div className="space-y-3.5 max-h-[300px] overflow-y-auto pr-1">
                    {auditLogs
                      .filter(l => l.actorEmail === currentTeacher.email)
                      .slice(0, 6)
                      .map(log => (
                        <div key={log.id} className="border-l-2 border-brand-primary pl-3 py-0.5 space-y-1">
                          <p className="text-xs text-brand-on-surface dark:text-gray-200 font-medium leading-snug">{log.action}</p>
                          <span className="text-[9px] text-gray-400 font-mono block">
                            {new Date(log.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} • {log.entityType}
                          </span>
                        </div>
                      ))}
                    {auditLogs.filter(l => l.actorEmail === currentTeacher.email).length === 0 && (
                      <p className="text-xs text-gray-400 font-serif italic text-center py-4">No recent session logs recorded.</p>
                    )}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* ==================== 2. MARK ATTENDANCE ==================== */}
          {activeSubTab === "Mark Attendance" && (
            <div className="p-6 rounded-2xl neu-flat space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 border-b border-brand-container pb-4">
                <div>
                  <h2 className="text-lg font-bold text-brand-on-surface dark:text-gray-100">Roll-Call Attendance Marking</h2>
                  <p className="text-xs text-brand-on-variant dark:text-gray-400 mt-0.5">Pick subject class, select date, and toggle students list exceptions.</p>
                </div>

                <div className="flex flex-wrap items-center gap-3">
                  <select
                    value={selectedSubject}
                    onChange={(e) => {
                      setSelectedSubject(e.target.value);
                      loadAttendanceRoster(e.target.value, selectedDate);
                    }}
                    className="p-2 text-xs rounded-xl neu-inset bg-brand-surface dark:bg-brand-dark-surface text-brand-on-surface dark:text-gray-100 outline-none cursor-pointer"
                  >
                    <option value="">Select Subject</option>
                    {teacherSubjects.map(sub => (
                      <option key={sub.id} value={sub.code}>{sub.code} - {sub.name}</option>
                    ))}
                  </select>

                  <input
                    type="date"
                    value={selectedDate}
                    onChange={(e) => {
                      setSelectedDate(e.target.value);
                      loadAttendanceRoster(selectedSubject, e.target.value);
                    }}
                    className="p-2 text-xs rounded-xl neu-inset bg-brand-surface dark:bg-brand-dark-surface text-brand-on-surface dark:text-gray-100 outline-none cursor-pointer"
                  />
                </div>
              </div>

              {/* Status Save Banner */}
              {attendanceSavedNote && (
                <div className="p-3 bg-emerald-500/10 border border-emerald-500/20 text-emerald-600 dark:text-emerald-400 text-xs font-bold text-center rounded-xl">
                  ✓ {attendanceSavedNote}
                </div>
              )}

              {selectedSubject ? (
                <div className="space-y-4">
                  <div className="flex items-center justify-between bg-brand-primary-container/10 p-3 rounded-xl text-xs font-mono text-brand-primary">
                    <span>Default State: <strong className="font-extrabold uppercase text-emerald-400">Bulk Marked Present</strong></span>
                    <span>Touch rows below to flag absences or cancellations</span>
                  </div>

                  {/* Student Grid */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {attendanceRoster.map((item, index) => {
                      // Check if Austin Reaves has disputed past records
                      const hasDispute = item.studentId === "student-1" && attendance.some(a => a.studentId === item.studentId && a.subjectCode === selectedSubject && a.disputed);

                      return (
                        <div 
                          key={item.studentId}
                          className={`p-4 rounded-xl transition-all flex items-center justify-between border ${
                            item.status === "Present"
                              ? "neu-inset border-emerald-500/10"
                              : "neu-flat border-rose-500/20"
                          }`}
                        >
                          <div className="min-w-0">
                            <h4 className="text-xs font-bold text-brand-on-surface dark:text-gray-100">{item.name}</h4>
                            <p className="text-[10px] text-gray-400 font-mono mt-0.5">Roll: {item.roll}</p>
                            
                            {hasDispute && (
                              <span className="inline-flex items-center gap-0.5 text-[8px] font-mono bg-rose-500/15 text-rose-500 px-1 py-0.5 rounded mt-1 uppercase font-bold">
                                <AlertCircle size={8} /> Has open attendance dispute!
                              </span>
                            )}
                          </div>

                          <div className="flex items-center gap-1.5">
                            {(["Present", "Absent", "No Class"] as const).map(st => (
                              <button
                                key={st}
                                onClick={() => {
                                  const updated = [...attendanceRoster];
                                  updated[index].status = st;
                                  setAttendanceRoster(updated);
                                }}
                                className={`px-2 py-1 rounded text-[9px] font-mono font-bold cursor-pointer transition-all ${
                                  item.status === st
                                    ? st === "Present"
                                      ? "bg-emerald-500 text-white"
                                      : st === "Absent"
                                        ? "bg-rose-500 text-white"
                                        : "bg-gray-500 text-white"
                                    : "bg-brand-surface hover:bg-brand-container border border-brand-container/20 text-gray-400"
                                }`}
                              >
                                {st}
                              </button>
                            ))}
                          </div>
                        </div>
                      );
                    })}
                  </div>

                  <div className="flex justify-end pt-4 border-t border-brand-container/30">
                    <button
                      onClick={handleSaveAttendance}
                      className="py-2.5 px-6 bg-brand-primary hover:bg-brand-primary-container text-white text-xs font-bold rounded-xl shadow-md cursor-pointer flex items-center gap-2 transition-all"
                    >
                      <Save size={14} /> Submit &amp; Sync Roster
                    </button>
                  </div>
                </div>
              ) : (
                <div className="text-center py-12 text-xs text-gray-400 font-serif italic">
                  ℹ Please pick an active subject class on the selector above to load the roll-call roster.
                </div>
              )}
            </div>
          )}

          {/* ==================== 3. ASSIGNMENTS & EVALUATION ==================== */}
          {activeSubTab === "Assignments" && (
            <div className="space-y-8">
              {/* Top Row: Create New Assignment & List Existing */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                {/* Create Assignment Form */}
                <div className="p-6 rounded-2xl neu-flat space-y-4">
                  <h3 className="font-bold text-md text-brand-on-surface dark:text-gray-100 flex items-center gap-2">
                    <Plus size={18} className="text-brand-primary dark:text-indigo-400" />
                    New Syllabus Task
                  </h3>

                  {assignFormMsg && (
                    <div className="p-3 bg-emerald-500/10 border border-emerald-500/20 text-emerald-600 dark:text-emerald-400 text-xs font-bold text-center rounded-xl">
                      ✓ {assignFormMsg}
                    </div>
                  )}

                  <form onSubmit={handleAddAssignmentSubmit} className="space-y-3.5">
                    <div className="space-y-1">
                      <label className="text-[10px] font-mono font-bold uppercase text-gray-400">Assignment Title</label>
                      <input
                        type="text"
                        required
                        value={newAssignTitle}
                        onChange={(e) => setNewAssignTitle(e.target.value)}
                        placeholder="e.g. Fourier Series Derivations"
                        className="w-full text-xs p-2.5 rounded-xl neu-inset bg-brand-surface dark:bg-brand-dark-surface text-brand-on-surface dark:text-gray-100 focus:outline-none"
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="text-[10px] font-mono font-bold uppercase text-gray-400">Class Subject</label>
                      <select
                        required
                        value={newAssignSubject}
                        onChange={(e) => setNewAssignSubject(e.target.value)}
                        className="w-full text-xs p-2.5 rounded-xl neu-inset bg-brand-surface dark:bg-brand-dark-surface text-brand-on-surface dark:text-gray-100 focus:outline-none cursor-pointer"
                      >
                        <option value="">Choose Class</option>
                        {teacherSubjects.map(sub => (
                          <option key={sub.id} value={sub.code}>{sub.code} - {sub.name}</option>
                        ))}
                      </select>
                    </div>

                    <div className="space-y-1">
                      <label className="text-[10px] font-mono font-bold uppercase text-gray-400">Deadline Target</label>
                      <input
                        type="text"
                        required
                        value={newAssignDueDate}
                        onChange={(e) => setNewAssignDueDate(e.target.value)}
                        placeholder="e.g. July 10, 2026, 11:59 PM"
                        className="w-full text-xs p-2.5 rounded-xl neu-inset bg-brand-surface dark:bg-brand-dark-surface text-brand-on-surface dark:text-gray-100 focus:outline-none"
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-1">
                        <label className="text-[10px] font-mono font-bold uppercase text-gray-400">Max Score</label>
                        <input
                          type="number"
                          required
                          value={newAssignMaxScore}
                          onChange={(e) => setNewAssignMaxScore(Number(e.target.value))}
                          className="w-full text-xs p-2.5 rounded-xl neu-inset bg-brand-surface dark:bg-brand-dark-surface text-brand-on-surface dark:text-gray-100 focus:outline-none"
                        />
                      </div>
                      <div className="space-y-1 flex flex-col justify-center">
                        <label className="text-[10px] font-mono font-bold uppercase text-gray-400 mb-2">Allow Late</label>
                        <button
                          type="button"
                          onClick={() => setNewAssignAllowLate(!newAssignAllowLate)}
                          className={`py-2 px-3 rounded-xl text-xs font-bold transition-all border ${
                            newAssignAllowLate
                              ? "bg-indigo-500/15 border-indigo-500/30 text-brand-primary"
                              : "bg-brand-surface border-brand-container text-gray-400"
                          }`}
                        >
                          {newAssignAllowLate ? "Yes, Late Allowed" : "No, Strict Lock"}
                        </button>
                      </div>
                    </div>

                    <div className="space-y-1">
                      <label className="text-[10px] font-mono font-bold uppercase text-gray-400">Instructions / Description</label>
                      <textarea
                        value={newAssignDesc}
                        onChange={(e) => setNewAssignDesc(e.target.value)}
                        rows={3}
                        placeholder="Detail specific deliverables..."
                        className="w-full text-xs p-2.5 rounded-xl neu-inset bg-brand-surface dark:bg-brand-dark-surface text-brand-on-surface dark:text-gray-100 focus:outline-none resize-none"
                      />
                    </div>

                    <button
                      type="submit"
                      className="w-full py-2.5 bg-brand-primary hover:bg-brand-primary-container text-white text-xs font-bold rounded-xl shadow-md transition-all cursor-pointer flex items-center justify-center gap-1.5"
                    >
                      <Send size={12} /> Dispatch Syllabus Task
                    </button>
                  </form>
                </div>

                {/* Assignments List & Submissions View */}
                <div className="lg:col-span-2 space-y-6">
                  <div className="p-6 rounded-2xl neu-flat space-y-4">
                    <h3 className="font-bold text-md text-brand-on-surface dark:text-gray-100">Evaluative Tasks Syllabus</h3>
                    <div className="space-y-3">
                      {assignments.filter(a => teacherSubjects.some(ts => ts.name === a.subject)).map(assign => {
                        const assignSubms = submissions.filter(s => s.assignmentId === assign.id);
                        const gradedSubms = assignSubms.filter(s => s.status === "Graded");
                        const pendingSubms = assignSubms.filter(s => s.status === "Submitted");

                        return (
                          <div key={assign.id} className="p-4 rounded-xl neu-inset flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                            <div>
                              <div className="flex items-center gap-2">
                                <span className="text-[9px] font-mono font-bold bg-indigo-500/10 text-brand-primary px-1.5 py-0.5 rounded">
                                  {assign.subject}
                                </span>
                                <h4 className="text-xs font-extrabold text-brand-on-surface dark:text-gray-100">{assign.title}</h4>
                              </div>
                              <p className="text-[10px] text-gray-400 mt-1 font-mono">Due: {assign.dueDate}</p>
                              <div className="flex gap-4 mt-2 text-[9px] text-gray-400 font-mono">
                                <span>Submissions: {assignSubms.length}</span>
                                <span className="text-rose-400 font-bold">Ungraded: {pendingSubms.length}</span>
                                <span className="text-emerald-500">Evaluated: {gradedSubms.length}</span>
                              </div>
                            </div>

                            <button
                              onClick={() => {
                                setSelectedAssignmentId(assign.id);
                                setActiveSubmissionId(null);
                              }}
                              className={`px-3 py-1.5 rounded-lg text-[10px] font-bold cursor-pointer transition-all flex items-center gap-1 ${
                                selectedAssignmentId === assign.id
                                  ? "bg-brand-primary text-white"
                                  : "bg-brand-surface dark:bg-slate-900 border border-brand-primary/20 text-brand-primary dark:text-indigo-400 hover:bg-brand-primary hover:text-white"
                              }`}
                            >
                              View Submissions <ChevronRight size={10} />
                            </button>
                          </div>
                        );
                      })}
                    </div>
                  </div>

                  {/* If an assignment is selected, show submissions list */}
                  {selectedAssignmentId && (
                    <div className="p-6 rounded-2xl neu-flat space-y-4">
                      <div className="flex items-center justify-between border-b border-brand-container pb-3">
                        <div>
                          <span className="text-[10px] font-mono text-indigo-400 uppercase font-bold block">Assignment Submissions</span>
                          <h4 className="text-xs font-bold text-brand-on-surface dark:text-gray-100">
                            {assignments.find(a => a.id === selectedAssignmentId)?.title}
                          </h4>
                        </div>
                        <button 
                          onClick={() => setSelectedAssignmentId(null)}
                          className="text-gray-400 hover:text-rose-500"
                        >
                          <X size={16} />
                        </button>
                      </div>

                      <div className="space-y-3.5">
                        {submissions.filter(s => s.assignmentId === selectedAssignmentId).map(subm => (
                          <div 
                            key={subm.id} 
                            className={`p-3.5 rounded-xl neu-inset transition-all border ${
                              activeSubmissionId === subm.id 
                                ? "border-brand-primary/50" 
                                : "border-brand-container/20"
                            }`}
                          >
                            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
                              <div>
                                <h5 className="text-xs font-bold text-brand-on-surface dark:text-gray-100">{subm.studentName}</h5>
                                <div className="flex items-center gap-3 mt-1 text-[9px] font-mono text-gray-400">
                                  <span>Submitted: {new Date(subm.submittedAt).toLocaleString()}</span>
                                  <span>Format: PDF Roster</span>
                                </div>
                              </div>

                              <div className="flex items-center gap-2">
                                <span className={`text-[9px] font-mono font-bold px-2 py-0.5 rounded-full uppercase ${
                                  subm.status === "Graded"
                                    ? "bg-emerald-500/10 text-emerald-500"
                                    : "bg-amber-500/10 text-amber-500"
                                }`}>
                                  {subm.status === "Graded" ? `Graded: ${subm.score}/${subm.maxScore}` : "Pending Evaluation"}
                                </span>

                                <button
                                  onClick={() => {
                                    setActiveSubmissionId(subm.id);
                                    setGradeScore(subm.score || subm.maxScore);
                                    setGradeFeedback(subm.feedback || "");
                                  }}
                                  className="px-2.5 py-1.5 rounded bg-brand-surface dark:bg-slate-900 border border-brand-container/40 hover:bg-brand-primary hover:text-white text-[9px] font-bold cursor-pointer transition-all"
                                >
                                  {subm.status === "Graded" ? "Update Grade" : "Evaluate"}
                                </button>
                              </div>
                            </div>

                            {/* Split grading screen side-by-side inside submission row if active */}
                            {activeSubmissionId === subm.id && (
                              <div className="mt-4 pt-4 border-t border-brand-container/40 grid grid-cols-1 md:grid-cols-2 gap-4">
                                {/* Left half: Inline PDF Viewer simulator */}
                                <div className="p-3.5 bg-brand-surface dark:bg-slate-950 rounded-xl border border-brand-container flex flex-col justify-between gap-4 h-[200px]">
                                  <div>
                                    <span className="text-[8px] font-mono uppercase text-gray-500">PDF INTERACTIVE VIEWER</span>
                                    <h6 className="text-xs font-bold font-serif italic text-brand-primary dark:text-indigo-400 truncate mt-1">
                                      {subm.fileUrl}
                                    </h6>
                                    <p className="text-[10px] text-gray-400 leading-snug mt-2">
                                      Holographic signature matching verified. All equations resolved down to PDE calculus parameters. Standard IEEE layout detected.
                                    </p>
                                  </div>

                                  <div className="flex items-center justify-between text-[9px] font-mono text-gray-400 border-t border-brand-container/30 pt-2">
                                    <span>MD5 checksum verified</span>
                                    <span className="text-brand-primary">Secure Socket Delivery</span>
                                  </div>
                                </div>

                                {/* Right half: Score and feedback entry */}
                                <form onSubmit={handleGradeSubmissionSubmit} className="space-y-3">
                                  {gradeSuccessMsg && (
                                    <div className="p-2 bg-emerald-500/10 border border-emerald-500/20 text-emerald-500 text-[10px] font-bold text-center rounded">
                                      ✓ {gradeSuccessMsg}
                                    </div>
                                  )}

                                  <div className="grid grid-cols-2 gap-2">
                                    <div className="space-y-0.5">
                                      <label className="text-[9px] font-mono font-bold uppercase text-gray-400">Award Score</label>
                                      <input
                                        type="number"
                                        required
                                        max={subm.maxScore}
                                        value={gradeScore}
                                        onChange={(e) => setGradeScore(Number(e.target.value))}
                                        className="w-full text-xs p-2 rounded neu-inset bg-brand-surface dark:bg-brand-dark-surface text-brand-on-surface dark:text-gray-100 outline-none"
                                      />
                                    </div>
                                    <div className="space-y-0.5">
                                      <label className="text-[9px] font-mono font-bold uppercase text-gray-400">Out of Max</label>
                                      <input
                                        type="text"
                                        disabled
                                        value={subm.maxScore}
                                        className="w-full text-xs p-2 rounded bg-brand-surface-dim border border-brand-container text-gray-500 outline-none"
                                      />
                                    </div>
                                  </div>

                                  <div className="space-y-0.5">
                                    <label className="text-[9px] font-mono font-bold uppercase text-gray-400">Evaluative Feedback Notes</label>
                                    <textarea
                                      required
                                      value={gradeFeedback}
                                      onChange={(e) => setGradeFeedback(e.target.value)}
                                      rows={2}
                                      placeholder="Explain specifics of structural evaluations..."
                                      className="w-full text-[10px] p-2 rounded neu-inset bg-brand-surface dark:bg-brand-dark-surface text-brand-on-surface dark:text-gray-100 outline-none resize-none"
                                    />
                                  </div>

                                  <button
                                    type="submit"
                                    className="w-full py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white text-[10px] font-bold rounded cursor-pointer transition-all flex items-center justify-center gap-1"
                                  >
                                    <Check size={12} /> Save &amp; Publish Grade
                                  </button>
                                </form>
                              </div>
                            )}
                          </div>
                        ))}

                        {submissions.filter(s => s.assignmentId === selectedAssignmentId).length === 0 && (
                          <div className="text-center py-6 text-xs text-gray-400 font-serif italic">
                            ℹ No submissions recorded yet for this active task.
                          </div>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* ==================== 4. EXAMS & MARKS ==================== */}
          {activeSubTab === "Exams & Marks" && (
            <div className="space-y-8">
              {/* Spreadsheet-like Marks Ledger Entry */}
              <div className="p-6 rounded-2xl neu-flat space-y-6">
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 border-b border-brand-container pb-4">
                  <div>
                    <h2 className="text-lg font-bold text-brand-on-surface dark:text-gray-100 font-sans">Exam Marks Entry Spreadsheet</h2>
                    <p className="text-xs text-brand-on-variant dark:text-gray-400 mt-0.5">
                      Input draft examination scores, review boundaries, and publish results to sync grade point averages.
                    </p>
                  </div>

                  <div className="flex flex-wrap items-center gap-3">
                    <select
                      value={marksSubjectCode}
                      onChange={(e) => {
                        setMarksSubjectCode(e.target.value);
                        loadMarksRoster(e.target.value, marksExamName);
                      }}
                      className="p-2 text-xs rounded-xl neu-inset bg-brand-surface dark:bg-brand-dark-surface text-brand-on-surface dark:text-gray-100 outline-none cursor-pointer"
                    >
                      <option value="">Select Subject</option>
                      {teacherSubjects.map(sub => (
                        <option key={sub.id} value={sub.code}>{sub.code} - {sub.name}</option>
                      ))}
                    </select>

                    <select
                      value={marksExamName}
                      onChange={(e) => {
                        setMarksExamName(e.target.value);
                        loadMarksRoster(marksSubjectCode, e.target.value);
                      }}
                      className="p-2 text-xs rounded-xl neu-inset bg-brand-surface dark:bg-brand-dark-surface text-brand-on-surface dark:text-gray-100 outline-none cursor-pointer"
                    >
                      <option value="Mid-Term Examination">Mid-Term Examination</option>
                      <option value="End-Semester Assessment">End-Semester Assessment</option>
                      <option value="Practical Lab Exam">Practical Lab Exam</option>
                    </select>
                  </div>
                </div>

                {marksStatusMsg && (
                  <div className="p-3 bg-indigo-500/10 border border-indigo-500/20 text-brand-primary dark:text-indigo-400 text-xs font-bold text-center rounded-xl">
                    ✓ {marksStatusMsg}
                  </div>
                )}

                {marksSubjectCode ? (
                  <div className="space-y-6">
                    {/* SPREADSHEET TABLE GRID */}
                    <div className="overflow-x-auto rounded-xl neu-inset border border-brand-container/20">
                      <table className="w-full text-left text-xs">
                        <thead>
                          <tr className="bg-brand-surface-bright dark:bg-slate-900 border-b border-brand-container">
                            <th className="p-3 font-mono text-[10px] uppercase font-bold text-gray-400">Student Name</th>
                            <th className="p-3 font-mono text-[10px] uppercase font-bold text-gray-400 text-center">Score Marks</th>
                            <th className="p-3 font-mono text-[10px] uppercase font-bold text-gray-400 text-center">Max Marks</th>
                            <th className="p-3 font-mono text-[10px] uppercase font-bold text-gray-400 text-center">Draft Status</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-brand-container/40">
                          {marksRoster.map((item, index) => {
                            const isMarkPublished = examMarks.some(m => m.subjectCode === marksSubjectCode && m.studentId === item.studentId && m.examName === marksExamName && m.published);

                            return (
                              <tr key={item.studentId} className="hover:bg-brand-surface-dim/30">
                                <td className="p-3 font-semibold text-brand-on-surface dark:text-gray-200">
                                  {item.name}
                                </td>
                                <td className="p-3 text-center">
                                  <input
                                    type="number"
                                    max={item.maxScore}
                                    value={item.score}
                                    onChange={(e) => {
                                      const updated = [...marksRoster];
                                      updated[index].score = Number(e.target.value);
                                      setMarksRoster(updated);
                                    }}
                                    className="w-20 text-center p-1.5 rounded neu-inset bg-brand-surface dark:bg-brand-dark-surface text-brand-on-surface dark:text-gray-100 outline-none font-bold"
                                  />
                                </td>
                                <td className="p-3 text-center">
                                  <input
                                    type="number"
                                    value={item.maxScore}
                                    onChange={(e) => {
                                      const updated = [...marksRoster];
                                      updated[index].maxScore = Number(e.target.value);
                                      setMarksRoster(updated);
                                    }}
                                    className="w-20 text-center p-1.5 rounded neu-inset bg-brand-surface dark:bg-brand-dark-surface text-brand-on-surface dark:text-gray-100 outline-none font-medium text-gray-400"
                                  />
                                </td>
                                <td className="p-3 text-center">
                                  <span className={`text-[9px] font-mono px-2 py-0.5 rounded-full ${
                                    isMarkPublished
                                      ? "bg-emerald-500/10 text-emerald-500"
                                      : "bg-amber-500/10 text-amber-500"
                                  }`}>
                                    {isMarkPublished ? "✓ Published" : "✎ Draft"}
                                  </span>
                                </td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>

                    <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 border-t border-brand-container/30 pt-4">
                      <span className="text-[10px] text-gray-400 font-mono">
                        Changes saved as draft will not be visible to students in their Academics ledger until published.
                      </span>

                      <div className="flex gap-3">
                        <button
                          onClick={handleSaveDraftMarks}
                          className="py-2.5 px-5 bg-brand-surface dark:bg-slate-900 hover:bg-brand-container text-brand-primary border border-brand-primary/20 text-xs font-bold rounded-xl shadow cursor-pointer transition-all flex items-center gap-1.5"
                        >
                          <Save size={14} /> Save Draft
                        </button>

                        <button
                          onClick={() => setConfirmPublish(true)}
                          className="py-2.5 px-5 bg-brand-primary hover:bg-brand-primary-container text-white text-xs font-bold rounded-xl shadow-md cursor-pointer transition-all flex items-center gap-1.5 animate-pulse-slow"
                        >
                          <CheckCircle size={14} /> Publish Results
                        </button>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-12 text-xs text-gray-400 font-serif italic">
                    ℹ Please select an active subject class on the selector above to populate the spreadsheet ledger.
                  </div>
                )}
              </div>

              {/* Confirm Publish Modal overlay backdrop */}
              {confirmPublish && (
                <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 z-50">
                  <div className="max-w-md w-full p-6 rounded-2xl neu-flat bg-brand-surface-dim border border-indigo-500/30 text-brand-on-surface dark:text-gray-100 space-y-4">
                    <div className="flex items-center gap-3 text-brand-primary">
                      <AlertCircle size={24} />
                      <h3 className="font-bold text-lg">Confirm Publish Action</h3>
                    </div>
                    <p className="text-xs leading-relaxed text-gray-400">
                      You are about to publish examination results for <strong>{marksSubjectCode} - {marksExamName}</strong>. This action will trigger automatic Grade Point Average recalculations server-side, lock editing permissions, and immediately dispatch alerts notifying all {marksRoster.length} students.
                    </p>
                    <div className="flex justify-end gap-3 pt-2">
                      <button
                        onClick={() => setConfirmPublish(false)}
                        className="py-2 px-4 rounded-xl border border-brand-container text-xs font-bold hover:bg-brand-container cursor-pointer transition-all"
                      >
                        Cancel
                      </button>
                      <button
                        onClick={handlePublishMarks}
                        className="py-2 px-4 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl shadow-md cursor-pointer transition-all"
                      >
                        Yes, Publish Now
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {/* Exam Scheduling Block */}
              <div className="p-6 rounded-2xl neu-flat space-y-5">
                <h3 className="font-bold text-md text-brand-on-surface dark:text-gray-100 flex items-center gap-2">
                  <Calendar size={18} className="text-brand-primary dark:text-indigo-400" />
                  Schedule Examination Midterm / Finals
                </h3>

                {examMsg && (
                  <div className="p-3 bg-emerald-500/10 border border-emerald-500/20 text-emerald-600 dark:text-emerald-400 text-xs font-bold text-center rounded-xl">
                    ✓ {examMsg}
                  </div>
                )}

                <form onSubmit={handleScheduleExam} className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  <div className="space-y-1">
                    <label className="text-[10px] font-mono font-bold uppercase text-gray-400">Subject</label>
                    <select
                      required
                      value={examSubject}
                      onChange={(e) => setExamSubject(e.target.value)}
                      className="w-full text-xs p-2.5 rounded-xl neu-inset bg-brand-surface dark:bg-brand-dark-surface text-brand-on-surface dark:text-gray-100 focus:outline-none cursor-pointer"
                    >
                      <option value="">Choose...</option>
                      {teacherSubjects.map(sub => (
                        <option key={sub.id} value={sub.code}>{sub.code} - {sub.name}</option>
                      ))}
                    </select>
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-mono font-bold uppercase text-gray-400">Exam Date</label>
                    <input
                      type="date"
                      required
                      value={examDate}
                      onChange={(e) => setExamDate(e.target.value)}
                      className="w-full text-xs p-2.5 rounded-xl neu-inset bg-brand-surface dark:bg-brand-dark-surface text-brand-on-surface dark:text-gray-100 focus:outline-none outline-none"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-mono font-bold uppercase text-gray-400">Exam Room Location</label>
                    <input
                      type="text"
                      required
                      value={examRoom}
                      onChange={(e) => setExamRoom(e.target.value)}
                      className="w-full text-xs p-2.5 rounded-xl neu-inset bg-brand-surface dark:bg-brand-dark-surface text-brand-on-surface dark:text-gray-100 focus:outline-none"
                    />
                  </div>

                  <div className="flex flex-col justify-end">
                    <button
                      type="submit"
                      className="py-2.5 bg-brand-primary hover:bg-brand-primary-container text-white text-xs font-bold rounded-xl shadow-md transition-all cursor-pointer flex items-center justify-center gap-1.5"
                    >
                      <Plus size={14} /> Schedule Exam
                    </button>
                  </div>
                </form>
              </div>
            </div>
          )}

          {/* ==================== 5. RESOURCES & CLASSES ==================== */}
          {activeSubTab === "Resources & Class" && (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {/* Resource Upload module */}
              <div className="p-6 rounded-2xl neu-flat space-y-4">
                <h3 className="font-bold text-md text-brand-on-surface dark:text-gray-100 flex items-center gap-2">
                  <Upload size={18} className="text-brand-primary dark:text-indigo-400" />
                  Upload Digital Classroom Resources
                </h3>

                {resourceMsg && (
                  <div className="p-3 bg-emerald-500/10 border border-emerald-500/20 text-emerald-600 dark:text-emerald-400 text-xs font-bold text-center rounded-xl">
                    ✓ {resourceMsg}
                  </div>
                )}

                <form onSubmit={handleUploadResource} className="space-y-4">
                  <div className="space-y-1">
                    <label className="text-[10px] font-mono font-bold uppercase text-gray-400">Resource Name / File title</label>
                    <input
                      type="text"
                      required
                      value={resourceName}
                      onChange={(e) => setResourceName(e.target.value)}
                      placeholder="e.g. Fourier Transforms PDEs Study Guide"
                      className="w-full text-xs p-2.5 rounded-xl neu-inset bg-brand-surface dark:bg-brand-dark-surface text-brand-on-surface dark:text-gray-100 focus:outline-none"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <label className="text-[10px] font-mono font-bold uppercase text-gray-400">Subject syllabus</label>
                      <select
                        required
                        value={resourceSubject}
                        onChange={(e) => setResourceSubject(e.target.value)}
                        className="w-full text-xs p-2.5 rounded-xl neu-inset bg-brand-surface dark:bg-brand-dark-surface text-brand-on-surface dark:text-gray-100 focus:outline-none cursor-pointer"
                      >
                        <option value="">Select subject</option>
                        {teacherSubjects.map(sub => (
                          <option key={sub.id} value={sub.code}>{sub.code} - {sub.name}</option>
                        ))}
                      </select>
                    </div>

                    <div className="space-y-1">
                      <label className="text-[10px] font-mono font-bold uppercase text-gray-400">File Format</label>
                      <select
                        value={resourceFormat}
                        onChange={(e) => setResourceFormat(e.target.value as any)}
                        className="w-full text-xs p-2.5 rounded-xl neu-inset bg-brand-surface dark:bg-brand-dark-surface text-brand-on-surface dark:text-gray-100 focus:outline-none cursor-pointer"
                      >
                        <option value="pdf">Adobe PDF (.pdf)</option>
                        <option value="epub">Epub Reader (.epub)</option>
                        <option value="doc">MS Word (.doc)</option>
                      </select>
                    </div>
                  </div>

                  <button
                    type="submit"
                    className="w-full py-2.5 bg-brand-primary hover:bg-brand-primary-container text-white text-xs font-bold rounded-xl shadow transition-all cursor-pointer flex items-center justify-center gap-1.5"
                  >
                    <Upload size={14} /> Dispatch to Library Vault
                  </button>
                </form>
              </div>

              {/* Syllabus Class Directory taught */}
              <div className="p-6 rounded-2xl neu-flat space-y-4">
                <h3 className="font-bold text-md text-brand-on-surface dark:text-gray-100 flex items-center gap-2">
                  <BookOpen size={18} className="text-brand-primary dark:text-indigo-400" />
                  My Classroom Syllabi Rosters
                </h3>

                <div className="space-y-4">
                  {teacherSubjects.map(sub => {
                    const studentCount = enrollments.filter(e => e.subjectCode === sub.code).length;

                    return (
                      <div key={sub.id} className="p-4 rounded-xl neu-inset space-y-3">
                        <div className="flex items-center justify-between">
                          <div>
                            <span className="text-[8px] font-mono font-bold bg-indigo-500/10 text-brand-primary px-1.5 py-0.5 rounded uppercase">
                              {sub.code}
                            </span>
                            <h4 className="text-xs font-bold text-brand-on-surface dark:text-gray-100 mt-1">{sub.name}</h4>
                          </div>
                          <span className="text-[10px] font-mono text-gray-400 font-bold">{studentCount} Students Enrolled</span>
                        </div>

                        {/* List of enrolled students names inline */}
                        <div className="pt-2 border-t border-brand-container/30">
                          <span className="text-[9px] font-mono uppercase text-gray-500 block mb-1.5">Enrolled Student Directory</span>
                          <div className="flex flex-wrap gap-1.5">
                            {enrollments
                              .filter(e => e.subjectCode === sub.code)
                              .map(e => profiles.find(p => p.id === e.studentId))
                              .filter(p => p !== undefined)
                              .map(student => (
                                <span 
                                  key={student?.id} 
                                  className="text-[9px] font-mono bg-brand-surface dark:bg-slate-900 border border-brand-container/20 px-2 py-0.5 rounded text-brand-on-surface dark:text-gray-300"
                                >
                                  {student?.name}
                                </span>
                              ))}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          )}
        </motion.div>
      </AnimatePresence>
    </div>
  );
}
