import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Activity, 
  Calendar, 
  AlertTriangle, 
  CheckCircle, 
  Send, 
  ArrowRight, 
  Clock, 
  ShieldCheck, 
  HelpCircle,
  TrendingUp,
  FileText
} from "lucide-react";
import { SUBJECT_ATTENDANCE } from "../data";

export default function AttendanceScreen() {
  const [subjectData, setSubjectData] = useState(SUBJECT_ATTENDANCE);
  
  // Bunk Potential Simulator state
  const [simMissed, setSimMissed] = useState(2);
  const [simSubject, setSimSubject] = useState("sub-1");

  // Leave Request Form state
  const [leaveType, setLeaveType] = useState("");
  const [leaveStart, setLeaveStart] = useState("");
  const [leaveEnd, setLeaveEnd] = useState("");
  const [leaveReason, setLeaveReason] = useState("");
  const [leaveSuccess, setLeaveSuccess] = useState(false);

  // Calculate simulated attendance
  const selectedSub = subjectData.find(s => s.id === simSubject) || subjectData[0];
  const simTotal = selectedSub.total + simMissed;
  const simPercentage = (selectedSub.present / simTotal) * 100;

  const handleLeaveSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!leaveType || !leaveStart || !leaveEnd || !leaveReason) return;

    setLeaveSuccess(true);
    setTimeout(() => {
      setLeaveSuccess(false);
      setLeaveType("");
      setLeaveStart("");
      setLeaveEnd("");
      setLeaveReason("");
    }, 2800);
  };

  return (
    <div className="space-y-8 pb-10" id="attendance-root">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold font-sans text-brand-on-surface dark:text-gray-100 flex items-center gap-2">
            <Activity size={24} className="text-brand-primary dark:text-indigo-400" />
            Attendance Tracker &amp; Register
          </h1>
          <p className="text-xs text-brand-on-variant dark:text-gray-400 mt-1">Check class count logs, simulate safety rates, and file official academic leave slips.</p>
        </div>

        {/* Global Attendance Register standing */}
        <div className="p-4 rounded-xl neu-flat flex items-center gap-4 border border-indigo-100/10 w-full sm:w-auto">
          <div className="relative w-12 h-12 flex items-center justify-center">
            <svg className="w-full h-full transform -rotate-90" viewBox="0 0 42 42">
              <circle cx="21" cy="21" r="18" stroke="rgba(163, 177, 198, 0.15)" strokeWidth="3" fill="transparent" />
              <circle 
                cx="21" cy="21" r="18" 
                stroke="#10b981" 
                strokeWidth="3" 
                fill="transparent" 
                strokeDasharray="113"
                strokeDashoffset={(113 - (113 * 86.4) / 100).toString()}
                strokeLinecap="round"
                className="transition-all duration-1000"
              />
            </svg>
            <span className="absolute text-[10px] font-mono font-extrabold text-emerald-600 dark:text-emerald-400">86%</span>
          </div>
          <div>
            <span className="text-[9px] font-mono font-bold text-brand-on-variant dark:text-gray-400 uppercase">Overall Attendance</span>
            <div className="text-xs font-bold text-emerald-600 dark:text-emerald-400 mt-0.5">
              Safe Status • Threshold 75%
            </div>
          </div>
        </div>
      </div>

      {/* Main splits */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left Columns - Course by course cards */}
        <div className="lg:col-span-2 space-y-6">
          <h2 className="text-md font-bold text-brand-on-surface dark:text-gray-100 flex items-center gap-2">
            <Clock size={16} className="text-brand-primary dark:text-indigo-400" />
            Subject-wise Registers
          </h2>

          <div className="space-y-4">
            {subjectData.map((sub) => (
              <div 
                key={sub.id} 
                className={`p-5 rounded-2xl neu-flat flex flex-col sm:flex-row sm:items-center justify-between gap-4 transition-all hover:scale-[1.005]`}
              >
                <div>
                  <span className="text-[9px] font-mono font-bold uppercase text-brand-on-variant dark:text-gray-400">{sub.code}</span>
                  <h3 className="text-sm font-bold text-brand-on-surface dark:text-gray-100 mt-0.5">{sub.name}</h3>
                  <p className="text-[10px] text-brand-on-variant dark:text-gray-400 mt-1 font-mono">
                    Logged Present: {sub.present} / {sub.total} Classes
                  </p>
                </div>

                <div className="flex items-center gap-6">
                  {/* Attendance percentage indicator circle */}
                  <div className="text-right">
                    <div className={`text-base font-extrabold ${sub.percentage >= 85 ? "text-emerald-600 dark:text-emerald-400" : sub.percentage >= 75 ? "text-amber-500" : "text-rose-500"}`}>
                      {sub.percentage.toFixed(1)}%
                    </div>
                    <span className="text-[9px] font-mono text-gray-400 uppercase font-semibold">Attended</span>
                  </div>

                  <div className="h-8 w-[1px] bg-gray-300 dark:bg-gray-700 hidden sm:block" />

                  {/* Bunk safety alerts */}
                  <div>
                    {sub.bunkable > 0 ? (
                      <span className="text-[10px] font-bold px-2.5 py-1 rounded bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 block text-center uppercase tracking-wide">
                        Bunk Safe: {sub.bunkable}
                      </span>
                    ) : (
                      <span className="text-[10px] font-bold px-2.5 py-1 rounded bg-rose-500/10 text-rose-500 block text-center uppercase tracking-wide animate-pulse">
                        Crit Limit • 0 Bunk
                      </span>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right Column: Bunk Simulator slider and Leave Slips */}
        <div className="space-y-8">
          {/* Bunk Potential Simulator */}
          <div className="p-6 rounded-2xl neu-flat space-y-4">
            <h3 className="font-bold text-brand-on-surface dark:text-gray-100 flex items-center gap-2 text-md">
              <AlertTriangle size={18} className="text-brand-primary dark:text-indigo-400" />
              Bunk Safety Simulator
            </h3>
            <p className="text-[11px] text-brand-on-variant dark:text-gray-400 leading-relaxed">
              Find out what your resulting attendance drops to if you skip upcoming classes in a selected register.
            </p>

            <div className="space-y-4 pt-2">
              <div className="space-y-1">
                <label className="text-[10px] font-mono font-bold uppercase text-brand-on-variant dark:text-gray-400">Target Register</label>
                <select
                  value={simSubject}
                  onChange={(e) => setSimSubject(e.target.value)}
                  className="w-full text-xs p-2 rounded-xl neu-inset bg-brand-surface dark:bg-brand-dark-surface dark:text-gray-100 focus:outline-none"
                >
                  {subjectData.map(s => (
                    <option key={s.id} value={s.id}>{s.name}</option>
                  ))}
                </select>
              </div>

              {/* Slider for Missed classes */}
              <div className="space-y-1.5">
                <div className="flex justify-between text-[10px] font-mono font-bold text-brand-on-variant dark:text-gray-400">
                  <span>MISS UPCOMING CLASSES</span>
                  <span className="text-brand-primary dark:text-indigo-400">+{simMissed} classes</span>
                </div>
                <input 
                  type="range" 
                  min="0" 
                  max="6" 
                  step="1"
                  value={simMissed} 
                  onChange={(e) => setSimMissed(parseInt(e.target.value))}
                  className="w-full accent-brand-primary h-1 rounded-full bg-gray-200 dark:bg-gray-800"
                />
              </div>

              {/* Simulation Result display block */}
              <div className="p-3.5 rounded-xl neu-inset bg-slate-50/50 dark:bg-slate-900/40 border border-gray-100 dark:border-slate-800 flex justify-between items-center text-xs">
                <div>
                  <span className="text-[9px] text-brand-on-variant dark:text-gray-400 font-mono font-bold block">Simulated Outcome</span>
                  <span className={`font-extrabold text-base ${simPercentage >= 75 ? "text-emerald-600 dark:text-emerald-400" : "text-rose-500 font-extrabold"}`}>
                    {simPercentage.toFixed(1)}%
                  </span>
                </div>

                <div>
                  {simPercentage >= 75 ? (
                    <span className="text-[9px] font-bold bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 px-2 py-0.5 rounded font-mono uppercase">
                      ✓ Above 75% Min
                    </span>
                  ) : (
                    <span className="text-[9px] font-bold bg-rose-500/10 text-rose-500 px-2 py-0.5 rounded font-mono uppercase animate-pulse">
                      🚨 Below 75% Limit
                    </span>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* Leave Application Slips */}
          <div className="p-6 rounded-2xl neu-flat space-y-4">
            <h3 className="font-bold text-brand-on-surface dark:text-gray-100 flex items-center gap-2 text-md">
              <FileText size={16} className="text-brand-primary dark:text-indigo-400" />
              File Leave Slips
            </h3>

            <AnimatePresence>
              {leaveSuccess ? (
                <motion.div
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="p-4 bg-emerald-500/10 border border-emerald-500/20 rounded-xl text-center space-y-1.5 text-emerald-600 dark:text-emerald-400"
                >
                  <CheckCircle size={24} className="mx-auto" />
                  <div className="text-xs font-bold">Leave Slip Transmitted!</div>
                  <div className="text-[10px]">Your leave request has been submitted for Registrar review. Check notification inbox for approvals.</div>
                </motion.div>
              ) : (
                <form onSubmit={handleLeaveSubmit} className="space-y-3">
                  <div className="space-y-1">
                    <label className="text-[10px] font-mono font-bold uppercase text-brand-on-variant dark:text-gray-400 font-sans">Leave Category</label>
                    <select
                      value={leaveType}
                      onChange={(e) => setLeaveType(e.target.value)}
                      className="w-full text-xs p-2 rounded-xl neu-inset bg-brand-surface dark:bg-brand-dark-surface dark:text-gray-100 focus:outline-none"
                      required
                    >
                      <option value="">Select...</option>
                      <option value="medical">Medical Slip (Certificate Needed)</option>
                      <option value="academic">Academic Leave (Seminars/Drills)</option>
                      <option value="personal">Personal Leave</option>
                    </select>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-1">
                      <label className="text-[10px] font-mono font-bold uppercase text-brand-on-variant dark:text-gray-400">Start Date</label>
                      <input
                        type="date"
                        value={leaveStart}
                        onChange={(e) => setLeaveStart(e.target.value)}
                        className="w-full text-[11px] p-2 rounded-xl neu-inset bg-brand-surface dark:bg-brand-dark-surface dark:text-gray-100 focus:outline-none"
                        required
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[10px] font-mono font-bold uppercase text-brand-on-variant dark:text-gray-400">End Date</label>
                      <input
                        type="date"
                        value={leaveEnd}
                        onChange={(e) => setLeaveEnd(e.target.value)}
                        className="w-full text-[11px] p-2 rounded-xl neu-inset bg-brand-surface dark:bg-brand-dark-surface dark:text-gray-100 focus:outline-none"
                        required
                      />
                    </div>
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-mono font-bold uppercase text-brand-on-variant dark:text-gray-400 font-sans">Justification / Reason</label>
                    <textarea
                      value={leaveReason}
                      onChange={(e) => setLeaveReason(e.target.value)}
                      rows={2}
                      placeholder="e.g., Hospitalized for viral fever, out of town representation..."
                      className="w-full text-xs p-2 rounded-xl neu-inset bg-brand-surface dark:bg-brand-dark-surface dark:text-gray-100 focus:outline-none resize-none leading-relaxed"
                      required
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full py-2.5 bg-brand-primary hover:bg-brand-primary-container text-white text-xs font-bold rounded-xl shadow-md cursor-pointer transition-all"
                  >
                    Transmit Official Slip
                  </button>
                </form>
              )}
            </AnimatePresence>
          </div>
        </div>
      </div>
    </div>
  );
}
