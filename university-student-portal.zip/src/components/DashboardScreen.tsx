import React, { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  BookOpen, 
  Clock, 
  Calendar, 
  ArrowRight, 
  Sparkles, 
  Send, 
  AlertCircle, 
  CheckCircle, 
  Download, 
  ChevronRight, 
  TrendingUp, 
  Mic, 
  User 
} from "lucide-react";
import { ScheduleClass, Assignment, ChatMessage } from "../types";
import { WEEKLY_SCHEDULE, INITIAL_ASSIGNMENTS, UPCOMING_INTERVIEWS, FINANCE_INSTALLMENTS } from "../data";

interface DashboardProps {
  onNavigate: (tab: string) => void;
  isDark: boolean;
}

export default function DashboardScreen({ onNavigate, isDark }: DashboardProps) {
  // Countdown state for DSA Exam (Starts tomorrow at 9 AM. Let's make it count down in real time!)
  const [timeLeft, setTimeLeft] = useState({ hours: 14, minutes: 32, seconds: 45 });
  
  // Chat modal state
  const [chatOpen, setChatOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: "welcome-1",
      sender: "ai",
      text: "Hello Austin! I'm Aura, your AI Study Assistant. I see you have your **Data Structures & Algorithms** midterm coming up tomorrow. Need some help reviewing trees, graphs, or sorting algorithms?",
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    }
  ]);
  const [inputVal, setInputVal] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Ticker for Midterm Exam Countdown
    const timer = setInterval(() => {
      setTimeLeft(prev => {
        if (prev.seconds > 0) {
          return { ...prev, seconds: prev.seconds - 1 };
        } else if (prev.minutes > 0) {
          return { ...prev, minutes: prev.minutes - 1, seconds: 59 };
        } else if (prev.hours > 0) {
          return { hours: prev.hours - 1, minutes: 59, seconds: 59 };
        } else {
          return { hours: 12, minutes: 0, seconds: 0 }; // Loop it safely
        }
      });
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [messages, isTyping]);

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputVal.trim()) return;

    const userMsg: ChatMessage = {
      id: `msg-${Date.now()}`,
      sender: "user",
      text: inputVal,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages(prev => [...prev, userMsg]);
    setInputVal("");
    setIsTyping(true);

    try {
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          messages: [...messages, userMsg].map(m => ({ text: m.text, role: m.sender })),
          context: {
            studentName: "Austin Reaves",
            major: "B.Tech Computer Science Engineering",
            semester: "4th Semester",
            gpa: 3.72,
            upcomingExam: "Data Structures & Algorithms Midterm",
            pendingAssignments: ["Fourier Transform & PDEs", "Zeeman Effect Experiment"]
          }
        })
      });

      const data = await response.json();
      setIsTyping(false);

      if (data.error) {
        setMessages(prev => [
          ...prev,
          {
            id: `msg-err-${Date.now()}`,
            sender: "ai",
            text: `⚠️ AI Key Offline: ${data.error}. To enable dynamic live chat, please make sure your **GEMINI_API_KEY** is added in the Secrets panel in AI Studio settings!`,
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
          }
        ]);
      } else {
        setMessages(prev => [
          ...prev,
          {
            id: `msg-ai-${Date.now()}`,
            sender: "ai",
            text: data.text,
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
          }
        ]);
      }
    } catch (err) {
      setIsTyping(false);
      setMessages(prev => [
        ...prev,
        {
          id: `msg-err-${Date.now()}`,
          sender: "ai",
          text: "⚠️ Aura is currently studying in local mode. Please make sure the backend server is running and your API keys are configured properly.",
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        }
      ]);
    }
  };

  // Compile and sort the next 3 urgent assignments or events
  const getUpcomingDeadlines = () => {
    const deadlines: {
      id: string;
      title: string;
      subject: string;
      type: "Assignment" | "Exam" | "Placement" | "Finance";
      dueDate: string;
      timeLeft: string;
      urgency: "Critical" | "High" | "Medium";
      dateRank: number;
      actionLabel: string;
      targetTab: string;
    }[] = [];

    // 1. Pending Assignments
    INITIAL_ASSIGNMENTS.filter(a => a.status === "Pending").forEach(a => {
      let dateRank = 999;
      if (a.id === "assign-1") dateRank = 1; // Tomorrow
      else if (a.id === "assign-2") dateRank = 3; // July 4
      else if (a.id === "assign-3") dateRank = 5; // July 8

      deadlines.push({
        id: a.id,
        title: a.title,
        subject: a.subject,
        type: "Assignment",
        dueDate: a.dueDate,
        timeLeft: a.timeLeft || "Soon",
        urgency: a.id === "assign-1" ? "Critical" : "High",
        dateRank,
        actionLabel: "Submit Now",
        targetTab: "Assignments"
      });
    });

    // 2. Upcoming Interviews
    UPCOMING_INTERVIEWS.forEach(i => {
      let dateRank = 999;
      if (i.id === "int-1") dateRank = 2; // July 2
      else if (i.id === "int-2") dateRank = 4; // July 6
      else if (i.id === "int-3") dateRank = 7; // July 15

      deadlines.push({
        id: i.id,
        title: `${i.company} Interview`,
        subject: i.round,
        type: "Placement",
        dueDate: i.time,
        timeLeft: i.id === "int-1" ? "2 days left" : "6 days left",
        urgency: i.id === "int-1" ? "High" : "Medium",
        dateRank,
        actionLabel: "Prepare with AI",
        targetTab: "Placements"
      });
    });

    // 3. Pending Finance Installments
    FINANCE_INSTALLMENTS.filter(f => f.status === "Pending").forEach(f => {
      let dateRank = 999;
      if (f.id === "inst-3") dateRank = 6; // July 10
      else if (f.id === "inst-4") dateRank = 8; // Oct 15

      deadlines.push({
        id: f.id,
        title: f.name,
        subject: `Fee Payment: $${f.amount}`,
        type: "Finance",
        dueDate: f.dueDate,
        timeLeft: f.id === "inst-3" ? "10 days left" : "Months away",
        urgency: f.id === "inst-3" ? "Medium" : "Medium",
        dateRank,
        actionLabel: "Pay Fees",
        targetTab: "Finance"
      });
    });

    // Sort by chronological/importance dateRank and pick top 3
    return deadlines.sort((a, b) => a.dateRank - b.dateRank).slice(0, 3);
  };

  const upcomingDeadlines = getUpcomingDeadlines();

  return (
    <div className="space-y-8 pb-10" id="dashboard-root">
      {/* 1. Welcoming Student Card - Neumorphic extruded panel */}
      <motion.div 
        initial={{ opacity: 0, y: 15 }} 
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        className="p-6 rounded-2xl neu-flat flex flex-col md:flex-row items-center justify-between gap-6"
        id="welcome-card"
      >
        <div className="flex items-center gap-5">
          <div className="w-16 h-16 rounded-full neu-inset p-1 flex items-center justify-center relative bg-brand-surface dark:bg-brand-dark-surface" id="student-avatar-ring">
            <img 
              src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=200&auto=format&fit=crop" 
              alt="Austin Reaves" 
              className="w-14 h-14 rounded-full object-cover"
              referrerPolicy="no-referrer"
            />
            <div className="absolute bottom-0 right-0 w-4 h-4 rounded-full border-2 border-brand-surface dark:border-brand-dark-bg bg-emerald-500 animate-pulse" />
          </div>
          <div className="text-center md:text-left">
            <div className="flex items-center gap-2 justify-center md:justify-start">
              <span className="text-xs font-mono px-2 py-0.5 rounded-full bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 font-semibold uppercase tracking-wider">
                ID: CSE-2024-048
              </span>
            </div>
            <h1 className="text-2xl font-bold font-sans text-brand-on-surface dark:text-gray-100 mt-1">
              Welcome Back, Austin!
            </h1>
            <p className="text-sm text-brand-on-variant dark:text-gray-400 mt-0.5">
              B.Tech Computer Science & Engineering • <span className="font-semibold text-brand-primary dark:text-indigo-400">4th Semester</span>
            </p>
          </div>
        </div>

        {/* Live status cards */}
        <div className="flex items-center gap-4 w-full md:w-auto overflow-x-auto py-1">
          <div className="flex-1 md:flex-initial px-4 py-2 rounded-xl neu-inset text-center min-w-[100px]">
            <span className="text-xs text-brand-on-variant dark:text-gray-400 font-medium">CGPA</span>
            <div className="text-lg font-bold text-brand-primary dark:text-indigo-400">3.72</div>
          </div>
          <div className="flex-1 md:flex-initial px-4 py-2 rounded-xl neu-inset text-center min-w-[100px]">
            <span className="text-xs text-brand-on-variant dark:text-gray-400 font-medium">Attendance</span>
            <div className="text-lg font-bold text-emerald-600 dark:text-emerald-400">86.4%</div>
          </div>
          <div className="flex-1 md:flex-initial px-4 py-2 rounded-xl neu-inset text-center min-w-[100px]">
            <span className="text-xs text-brand-on-variant dark:text-gray-400 font-medium">Rank</span>
            <div className="text-lg font-bold text-amber-500 dark:text-amber-400">#12</div>
          </div>
        </div>
      </motion.div>

      {/* 2. Core Dashboard Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left Column: Today's Schedule & Academic rings */}
        <div className="lg:col-span-2 space-y-8">
          {/* Neumorphic Grid for circular KPI trackers */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            {/* CGPA Progress Dial */}
            <div className="p-6 rounded-2xl neu-flat flex items-center justify-between gap-4">
              <div className="space-y-1">
                <span className="text-xs font-mono uppercase tracking-wider text-brand-on-variant dark:text-gray-400">Cumulative GPA</span>
                <h3 className="text-xl font-bold text-brand-on-surface dark:text-gray-100">Excellent Standing</h3>
                <p className="text-xs text-brand-on-variant dark:text-gray-400">Target of 3.80 is within reach this semester.</p>
                <button 
                  onClick={() => onNavigate("Grades")}
                  className="text-xs font-semibold text-brand-primary dark:text-indigo-400 hover:underline flex items-center gap-1 mt-2 cursor-pointer"
                >
                  Predict CGPA <ChevronRight size={14} />
                </button>
              </div>
              <div className="relative w-24 h-24 flex items-center justify-center flex-shrink-0">
                <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
                  <circle cx="50" cy="50" r="40" stroke="rgba(163, 177, 198, 0.2)" strokeWidth="8" fill="transparent" />
                  <circle 
                    cx="50" cy="50" r="40" 
                    stroke="var(--color-brand-primary)" 
                    strokeWidth="8" 
                    fill="transparent" 
                    strokeDasharray="251.2"
                    strokeDashoffset={(251.2 - (251.2 * 3.72) / 4.0).toString()}
                    strokeLinecap="round"
                    className="transition-all duration-1000 ease-out"
                  />
                </svg>
                <div className="absolute inset-0 flex flex-col items-center justify-center">
                  <span className="text-lg font-bold text-brand-on-surface dark:text-gray-100">3.72</span>
                  <span className="text-[9px] text-brand-on-variant dark:text-gray-400 font-semibold uppercase">of 4.0</span>
                </div>
              </div>
            </div>

            {/* Attendance Progress Dial */}
            <div className="p-6 rounded-2xl neu-flat flex items-center justify-between gap-4">
              <div className="space-y-1">
                <span className="text-xs font-mono uppercase tracking-wider text-brand-on-variant dark:text-gray-400">Total Attendance</span>
                <h3 className="text-xl font-bold text-emerald-600 dark:text-emerald-400">Safe Status</h3>
                <p className="text-xs text-brand-on-variant dark:text-gray-400">Bunk safety: You can miss 2 more Advanced Math classes.</p>
                <button 
                  onClick={() => onNavigate("Attendance")}
                  className="text-xs font-semibold text-emerald-600 dark:text-emerald-400 hover:underline flex items-center gap-1 mt-2 cursor-pointer"
                >
                  Bunk Simulator <ChevronRight size={14} />
                </button>
              </div>
              <div className="relative w-24 h-24 flex items-center justify-center flex-shrink-0">
                <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
                  <circle cx="50" cy="50" r="40" stroke="rgba(163, 177, 198, 0.2)" strokeWidth="8" fill="transparent" />
                  <circle 
                    cx="50" cy="50" r="40" 
                    stroke="#10b981" 
                    strokeWidth="8" 
                    fill="transparent" 
                    strokeDasharray="251.2"
                    strokeDashoffset={(251.2 - (251.2 * 86.4) / 100.0).toString()}
                    strokeLinecap="round"
                  />
                </svg>
                <div className="absolute inset-0 flex flex-col items-center justify-center">
                  <span className="text-lg font-bold text-emerald-600 dark:text-emerald-400">86.4%</span>
                  <span className="text-[9px] text-emerald-500 font-semibold uppercase">Min 75%</span>
                </div>
              </div>
            </div>
          </div>

          {/* Today's Schedule Card */}
          <div className="p-6 rounded-2xl neu-flat space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Clock className="text-brand-primary dark:text-indigo-400" size={18} />
                <h2 className="text-lg font-bold text-brand-on-surface dark:text-gray-100">Today's Schedule</h2>
              </div>
              <button 
                onClick={() => onNavigate("Schedule")}
                className="text-xs font-semibold text-brand-primary dark:text-indigo-400 flex items-center gap-1 hover:underline cursor-pointer"
              >
                View Full Calendar <ArrowRight size={12} />
              </button>
            </div>

            <div className="space-y-4">
              {WEEKLY_SCHEDULE.map((cls, index) => (
                <div 
                  key={cls.id} 
                  className={`p-4 rounded-xl flex items-center justify-between gap-4 transition-all ${
                    cls.active 
                      ? "neu-inset border-l-4 border-brand-primary bg-indigo-50/25 dark:bg-indigo-950/25" 
                      : "neu-flat hover:neu-inset"
                  }`}
                >
                  <div className="flex items-center gap-4">
                    <div className="text-center w-14 flex-shrink-0">
                      <div className="text-sm font-extrabold text-brand-primary dark:text-indigo-400">{cls.time}</div>
                      <div className="text-[10px] uppercase font-mono text-brand-on-variant dark:text-gray-400 font-semibold">{cls.period}</div>
                    </div>
                    <div className="h-8 w-[1px] bg-gray-300 dark:bg-gray-700" />
                    <div>
                      <div className="text-sm font-bold text-brand-on-surface dark:text-gray-100 flex items-center gap-2">
                        {cls.subject}
                        {cls.active && (
                          <span className="text-[9px] font-mono font-bold bg-indigo-500 text-white px-1.5 py-0.5 rounded-full uppercase tracking-wider animate-pulse">
                            Active Now
                          </span>
                        )}
                      </div>
                      <div className="text-xs text-brand-on-variant dark:text-gray-400 mt-0.5">
                        {cls.instructor} • <span className="font-mono">{cls.room}</span>
                      </div>
                    </div>
                  </div>

                  <div>
                    {cls.active ? (
                      <a 
                        href="https://meet.google.com" 
                        target="_blank" 
                        rel="noreferrer"
                        className="text-xs px-3 py-1.5 rounded-lg bg-brand-primary hover:bg-brand-primary-container text-white font-semibold transition-all shadow-md flex items-center gap-1.5 cursor-pointer"
                      >
                        Join Session
                      </a>
                    ) : (
                      <span className="text-xs font-mono text-brand-on-variant dark:text-gray-400">{cls.duration}</span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Upcoming Deadlines Section */}
          <div className="p-6 rounded-2xl neu-flat space-y-4" id="upcoming-deadlines-section">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Calendar className="text-brand-primary dark:text-indigo-400" size={18} />
                <h2 className="text-lg font-bold text-brand-on-surface dark:text-gray-100 font-sans">Upcoming Deadlines</h2>
              </div>
              <span className="text-[10px] font-mono font-bold bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 px-2.5 py-0.5 rounded-full uppercase tracking-wider">
                Urgent Actions
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {upcomingDeadlines.map((deadline) => {
                // Determine category badge colors
                let badgeStyle = "bg-rose-500/10 text-rose-500 dark:bg-rose-500/20 dark:text-rose-400";
                if (deadline.type === "Placement") {
                  badgeStyle = "bg-amber-500/10 text-amber-600 dark:bg-amber-500/20 dark:text-amber-400";
                } else if (deadline.type === "Finance") {
                  badgeStyle = "bg-emerald-500/10 text-emerald-600 dark:bg-emerald-500/20 dark:text-emerald-400";
                }

                // Determine urgency style
                let urgencyStyle = "border-rose-500/30 text-rose-500 bg-rose-500/5";
                if (deadline.urgency === "High") {
                  urgencyStyle = "border-amber-500/30 text-amber-500 bg-amber-500/5";
                } else if (deadline.urgency === "Medium") {
                  urgencyStyle = "border-indigo-500/30 text-indigo-500 bg-indigo-500/5";
                }

                return (
                  <div 
                    key={deadline.id} 
                    className="p-4 rounded-xl neu-inset flex flex-col justify-between gap-4 border border-brand-container/20 hover:border-brand-primary/20 transition-all group"
                  >
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className={`text-[9px] font-mono font-bold px-2 py-0.5 rounded-full uppercase tracking-wider ${badgeStyle}`}>
                          {deadline.type}
                        </span>
                        <span className={`text-[9px] font-mono font-extrabold px-1.5 py-0.5 rounded border ${urgencyStyle}`}>
                          {deadline.urgency}
                        </span>
                      </div>

                      <div>
                        <h3 className="text-xs font-bold text-brand-on-surface dark:text-gray-100 leading-tight line-clamp-1 group-hover:text-brand-primary dark:group-hover:text-indigo-400 transition-colors">
                          {deadline.title}
                        </h3>
                        <p className="text-[10px] text-brand-on-variant dark:text-gray-400 font-mono mt-0.5 truncate">
                          {deadline.subject}
                        </p>
                      </div>
                    </div>

                    <div className="space-y-2 border-t border-brand-container/10 dark:border-slate-800/40 pt-2">
                      <div className="flex items-center justify-between text-[10px] font-mono">
                        <span className="text-gray-400">Scheduled:</span>
                        <span className="text-brand-on-surface dark:text-gray-200 font-bold truncate max-w-[100px] text-right">{deadline.dueDate}</span>
                      </div>
                      <div className="flex items-center justify-between text-[10px] font-mono">
                        <span className="text-gray-400">Time Left:</span>
                        <span className="text-rose-500 dark:text-rose-400 font-bold">{deadline.timeLeft}</span>
                      </div>

                      <button
                        onClick={() => onNavigate(deadline.targetTab)}
                        className="w-full mt-1 py-1.5 rounded-lg bg-brand-surface dark:bg-slate-900 hover:bg-brand-primary hover:text-white dark:hover:bg-indigo-600 dark:hover:text-white text-[10px] font-bold text-brand-primary dark:text-indigo-400 border border-brand-primary/20 dark:border-indigo-500/20 hover:border-transparent transition-all flex items-center justify-center gap-1 cursor-pointer"
                      >
                        {deadline.actionLabel} <ArrowRight size={10} />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Right Column: Countdown, AI helper prompt, pending assignments */}
        <div className="space-y-8">
          {/* Critical midterm countdown */}
          <div className="p-6 rounded-2xl neu-flat bg-gradient-to-br from-indigo-50 to-indigo-100/50 dark:from-slate-900 dark:to-indigo-950/25 text-brand-on-surface dark:text-gray-100 border border-indigo-100/20 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-24 h-24 bg-indigo-500/5 rounded-full -mr-6 -mt-6" />
            <div className="space-y-4 relative">
              <div className="flex items-center gap-2 text-indigo-600 dark:text-indigo-400 font-semibold text-xs uppercase tracking-wider font-mono">
                <AlertCircle size={14} className="animate-bounce" />
                Critical Exam Countdown
              </div>
              <div>
                <h3 className="font-extrabold text-lg leading-tight">Data Structures &amp; Algorithms</h3>
                <p className="text-xs text-brand-on-variant dark:text-gray-400 mt-0.5">Mid-Term Assessment • Lecture Hall C</p>
              </div>

              {/* Countdown Ticker Box */}
              <div className="flex justify-between gap-2 bg-white/60 dark:bg-black/30 p-3 rounded-xl neu-inset">
                <div className="text-center flex-1">
                  <div className="text-2xl font-mono font-extrabold text-brand-primary dark:text-indigo-400">
                    {timeLeft.hours.toString().padStart(2, "0")}
                  </div>
                  <span className="text-[9px] text-brand-on-variant dark:text-gray-400 font-bold uppercase">Hours</span>
                </div>
                <div className="text-xl font-bold flex items-center text-brand-primary dark:text-indigo-400 animate-pulse">:</div>
                <div className="text-center flex-1">
                  <div className="text-2xl font-mono font-extrabold text-brand-primary dark:text-indigo-400">
                    {timeLeft.minutes.toString().padStart(2, "0")}
                  </div>
                  <span className="text-[9px] text-brand-on-variant dark:text-gray-400 font-bold uppercase">Minutes</span>
                </div>
                <div className="text-xl font-bold flex items-center text-brand-primary dark:text-indigo-400 animate-pulse">:</div>
                <div className="text-center flex-1">
                  <div className="text-2xl font-mono font-extrabold text-brand-primary dark:text-indigo-400 text-rose-500 dark:text-rose-400">
                    {timeLeft.seconds.toString().padStart(2, "0")}
                  </div>
                  <span className="text-[9px] text-rose-500 dark:text-rose-400 font-bold uppercase">Seconds</span>
                </div>
              </div>

              <button 
                onClick={() => setChatOpen(true)}
                className="w-full py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition-all shadow flex items-center justify-center gap-2 cursor-pointer"
              >
                <Sparkles size={14} /> Prepare with Aura AI Coach
              </button>
            </div>
          </div>

          {/* AI Study Assistant Banner */}
          <div className="p-6 rounded-2xl neu-flat flex flex-col gap-4 relative">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-mono font-bold bg-amber-500/15 text-amber-600 dark:text-amber-400 px-2 py-0.5 rounded-full uppercase tracking-wide flex items-center gap-1">
                <Sparkles size={10} /> Active AI Copilot
              </span>
              <div className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-ping" />
            </div>
            <div className="space-y-1">
              <h3 className="font-bold text-brand-on-surface dark:text-gray-100">Need immediate homework help?</h3>
              <p className="text-xs text-brand-on-variant dark:text-gray-400 leading-relaxed">
                Connect with Aura, your private AI tutor. Answer formulas, write optimal code, review mathematical derivations, or summarize slides.
              </p>
            </div>
            <button 
              onClick={() => setChatOpen(true)}
              className="py-2.5 bg-brand-primary hover:bg-brand-primary-container text-white text-xs font-extrabold rounded-xl transition-all shadow-md flex items-center justify-center gap-2 cursor-pointer"
            >
              Start Session <ArrowRight size={14} />
            </button>
          </div>

          {/* Pending Tasks / Assignments widget */}
          <div className="p-6 rounded-2xl neu-flat space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-md font-bold text-brand-on-surface dark:text-gray-100">Pending Tasks</h2>
              <button 
                onClick={() => onNavigate("Assignments")}
                className="text-xs font-semibold text-brand-primary dark:text-indigo-400 hover:underline cursor-pointer"
              >
                All Assignments
              </button>
            </div>

            <div className="space-y-3">
              {INITIAL_ASSIGNMENTS.filter(a => a.status === "Pending").slice(0, 2).map((task) => (
                <div key={task.id} className="p-3 rounded-xl neu-inset flex items-start gap-3">
                  <div className="w-2 h-2 rounded-full bg-rose-500 mt-1.5 flex-shrink-0 animate-pulse" />
                  <div className="space-y-0.5 flex-1 min-w-0">
                    <div className="text-xs font-semibold text-brand-on-surface dark:text-gray-100 truncate">{task.title}</div>
                    <div className="text-[10px] text-brand-on-variant dark:text-gray-400 font-mono truncate">{task.subject}</div>
                  </div>
                  <div className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-rose-500/10 text-rose-500 dark:text-rose-400 font-semibold whitespace-nowrap">
                    {task.timeLeft}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Aura AI Chat overlay sliding drawer - Selective Glassmorphism panel */}
      <AnimatePresence>
        {chatOpen && (
          <div className="fixed inset-0 z-50 flex justify-end bg-black/40 backdrop-blur-xs transition-opacity">
            {/* Click backdrop to close */}
            <div className="absolute inset-0" onClick={() => setChatOpen(false)} />

            <motion.div 
              initial={{ x: "100%" }}
              animate={{ x: 0 }}
              exit={{ x: "100%" }}
              transition={{ type: "spring", damping: 25, stiffness: 220 }}
              className="relative w-full max-w-lg h-full glass-layer flex flex-col shadow-2xl border-l border-white/20"
              id="ai-sidebar-panel"
            >
              {/* Header */}
              <div className="p-5 border-b border-brand-container dark:border-brand-dark-container flex items-center justify-between bg-white/85 dark:bg-slate-900/85">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-indigo-500/10 dark:bg-indigo-500/20 p-0.5 flex items-center justify-center text-indigo-600 dark:text-indigo-400">
                    <Sparkles className="animate-spin-slow text-brand-primary dark:text-indigo-400" size={20} />
                  </div>
                  <div>
                    <h3 className="font-bold text-brand-on-surface dark:text-gray-100 flex items-center gap-1.5 text-md">
                      Aura
                      <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 uppercase tracking-wider font-bold">
                        Online
                      </span>
                    </h3>
                    <p className="text-[10px] text-brand-on-variant dark:text-gray-400">AI Academic Counselor &amp; Study Coach</p>
                  </div>
                </div>
                <button 
                  onClick={() => setChatOpen(false)}
                  className="w-8 h-8 rounded-full flex items-center justify-center neu-button hover:bg-rose-50 text-rose-600 dark:text-rose-400 font-semibold text-lg cursor-pointer"
                >
                  &times;
                </button>
              </div>

              {/* Chat history */}
              <div className="flex-1 overflow-y-auto p-5 space-y-4 bg-slate-50/50 dark:bg-slate-950/20">
                {messages.map((msg) => (
                  <div 
                    key={msg.id} 
                    className={`flex ${msg.sender === "user" ? "justify-end" : "justify-start"}`}
                  >
                    <div className={`max-w-[85%] rounded-2xl p-4 text-xs leading-relaxed shadow-sm ${
                      msg.sender === "user" 
                        ? "bg-brand-primary text-white rounded-br-none" 
                        : "bg-white dark:bg-slate-900 text-brand-on-surface dark:text-gray-200 rounded-bl-none border border-brand-container dark:border-slate-800"
                    }`}>
                      {msg.sender === "ai" ? (
                        <div className="prose prose-xs dark:prose-invert">
                          {msg.text.split("\n\n").map((para, pIdx) => (
                            <p key={pIdx} className={pIdx > 0 ? "mt-2" : ""}>
                              {para.split("**").map((part, partIdx) => 
                                partIdx % 2 === 1 ? <strong key={partIdx} className="font-extrabold">{part}</strong> : part
                              )}
                            </p>
                          ))}
                        </div>
                      ) : (
                        msg.text
                      )}
                      <div className={`text-[8px] font-mono mt-1.5 ${msg.sender === "user" ? "text-indigo-200 text-right" : "text-brand-on-variant dark:text-gray-400"}`}>
                        {msg.timestamp}
                      </div>
                    </div>
                  </div>
                ))}

                {isTyping && (
                  <div className="flex justify-start">
                    <div className="bg-white dark:bg-slate-900 rounded-2xl rounded-bl-none p-3 border border-brand-container dark:border-slate-800 shadow-sm flex items-center gap-1.5">
                      <span className="w-1.5 h-1.5 rounded-full bg-indigo-500 animate-bounce" style={{ animationDelay: "0ms" }} />
                      <span className="w-1.5 h-1.5 rounded-full bg-indigo-500 animate-bounce" style={{ animationDelay: "150ms" }} />
                      <span className="w-1.5 h-1.5 rounded-full bg-indigo-500 animate-bounce" style={{ animationDelay: "300ms" }} />
                    </div>
                  </div>
                )}
                <div ref={messagesEndRef} />
              </div>

              {/* Suggestions quick tags */}
              <div className="px-4 py-2 bg-white/70 dark:bg-slate-900/70 border-t border-brand-container dark:border-brand-dark-container flex items-center gap-2 overflow-x-auto whitespace-nowrap">
                <button 
                  onClick={() => setInputVal("Explain Dijkstra's shortest path algorithm step-by-step with complexity.")}
                  className="text-[10px] font-semibold px-2.5 py-1.5 rounded-lg neu-flat hover:neu-inset text-indigo-600 dark:text-indigo-400 cursor-pointer"
                >
                  🌳 Dijkstra's Algorithm
                </button>
                <button 
                  onClick={() => setInputVal("Give me some key sample practice questions on continuous Fourier Transform for Math midterm.")}
                  className="text-[10px] font-semibold px-2.5 py-1.5 rounded-lg neu-flat hover:neu-inset text-indigo-600 dark:text-indigo-400 cursor-pointer"
                >
                  📐 Fourier Midterm Qs
                </button>
                <button 
                  onClick={() => setInputVal("How can I map cortical activation profiles during standard cognitive linguistic testing?")}
                  className="text-[10px] font-semibold px-2.5 py-1.5 rounded-lg neu-flat hover:neu-inset text-indigo-600 dark:text-indigo-400 cursor-pointer"
                >
                  🧠 Cortical Mapping
                </button>
              </div>

              {/* Input Form */}
              <form 
                onSubmit={handleSendMessage}
                className="p-4 border-t border-brand-container dark:border-brand-dark-container flex items-center gap-3 bg-white dark:bg-slate-900"
              >
                <input 
                  type="text" 
                  value={inputVal}
                  onChange={(e) => setInputVal(e.target.value)}
                  placeholder="Ask Aura anything about your curriculum..." 
                  className="flex-1 py-2 px-3.5 rounded-xl neu-inset bg-brand-surface dark:bg-brand-dark-surface dark:text-gray-100 text-xs focus:outline-none"
                />
                <button 
                  type="submit" 
                  className="w-9 h-9 rounded-full bg-brand-primary hover:bg-brand-primary-container text-white flex items-center justify-center flex-shrink-0 shadow transition-all cursor-pointer"
                >
                  <Send size={15} />
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
