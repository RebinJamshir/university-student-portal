import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  FileText, 
  Upload, 
  Clock, 
  CheckCircle, 
  CheckCircle2, 
  AlertCircle, 
  ArrowRight, 
  Sparkles, 
  FolderOpen, 
  HelpCircle,
  Lightbulb
} from "lucide-react";
import { Assignment } from "../types";
import { INITIAL_ASSIGNMENTS } from "../data";

export default function AssignmentsScreen() {
  const [assignments, setAssignments] = useState<Assignment[]>(INITIAL_ASSIGNMENTS);
  const [expandedId, setExpandedId] = useState<string | null>("assign-1"); // Expand first by default
  const [uploadingId, setUploadingId] = useState<string | null>(null);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [selectedFile, setSelectedFile] = useState<string>("");

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>, id: string) => {
    if (e.target.files && e.target.files[0]) {
      setSelectedFile(e.target.files[0].name);
    }
  };

  const handleUploadSubmit = (id: string) => {
    if (!selectedFile) return;
    setUploadingId(id);
    setUploadProgress(0);

    // Simulate progress upload bar
    const interval = setInterval(() => {
      setUploadProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          setTimeout(() => {
            setAssignments((prevList) => 
              prevList.map((item) => 
                item.id === id 
                  ? { ...item, status: "Completed", timeLeft: undefined, countdownSeconds: undefined } 
                  : item
              )
            );
            setUploadingId(null);
            setUploadProgress(0);
            setSelectedFile("");
          }, 600);
          return 100;
        }
        return prev + 20;
      });
    }, 150);
  };

  return (
    <div className="space-y-8 pb-10" id="assignments-root">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold font-sans text-brand-on-surface dark:text-gray-100 flex items-center gap-2">
            <FileText size={24} className="text-brand-primary dark:text-indigo-400" />
            Course Assignments &amp; Hand-ins
          </h1>
          <p className="text-xs text-brand-on-variant dark:text-gray-400 mt-1">Submit digital course projects, view mid-term grades, and read grading feedback logs.</p>
        </div>

        {/* Stats Summary Panel */}
        <div className="flex items-center gap-3 w-full sm:w-auto">
          <div className="flex-1 sm:flex-initial px-4 py-2 rounded-xl neu-inset text-center min-w-[100px]">
            <span className="text-[9px] text-brand-on-variant dark:text-gray-400 font-mono uppercase font-bold">Pending</span>
            <div className="text-md font-extrabold text-rose-500">
              {assignments.filter((a) => a.status === "Pending").length}
            </div>
          </div>
          <div className="flex-1 sm:flex-initial px-4 py-2 rounded-xl neu-inset text-center min-w-[100px]">
            <span className="text-[9px] text-brand-on-variant dark:text-gray-400 font-mono uppercase font-bold">Completed</span>
            <div className="text-md font-extrabold text-brand-primary dark:text-indigo-400">
              {assignments.filter((a) => a.status !== "Pending").length}
            </div>
          </div>
        </div>
      </div>

      {/* Aura Study Insight Banner */}
      <div className="p-4 rounded-xl neu-flat bg-gradient-to-r from-amber-50 to-orange-50/20 dark:from-slate-900 dark:to-orange-950/10 border-l-4 border-amber-500 flex gap-3 text-xs leading-relaxed text-brand-on-surface dark:text-gray-200">
        <Lightbulb className="text-amber-500 flex-shrink-0 mt-0.5" size={18} />
        <div>
          <span className="font-extrabold text-amber-600 dark:text-amber-400">Aura Study Recommendation:</span> For your pending **Fourier Transform PDE mathematical derivation**, we highly recommend checking the **Fourier Analysis Cheat Sheet.pdf** in the Library Digital Repository first. It outlines continuous synthesis equations.
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left Columns - Active Pending Assignments with expandable uploads */}
        <div className="lg:col-span-2 space-y-6">
          <h2 className="text-md font-bold text-brand-on-surface dark:text-gray-100 flex items-center gap-2">
            <Clock size={16} className="text-rose-500" />
            Pending Action Items
          </h2>

          <div className="space-y-4">
            {assignments.filter((a) => a.status === "Pending").map((item) => {
              const isExpanded = expandedId === item.id;
              const isUploading = uploadingId === item.id;

              return (
                <div key={item.id} className="rounded-2xl neu-flat overflow-hidden transition-all">
                  {/* Summary trigger line */}
                  <div 
                    onClick={() => setExpandedId(isExpanded ? null : item.id)}
                    className="p-5 flex items-center justify-between gap-4 cursor-pointer hover:bg-slate-50/50 dark:hover:bg-slate-900/10"
                  >
                    <div className="min-w-0">
                      <div className="text-[10px] font-mono font-bold uppercase tracking-wider text-brand-on-variant dark:text-gray-400">
                        {item.subject}
                      </div>
                      <h3 className="text-sm font-bold text-brand-on-surface dark:text-gray-100 mt-1 truncate">
                        {item.title}
                      </h3>
                    </div>

                    <div className="flex items-center gap-3 flex-shrink-0">
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-rose-500/10 text-rose-500 dark:text-rose-400 font-bold whitespace-nowrap">
                        {item.timeLeft}
                      </span>
                    </div>
                  </div>

                  {/* Expandable Upload / Details Area */}
                  <AnimatePresence>
                    {isExpanded && (
                      <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: "auto", opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        className="border-t border-brand-container dark:border-brand-dark-container bg-brand-surface-low dark:bg-brand-dark-low"
                      >
                        <div className="p-5 space-y-4">
                          <p className="text-xs text-brand-on-variant dark:text-gray-300 leading-relaxed">
                            {item.description}
                          </p>

                          {/* Interactive Upload Block */}
                          <div className="p-4 rounded-xl neu-inset bg-brand-surface dark:bg-brand-dark-surface space-y-4">
                            <div className="flex items-center justify-between text-xs">
                              <span className="font-bold text-brand-on-surface dark:text-gray-200">Secure Submission Upload</span>
                              <span className="text-[10px] font-mono text-gray-400">Limit: PDF, ZIP (Max 15MB)</span>
                            </div>

                            {isUploading ? (
                              <div className="space-y-2 py-3 text-center">
                                <span className="text-xs font-mono font-bold text-brand-primary dark:text-indigo-400">
                                  Uploading: {uploadProgress}%
                                </span>
                                <div className="w-full bg-gray-200 dark:bg-gray-800 h-2 rounded-full overflow-hidden">
                                  <div 
                                    className="bg-brand-primary h-full transition-all duration-150"
                                    style={{ width: `${uploadProgress}%` }}
                                  />
                                </div>
                              </div>
                            ) : (
                              <div className="flex flex-col sm:flex-row items-center gap-4">
                                <label className="flex-1 w-full p-4 rounded-lg border-2 border-dashed border-gray-300 dark:border-slate-700 hover:border-brand-primary hover:bg-indigo-50/10 dark:hover:bg-slate-900/20 transition-all flex flex-col items-center justify-center gap-1.5 cursor-pointer text-center">
                                  <Upload size={20} className="text-brand-primary dark:text-indigo-400" />
                                  <span className="text-xs font-semibold text-brand-on-surface dark:text-gray-300">
                                    {selectedFile ? selectedFile : "Drag & drop or browse computer"}
                                  </span>
                                  <input 
                                    type="file" 
                                    className="hidden" 
                                    onChange={(e) => handleFileChange(e, item.id)}
                                  />
                                </label>

                                {selectedFile && (
                                  <button
                                    onClick={() => handleUploadSubmit(item.id)}
                                    className="w-full sm:w-auto px-5 py-3 rounded-lg bg-brand-primary hover:bg-brand-primary-container text-white text-xs font-bold shadow-md transition-all flex items-center justify-center gap-1.5 cursor-pointer"
                                  >
                                    Submit Hand-in
                                  </button>
                                )}
                              </div>
                            )}
                          </div>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              );
            })}

            {assignments.filter((a) => a.status === "Pending").length === 0 && (
              <div className="p-6 rounded-2xl neu-inset text-center space-y-2 text-brand-on-variant">
                <CheckCircle2 size={32} className="text-emerald-500 mx-auto" />
                <h4 className="font-bold text-sm">All Clear!</h4>
                <p className="text-xs">No pending course assignments left. You are ahead of schedule.</p>
              </div>
            )}
          </div>
        </div>

        {/* Right Column - Graded Summaries logs */}
        <div className="space-y-6">
          <h2 className="text-md font-bold text-brand-on-surface dark:text-gray-100 flex items-center gap-2">
            <CheckCircle size={16} className="text-brand-primary dark:text-indigo-400" />
            Graded Evaluations
          </h2>

          <div className="space-y-4">
            {assignments.filter((a) => a.status !== "Pending").map((item) => (
              <div key={item.id} className="p-4 rounded-2xl neu-flat space-y-3">
                <div className="flex items-center justify-between gap-2">
                  <div>
                    <span className="text-[9px] font-mono font-bold uppercase text-brand-on-variant dark:text-gray-400">{item.subject}</span>
                    <h4 className="text-xs font-bold text-brand-on-surface dark:text-gray-100 mt-0.5">{item.title}</h4>
                  </div>

                  <div className="w-9 h-9 rounded-full bg-brand-primary/10 text-brand-primary dark:text-indigo-400 font-extrabold text-xs flex items-center justify-center border border-brand-primary/20 flex-shrink-0">
                    {item.grade || "Recv"}
                  </div>
                </div>

                {item.feedback && (
                  <p className="p-3 rounded-xl neu-inset text-[11px] text-brand-on-variant dark:text-gray-300 leading-relaxed font-sans">
                    <span className="font-bold block text-brand-on-surface dark:text-gray-200 mb-0.5">Faculty Feedback:</span>
                    "{item.feedback}"
                  </p>
                )}

                <div className="flex items-center justify-between text-[10px] text-brand-on-variant dark:text-gray-400 font-mono">
                  <span>Processed June 2026</span>
                  <span className="text-emerald-600 dark:text-emerald-400 font-bold flex items-center gap-1">
                    <CheckCircle2 size={12} /> Logged in system
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
