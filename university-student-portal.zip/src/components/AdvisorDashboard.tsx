import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Users, 
  AlertCircle, 
  Calendar, 
  FileText, 
  Award, 
  Notebook, 
  ChevronRight, 
  Search, 
  User, 
  Activity, 
  Send, 
  Clock, 
  ChevronLeft,
  BookOpen
} from "lucide-react";
import { 
  Profile, 
  Enrollment, 
  AttendanceRecord, 
  Assignment, 
  AssignmentSubmission, 
  Exam, 
  ExamMark, 
  AdvisorNote 
} from "../types";

interface AdvisorDashboardProps {
  currentAdvisor: Profile;
  profiles: Profile[];
  enrollments: Enrollment[];
  attendance: AttendanceRecord[];
  assignments: Assignment[];
  submissions: AssignmentSubmission[];
  exams: Exam[];
  examMarks: ExamMark[];
  advisorNotes: AdvisorNote[];
  onAddAdvisorNote: (note: AdvisorNote) => void;
  onAddAuditLog: (action: string, entity: string, entityType: string, metadata?: string) => void;
}

export default function AdvisorDashboard({
  currentAdvisor,
  profiles,
  enrollments,
  attendance,
  assignments,
  submissions,
  exams,
  examMarks,
  advisorNotes,
  onAddAdvisorNote,
  onAddAuditLog
}: AdvisorDashboardProps) {
  const [activeSubTab, setActiveSubTab] = useState<string>("Overview");
  const [selectedStudentId, setSelectedStudentId] = useState<string | null>(null);

  // Search state
  const [searchText, setSearchText] = useState("");
  const [sortField, setSortField] = useState<"attendance" | "name">("name");

  // New Note State
  const [newNoteText, setNewNoteText] = useState("");
  const [noteSuccess, setNoteSuccess] = useState<string | null>(null);

  // Filter profiles to ONLY include students assigned to this advisor
  const myAdvisees = profiles.filter(
    p => p.role === "student" && p.advisorId === currentAdvisor.id
  );

  // Helper: calculate attendance rate for a student
  const getStudentAttendanceStats = (studentId: string) => {
    const studentEnrollments = enrollments.filter(e => e.studentId === studentId);
    if (studentEnrollments.length === 0) return { percentage: 0, total: 0, present: 0 };

    // Get all records for this student
    const studentRecords = attendance.filter(a => a.studentId === studentId);
    if (studentRecords.length === 0) {
      // Seed fallback rate based on existing subject attendance or return mock perfect rate
      // Austin Reaves is student-1 (we know his real statistics are high except Cognitive Neuroscience)
      if (studentId === "student-1") return { percentage: 89.0, total: 139, present: 118 };
      if (studentId === "student-2") return { percentage: 91.5, total: 112, present: 102 };
      if (studentId === "student-3") return { percentage: 48.0, total: 98, present: 47 }; // Defaulter!
      if (studentId === "student-4") return { percentage: 82.5, total: 80, present: 66 };
      if (studentId === "student-5") return { percentage: 76.0, total: 90, present: 68 }; // Defaulter!
      return { percentage: 85.0, total: 100, present: 85 };
    }

    const presentCount = studentRecords.filter(r => r.status === "Present").length;
    const totalCount = studentRecords.filter(r => r.status !== "No Class").length;

    const percentage = totalCount > 0 ? (presentCount / totalCount) * 100 : 85;
    return { percentage: Math.round(percentage * 10) / 10, total: totalCount, present: presentCount };
  };

  // Helper: get pending overdue assignment count
  const getStudentOverdueAssignments = (studentId: string) => {
    // Overdue counts as status === "Pending" in assignments list for which they have enrolled subjects
    const enrolledSubjectCodes = enrollments.filter(e => e.studentId === studentId).map(e => e.subjectCode);
    const pendingAssignments = assignments.filter(
      a => a.status === "Pending" && enrolledSubjectCodes.includes(
        // Map subject name to code
        a.subject === "Advanced Mathematics" ? "MTH-401" :
        a.subject === "Quantum Physics Lab" ? "PHY-402L" :
        a.subject === "Cognitive Neuroscience" ? "NEU-405" :
        a.subject === "Data Structures & Algorithms" ? "CSE-409" : "SWE-412"
      )
    );

    // Filter out submissions already made
    const overdueList = pendingAssignments.filter(a => {
      const submitted = submissions.some(s => s.assignmentId === a.id && s.studentId === studentId);
      return !submitted;
    });

    return overdueList;
  };

  // Helper: get failing exam grades (failing threshold < 40% i.e. < 20 out of 50)
  const getFailingGrades = (studentId: string) => {
    return examMarks.filter(
      m => m.studentId === studentId && m.published && (m.score / m.maxScore) < 0.45
    );
  };

  // Compile Advisee Alerts
  const compileAlerts = () => {
    const alerts: {
      studentId: string;
      studentName: string;
      rollNumber: string;
      type: "Attendance Shortage" | "Overdue Tasks" | "Failing Grades";
      desc: string;
      severity: "Critical" | "High" | "Medium";
    }[] = [];

    myAdvisees.forEach(adv => {
      const att = getStudentAttendanceStats(adv.id);
      if (att.percentage < 75) {
        alerts.push({
          studentId: adv.id,
          studentName: adv.name,
          rollNumber: adv.rollNumber || "N/A",
          type: "Attendance Shortage",
          desc: `Severe attendance default rate of ${att.percentage}% (Requires review)`,
          severity: "Critical"
        });
      } else if (att.percentage < 80) {
        alerts.push({
          studentId: adv.id,
          studentName: adv.name,
          rollNumber: adv.rollNumber || "N/A",
          type: "Attendance Shortage",
          desc: `Borderline attendance rate of ${att.percentage}%`,
          severity: "High"
        });
      }

      const overdue = getStudentOverdueAssignments(adv.id);
      if (overdue.length >= 2) {
        alerts.push({
          studentId: adv.id,
          studentName: adv.name,
          rollNumber: adv.rollNumber || "N/A",
          type: "Overdue Tasks",
          desc: `Missing ${overdue.length} pending syllabus tasks & submissions`,
          severity: "High"
        });
      }

      const failing = getFailingGrades(adv.id);
      if (failing.length > 0) {
        alerts.push({
          studentId: adv.id,
          studentName: adv.name,
          rollNumber: adv.rollNumber || "N/A",
          type: "Failing Grades",
          desc: `Scored failing grades in ${failing.length} published exams`,
          severity: "Critical"
        });
      }
    });

    return alerts;
  };

  const adviseeAlerts = compileAlerts();

  // Search/Sort advisees
  const getSortedAdvisees = () => {
    const list = myAdvisees.filter(adv => {
      if (searchText === "") return true;
      return adv.name.toLowerCase().includes(searchText.toLowerCase()) || 
             (adv.rollNumber && adv.rollNumber.toLowerCase().includes(searchText.toLowerCase()));
    });

    if (sortField === "attendance") {
      return [...list].sort((a, b) => getStudentAttendanceStats(a.id).percentage - getStudentAttendanceStats(b.id).percentage);
    }
    return [...list].sort((a, b) => a.name.localeCompare(b.name));
  };

  // Submit Note
  const handleSaveNote = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedStudentId || !newNoteText.trim()) return;

    const newNote: AdvisorNote = {
      id: `note-${Date.now()}`,
      studentId: selectedStudentId,
      advisorId: currentAdvisor.id,
      advisorName: currentAdvisor.name,
      note: newNoteText,
      createdAt: new Date().toISOString()
    };

    onAddAdvisorNote(newNote);
    onAddAuditLog(
      `Logged confidential advisor timeline note for advisee student`,
      selectedStudentId,
      "Advisor Note"
    );

    setNoteSuccess("Note recorded in secure student advisor ledger.");
    setNewNoteText("");
    setTimeout(() => setNoteSuccess(null), 3000);
  };

  // Student specific details
  const studentDetail = profiles.find(p => p.id === selectedStudentId);
  const detailAttendance = selectedStudentId ? getStudentAttendanceStats(selectedStudentId) : { percentage: 0, total: 0, present: 0 };
  const detailOverdue = selectedStudentId ? getStudentOverdueAssignments(selectedStudentId) : [];
  const detailNotes = selectedStudentId ? advisorNotes.filter(n => n.studentId === selectedStudentId) : [];
  const detailMarks = selectedStudentId ? examMarks.filter(m => m.studentId === selectedStudentId && m.published) : [];

  return (
    <div className="space-y-8 pb-10" id="advisor-dashboard-root">
      {/* Advisor Welcome Info */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold font-sans text-brand-on-surface dark:text-gray-100 flex items-center gap-2">
            <Notebook size={24} className="text-brand-primary dark:text-indigo-400" />
            Advisory Console: {currentAdvisor.name}
          </h1>
          <p className="text-xs text-brand-on-variant dark:text-gray-400 mt-1">
            Pastoral Counselor Portfolio | Registered Advisees: {myAdvisees.length} students
          </p>
        </div>

        {/* Subtabs tabs */}
        <div className="flex gap-2" id="advisor-subtabs">
          {["Overview", "Advisees Directory"].map((tab) => (
            <button
              key={tab}
              id={`advisor-tab-${tab.toLowerCase().replace(/ /g, "-")}`}
              onClick={() => {
                setActiveSubTab(tab);
                setSelectedStudentId(null);
              }}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold cursor-pointer transition-all ${
                activeSubTab === tab && !selectedStudentId
                  ? "neu-inset border border-brand-primary/20 text-brand-primary dark:text-indigo-400 font-extrabold"
                  : "neu-flat text-brand-on-variant dark:text-gray-400 hover:text-brand-on-surface"
              }`}
            >
              {tab}
            </button>
          ))}
        </div>
      </div>

      <AnimatePresence mode="wait">
        <motion.div
          key={selectedStudentId ? "detail" : activeSubTab}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -10 }}
          transition={{ duration: 0.15 }}
          className="space-y-8"
        >
          {/* ==================== 1. OVERVIEW SCREEN ==================== */}
          {activeSubTab === "Overview" && !selectedStudentId && (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              {/* Main Column: Alerts aggregated */}
              <div className="lg:col-span-2 space-y-6">
                <div className="p-6 rounded-2xl neu-flat space-y-4">
                  <div className="flex items-center justify-between border-b border-brand-container pb-3">
                    <h3 className="font-bold text-md text-brand-on-surface dark:text-gray-100 flex items-center gap-2">
                      <AlertCircle size={18} className="text-brand-primary dark:text-indigo-400" />
                      Advisee Academic Health Warnings
                    </h3>
                    <span className="text-[10px] font-mono font-bold bg-rose-500/10 text-rose-500 px-2.5 py-0.5 rounded-full uppercase">
                      {adviseeAlerts.length} Active Alerts
                    </span>
                  </div>

                  <div className="space-y-3.5">
                    {adviseeAlerts.map((alert, idx) => (
                      <div 
                        key={idx} 
                        className={`p-4 rounded-xl neu-inset border flex items-start justify-between gap-4 transition-all ${
                          alert.severity === "Critical" 
                            ? "border-rose-500/20 bg-rose-500/[0.02]" 
                            : alert.severity === "High"
                              ? "border-amber-500/20 bg-amber-500/[0.02]"
                              : "border-indigo-500/20"
                        }`}
                      >
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <span className="text-xs font-bold text-brand-on-surface dark:text-gray-100">
                              {alert.studentName}
                            </span>
                            <span className="text-[9px] font-mono text-gray-400">({alert.rollNumber})</span>
                          </div>
                          <p className="text-[11px] text-gray-400 font-medium leading-relaxed">{alert.desc}</p>
                          <span className={`text-[8px] font-mono font-extrabold px-1.5 py-0.5 rounded border uppercase inline-block mt-1 ${
                            alert.severity === "Critical"
                              ? "border-rose-500/30 text-rose-500 bg-rose-500/5"
                              : "border-amber-500/30 text-amber-500 bg-amber-500/5"
                          }`}>
                            {alert.type} • {alert.severity}
                          </span>
                        </div>

                        <button
                          onClick={() => setSelectedStudentId(alert.studentId)}
                          className="px-2.5 py-1.5 rounded-lg bg-brand-surface dark:bg-slate-900 text-brand-primary dark:text-indigo-400 border border-brand-container/40 text-[9px] font-bold cursor-pointer hover:bg-brand-primary hover:text-white transition-all flex items-center gap-0.5"
                        >
                          Review <ChevronRight size={10} />
                        </button>
                      </div>
                    ))}

                    {adviseeAlerts.length === 0 && (
                      <div className="p-6 text-center text-xs text-gray-400 font-serif italic">
                        ✓ Absolute Excellence! All assigned advisees meet attendance parameters and evaluation targets.
                      </div>
                    )}
                  </div>
                </div>
              </div>

              {/* Sidebar stats context */}
              <div className="space-y-8">
                <div className="p-6 rounded-2xl neu-flat bg-brand-surface/20 space-y-4">
                  <span className="text-[10px] font-mono font-bold text-gray-400 block uppercase">Advisor context</span>
                  <div className="p-4 rounded-xl neu-inset text-center space-y-1">
                    <span className="text-3xl font-extrabold font-serif italic text-brand-primary mt-1 block">{myAdvisees.length}</span>
                    <span className="text-xs text-gray-400 block">Total Assigned Advisees</span>
                  </div>

                  <p className="text-[10px] text-gray-400 leading-normal font-mono">
                    Advisors possess cross-subject visibility to observe advisee academic status, record timeline session note details, and alert on attendance defaults.
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* ==================== 2. ADVISEES LIST DIRECTORY ==================== */}
          {activeSubTab === "Advisees Directory" && !selectedStudentId && (
            <div className="p-6 rounded-2xl neu-flat space-y-5">
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 border-b border-brand-container pb-4">
                <h3 className="font-bold text-md text-brand-on-surface dark:text-gray-100">Assigned Advisees Register</h3>

                <div className="flex flex-wrap items-center gap-3">
                  <div className="relative">
                    <Search size={14} className="absolute left-3 top-2.5 text-gray-400" />
                    <input
                      type="text"
                      placeholder="Search advisee name, roll..."
                      value={searchText}
                      onChange={(e) => setSearchText(e.target.value)}
                      className="p-2 pl-9 text-xs rounded-xl neu-inset bg-brand-surface dark:bg-brand-dark-surface text-brand-on-surface dark:text-gray-100 outline-none w-[200px]"
                    />
                  </div>

                  <select
                    value={sortField}
                    onChange={(e) => setSortField(e.target.value as any)}
                    className="p-2 text-xs rounded-xl neu-inset bg-brand-surface dark:bg-brand-dark-surface text-brand-on-surface dark:text-gray-100 outline-none cursor-pointer"
                  >
                    <option value="name">Sort by Name</option>
                    <option value="attendance">Sort by Attendance</option>
                  </select>
                </div>
              </div>

              {/* Advisees Register Table */}
              <div className="overflow-x-auto rounded-xl border border-brand-container/20">
                <table className="w-full text-left text-xs">
                  <thead>
                    <tr className="bg-brand-surface-bright dark:bg-slate-900 border-b border-brand-container">
                      <th className="p-3 font-mono text-[10px] uppercase font-bold text-gray-400">Advisee Student</th>
                      <th className="p-3 font-mono text-[10px] uppercase font-bold text-gray-400">Roll ID</th>
                      <th className="p-3 font-mono text-[10px] uppercase font-bold text-gray-400">Term Semester</th>
                      <th className="p-3 font-mono text-[10px] uppercase font-bold text-gray-400 text-center">Attendance Rate</th>
                      <th className="p-3 font-mono text-[10px] uppercase font-bold text-gray-400 text-center">Active Warnings</th>
                      <th className="p-3 font-mono text-[10px] uppercase font-bold text-gray-400 text-center">Action Detail</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-brand-container/40">
                    {getSortedAdvisees().map(adv => {
                      const stats = getStudentAttendanceStats(adv.id);
                      const overdueCount = getStudentOverdueAssignments(adv.id).length;
                      const failingCount = getFailingGrades(adv.id).length;

                      // attendance status coloring
                      let attColor = "text-emerald-500 bg-emerald-500/10";
                      if (stats.percentage < 75) attColor = "text-rose-500 bg-rose-500/10 font-bold";
                      else if (stats.percentage < 80) attColor = "text-amber-500 bg-amber-500/10";

                      return (
                        <tr key={adv.id} className="hover:bg-brand-surface-dim/30">
                          <td className="p-3 font-bold text-brand-on-surface dark:text-gray-200">
                            {adv.name}
                            <span className="text-[10px] text-gray-400 font-mono block mt-0.5">{adv.email}</span>
                          </td>
                          <td className="p-3 font-mono text-[11px] text-brand-on-surface dark:text-gray-200">
                            {adv.rollNumber}
                          </td>
                          <td className="p-3 font-mono text-[11px] text-brand-on-surface dark:text-gray-200">
                            Sem {adv.semester} ({adv.batch})
                          </td>
                          <td className="p-3 text-center">
                            <span className={`text-[10px] font-mono font-bold px-2.5 py-1 rounded-full ${attColor}`}>
                              {stats.percentage}%
                            </span>
                          </td>
                          <td className="p-3 text-center">
                            {overdueCount > 0 || failingCount > 0 ? (
                              <div className="flex justify-center gap-1">
                                {overdueCount > 0 && (
                                  <span className="text-[8px] font-mono font-extrabold bg-amber-500/10 text-amber-500 px-1.5 py-0.5 rounded">
                                    {overdueCount} Overdue
                                  </span>
                                )}
                                {failingCount > 0 && (
                                  <span className="text-[8px] font-mono font-extrabold bg-rose-500/10 text-rose-500 px-1.5 py-0.5 rounded">
                                    {failingCount} Failing
                                  </span>
                                )}
                              </div>
                            ) : (
                              <span className="text-[10px] font-mono text-emerald-500 font-bold">✓ Clean</span>
                            )}
                          </td>
                          <td className="p-3 text-center">
                            <button
                              onClick={() => setSelectedStudentId(adv.id)}
                              className="px-2.5 py-1.5 rounded-lg bg-brand-surface dark:bg-slate-900 border border-brand-container/40 text-[9px] font-bold text-brand-primary dark:text-indigo-400 hover:bg-brand-primary hover:text-white transition-all cursor-pointer"
                            >
                              Open Profile
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* ==================== 3. ADVISEE COMPREHENSIVE DETAIL SCREEN ==================== */}
          {selectedStudentId && studentDetail && (
            <div className="space-y-8">
              {/* Return link */}
              <button
                onClick={() => setSelectedStudentId(null)}
                className="flex items-center gap-1.5 text-xs font-bold text-brand-primary hover:text-brand-primary-container cursor-pointer"
              >
                <ChevronLeft size={16} /> Return to Advisees Directory
              </button>

              {/* Student Header */}
              <div className="p-6 rounded-2xl neu-flat bg-brand-surface/20 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-6">
                <div className="flex gap-4 items-center">
                  <div className="w-16 h-16 rounded-full bg-brand-primary/10 border-2 border-brand-primary/20 flex items-center justify-center text-brand-primary text-xl font-bold font-serif">
                    {studentDetail.name.split(" ").map(n => n[0]).join("")}
                  </div>
                  <div>
                    <h2 className="text-lg font-bold text-brand-on-surface dark:text-gray-100">{studentDetail.name}</h2>
                    <p className="text-xs text-gray-400 font-mono mt-0.5">{studentDetail.rollNumber} | Sem {studentDetail.semester} | Batch {studentDetail.batch}</p>
                    <span className="inline-block text-[9px] font-mono uppercase font-bold bg-indigo-500/10 text-brand-primary px-1.5 py-0.5 rounded mt-2">
                      Academic Ledger Status: {studentDetail.academicStatus || "Active"}
                    </span>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4 text-center sm:text-right">
                  <div className="p-3.5 rounded-xl neu-inset border border-brand-container/20">
                    <span className="text-[8px] font-mono text-gray-500 block uppercase">CGPA Grade Point</span>
                    <span className="text-lg font-bold text-emerald-500 block mt-0.5">3.85 / 4.0</span>
                  </div>
                  <div className="p-3.5 rounded-xl neu-inset border border-brand-container/20">
                    <span className="text-[8px] font-mono text-gray-500 block uppercase">Attendance Rate</span>
                    <span className="text-lg font-bold text-brand-primary block mt-0.5">{detailAttendance.percentage}%</span>
                  </div>
                </div>
              </div>

              {/* Rollup grid mimicking Student dashboards */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                {/* Left 2 Columns: Academics, Exams, Tasks diagnostic */}
                <div className="lg:col-span-2 space-y-8">
                  {/* Attendance Ring replicate */}
                  <div className="p-6 rounded-2xl neu-flat space-y-4">
                    <h3 className="font-bold text-xs font-mono uppercase text-brand-primary tracking-widest">Attendance parameters</h3>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 items-center">
                      <div className="space-y-2">
                        <p className="text-xs text-gray-300 font-medium">Class Attendance Parameters</p>
                        <p className="text-[11px] text-gray-400 leading-relaxed font-mono">
                          Registered hours: {detailAttendance.total} slots.<br />
                          Attended hours: {detailAttendance.present} slots.<br />
                          Deficit: {detailAttendance.total - detailAttendance.present} missed lectures.
                        </p>
                      </div>

                      {/* Diagnostic ring loader */}
                      <div className="flex justify-center">
                        <div className="relative w-24 h-24 flex items-center justify-center">
                          <svg className="w-full h-full transform -rotate-90">
                            <circle cx="48" cy="48" r="38" stroke="currentColor" className="text-brand-container/30" strokeWidth="6" fill="transparent" />
                            <circle cx="48" cy="48" r="38" stroke="currentColor" className="text-brand-primary" strokeWidth="6" fill="transparent" 
                              strokeDasharray={2 * Math.PI * 38}
                              strokeDashoffset={2 * Math.PI * 38 * (1 - detailAttendance.percentage / 100)}
                            />
                          </svg>
                          <span className="absolute text-xs font-mono font-bold text-brand-on-surface dark:text-gray-100">{detailAttendance.percentage}%</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Exam scores published ledger */}
                  <div className="p-6 rounded-2xl neu-flat space-y-4">
                    <h3 className="font-bold text-xs font-mono uppercase text-brand-primary tracking-widest">Syllabus Exam Scores</h3>
                    <div className="overflow-x-auto rounded-xl border border-brand-container/20">
                      <table className="w-full text-left text-xs">
                        <thead>
                          <tr className="bg-brand-surface-bright dark:bg-slate-900 border-b border-brand-container">
                            <th className="p-3 font-mono text-[9px] uppercase font-bold text-gray-400">Exam Test Name</th>
                            <th className="p-3 font-mono text-[9px] uppercase font-bold text-gray-400">Subject Code</th>
                            <th className="p-3 font-mono text-[9px] uppercase font-bold text-gray-400 text-center">Score Grade</th>
                            <th className="p-3 font-mono text-[9px] uppercase font-bold text-gray-400 text-center font-bold">Percentage</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-brand-container/40">
                          {detailMarks.map(mark => {
                            const pct = (mark.score / mark.maxScore) * 100;
                            let scoreStyle = "text-emerald-500 font-bold";
                            if (pct < 50) scoreStyle = "text-rose-500 font-extrabold";

                            return (
                              <tr key={mark.id}>
                                <td className="p-3 font-bold text-brand-on-surface dark:text-gray-200">{mark.examName}</td>
                                <td className="p-3 font-mono text-indigo-400 font-bold">{mark.subjectCode}</td>
                                <td className="p-3 text-center font-bold font-mono text-brand-on-surface dark:text-gray-200">
                                  {mark.score} / {mark.maxScore}
                                </td>
                                <td className={`p-3 text-center font-mono ${scoreStyle}`}>
                                  {pct}%
                                </td>
                              </tr>
                            );
                          })}
                          {detailMarks.length === 0 && (
                            <tr>
                              <td colSpan={4} className="p-4 text-center text-xs text-gray-400 font-serif italic">
                                No published midterm assessments available for review.
                              </td>
                            </tr>
                          )}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>

                {/* Right Column: Confidential Advisor Notes write ledger */}
                <div className="space-y-8">
                  {/* Confidential Advisor notes log */}
                  <div className="p-6 rounded-2xl neu-flat space-y-4">
                    <h3 className="font-bold text-md text-brand-on-surface dark:text-gray-100 flex items-center gap-2">
                      <Notebook size={18} className="text-brand-primary dark:text-indigo-400" />
                      Counselor Log Annotations
                    </h3>

                    {noteSuccess && (
                      <div className="p-2.5 bg-emerald-500/10 border border-emerald-500/20 text-emerald-500 text-xs font-bold text-center rounded-xl">
                        ✓ {noteSuccess}
                      </div>
                    )}

                    {/* Historical Notes */}
                    <div className="space-y-3 max-h-[220px] overflow-y-auto pr-1">
                      {detailNotes.map(n => (
                        <div key={n.id} className="p-3 rounded-xl neu-inset border border-brand-container/10 space-y-1.5 text-[11px]">
                          <p className="text-brand-on-surface dark:text-gray-300 leading-snug">{n.note}</p>
                          <div className="flex justify-between items-center text-[9px] text-gray-500 font-mono">
                            <span>By: {n.advisorName}</span>
                            <span>{new Date(n.createdAt).toLocaleDateString()}</span>
                          </div>
                        </div>
                      ))}
                      {detailNotes.length === 0 && (
                        <p className="text-xs text-gray-400 font-serif italic text-center py-4">No historical advisory notes logged.</p>
                      )}
                    </div>

                    {/* Form to submit note */}
                    <form onSubmit={handleSaveNote} className="space-y-3 pt-3 border-t border-brand-container/30">
                      <div className="space-y-1">
                        <label className="text-[9px] font-mono font-bold uppercase text-gray-400">Append New Advisory Note</label>
                        <textarea
                          required
                          value={newNoteText}
                          onChange={(e) => setNewNoteText(e.target.value)}
                          rows={3}
                          placeholder="Confidential case logs, only visible to other advisors and admins..."
                          className="w-full text-xs p-2.5 rounded-xl neu-inset bg-brand-surface dark:bg-brand-dark-surface text-brand-on-surface dark:text-gray-100 focus:outline-none resize-none"
                        />
                      </div>

                      <button
                        type="submit"
                        className="w-full py-2 bg-brand-primary hover:bg-brand-primary-container text-white text-xs font-bold rounded-xl shadow-md transition-all cursor-pointer flex items-center justify-center gap-1.5"
                      >
                        <Send size={12} /> Log Counselor Note
                      </button>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          )}
        </motion.div>
      </AnimatePresence>
    </div>
  );
}
