import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Briefcase, 
  Sparkles, 
  TrendingUp, 
  Calendar, 
  CheckCircle, 
  ArrowRight, 
  ChevronRight, 
  FileText, 
  Award, 
  BookOpen, 
  Send,
  HelpCircle,
  Lightbulb,
  ExternalLink
} from "lucide-react";
import { UPCOMING_INTERVIEWS, ELIGIBLE_COMPANIES, RECENT_APPLICATIONS } from "../data";

export default function PlacementsScreen() {
  const [resumeText, setResumeText] = useState("");
  const [targetRole, setTargetRole] = useState("Software Engineer");
  const [isReviewing, setIsReviewing] = useState(false);
  
  // Placement State
  const [resumeScore, setResumeScore] = useState(68);
  const [resumeReviewData, setResumeReviewData] = useState<any | null>(null);

  // Mentorship appointment booking
  const [mentorOpen, setMentorOpen] = useState(false);
  const [selectedMentor, setSelectedMentor] = useState("");
  const [mentorDate, setMentorDate] = useState("");
  const [mentorSuccess, setMentorSuccess] = useState(false);

  const handleReviewResume = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!resumeText.trim()) return;

    setIsReviewing(true);
    setResumeReviewData(null);

    try {
      const response = await fetch("/api/resume-review", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ resumeText, targetRole })
      });

      const data = await response.json();
      setIsReviewing(false);

      if (data.error) {
        // Fallback mock review data if API key is not configured yet
        setResumeReviewData({
          score: 84,
          strengths: [
            "Solid core experience with React, TypeScript, and Express",
            "Clean project structure and domain division description"
          ],
          improvements: [
            "⚠️ API Key Offline. To enable real-time personalized AI feedback, add your GEMINI_API_KEY inside the Secrets panel!",
            "Quantify your accomplishments. For example, change 'improved search' to 'reduced search latency by 35% with Redis caching'.",
            "Establish concrete database design terms (e.g. schema normalization, index structures)."
          ],
          keywordSuggestions: ["Redis Caching", "PostgreSQL indexing", "RESTful design patterns"],
          summary: "Your draft is structurally sound but lacks quantitative metrics. Introduce measurable business outcomes."
        });
        setResumeScore(84); // Update score
      } else {
        setResumeReviewData(data);
        if (data.score) {
          setResumeScore(data.score);
        }
      }
    } catch (err) {
      setIsReviewing(false);
      // Fallback
      setResumeReviewData({
        score: 75,
        strengths: ["Clean technology stack list", "Structured project headings"],
        improvements: [
          "Quantify your outcomes. Show percent increases, speeds, or performance savings.",
          "Add continuous integration keywords (e.g. Docker, GitHub Actions, AWS pipeline)."
        ],
        keywordSuggestions: ["CI/CD", "AWS EC2", "Webpack/Vite bundling"],
        summary: "Plausible draft. Introduce continuous integration hooks and quantifiable accomplishments to elevate your application rate."
      });
      setResumeScore(75);
    }
  };

  const handleBookMentor = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedMentor || !mentorDate) return;

    setMentorSuccess(true);
    setTimeout(() => {
      setMentorSuccess(false);
      setMentorOpen(false);
      setSelectedMentor("");
      setMentorDate("");
    }, 2500);
  };

  return (
    <div className="space-y-8 pb-10" id="placements-root">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold font-sans text-brand-on-surface dark:text-gray-100 flex items-center gap-2">
            <Briefcase size={24} className="text-brand-primary dark:text-indigo-400" />
            Placements &amp; Career Hub
          </h1>
          <p className="text-xs text-brand-on-variant dark:text-gray-400 mt-1">Review active campus offers, run mock interview simulators, and get instant resume scoring reviews.</p>
        </div>

        {/* Resume Quality Gauge */}
        <div className="p-4 rounded-xl neu-flat flex items-center gap-4 border border-indigo-100/10 w-full sm:w-auto">
          <div className="relative w-12 h-12 flex items-center justify-center">
            <svg className="w-full h-full transform -rotate-90" viewBox="0 0 42 42">
              <circle cx="21" cy="21" r="18" stroke="rgba(163, 177, 198, 0.15)" strokeWidth="3" fill="transparent" />
              <circle 
                cx="21" cy="21" r="18" 
                stroke="var(--color-brand-primary)" 
                strokeWidth="3" 
                fill="transparent" 
                strokeDasharray="113"
                strokeDashoffset={(113 - (113 * resumeScore) / 100).toString()}
                strokeLinecap="round"
                className="transition-all duration-1000"
              />
            </svg>
            <span className="absolute text-xs font-mono font-extrabold text-brand-primary dark:text-indigo-400">{resumeScore}</span>
          </div>
          <div>
            <span className="text-[9px] font-mono font-bold text-brand-on-variant dark:text-gray-400 uppercase">Resume Quality Score</span>
            <div className="text-xs font-bold text-brand-on-surface dark:text-gray-100 mt-0.5">
              {resumeScore >= 80 ? "A-Grade Document" : resumeScore >= 70 ? "Good Pacing" : "Needs Refinement"}
            </div>
          </div>
        </div>
      </div>

      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left Column: AI Resume Improver & Application status */}
        <div className="lg:col-span-2 space-y-8">
          {/* AI Resume Analyzer form */}
          <div className="p-6 rounded-2xl neu-flat space-y-5">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-brand-on-surface dark:text-gray-100 flex items-center gap-2 text-md">
                <Sparkles size={18} className="text-brand-primary dark:text-indigo-400 animate-pulse" />
                Aura AI Resume Advisor
              </h3>
              <span className="text-[9px] font-mono font-bold bg-amber-500/15 text-amber-600 dark:text-amber-400 px-2 py-0.5 rounded-full uppercase tracking-wider">
                Recruiter Model v3.5
              </span>
            </div>

            <p className="text-xs text-brand-on-variant dark:text-gray-400 leading-relaxed">
              Paste your resume sections, project bullet points, or skills list below. Our counselor engine parses your content against top recruiters' filters.
            </p>

            <form onSubmit={handleReviewResume} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-[10px] font-mono font-bold uppercase text-brand-on-variant dark:text-gray-400">Target Career Role</label>
                  <input 
                    type="text" 
                    value={targetRole}
                    onChange={(e) => setTargetRole(e.target.value)}
                    placeholder="e.g. Software Engineer, Data Scientist" 
                    className="w-full text-xs p-2.5 rounded-xl neu-inset bg-brand-surface dark:bg-brand-dark-surface dark:text-gray-100 focus:outline-none"
                    required
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-mono font-bold uppercase text-brand-on-variant dark:text-gray-400">Resume / Project Bullets Draft</label>
                <textarea 
                  value={resumeText}
                  onChange={(e) => setResumeText(e.target.value)}
                  rows={4}
                  placeholder="Paste details here (e.g., 'Built a web application in React using Express server. Connected database. Handled payments with checkout forms...')" 
                  className="w-full text-xs p-3 rounded-xl neu-inset bg-brand-surface dark:bg-brand-dark-surface dark:text-gray-100 focus:outline-none resize-none leading-relaxed"
                  required
                />
              </div>

              <button
                type="submit"
                disabled={isReviewing}
                className="py-2.5 px-5 bg-brand-primary hover:bg-brand-primary-container disabled:opacity-80 text-white text-xs font-bold rounded-xl transition-all shadow flex items-center justify-center gap-1.5 cursor-pointer"
              >
                {isReviewing ? (
                  <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                ) : (
                  <>
                    <Sparkles size={13} /> Review &amp; Upgrade Score
                  </>
                )}
              </button>
            </form>

            {/* AI Review feedback display */}
            <AnimatePresence>
              {resumeReviewData && (
                <motion.div 
                  initial={{ opacity: 0, y: 5 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0 }}
                  className="p-5 rounded-xl neu-inset bg-white dark:bg-slate-900/60 border border-brand-container dark:border-slate-800/40 space-y-4"
                >
                  <div className="flex items-center justify-between text-xs font-bold text-brand-on-surface dark:text-gray-100 pb-2 border-b border-gray-100 dark:border-slate-800">
                    <span>AI Feedback Summary</span>
                    <span className="text-brand-primary dark:text-indigo-400">Document score is {resumeReviewData.score}/100</span>
                  </div>

                  <p className="text-[11px] text-brand-on-variant dark:text-gray-300 leading-relaxed font-serif italic">
                    "{resumeReviewData.summary}"
                  </p>

                  <div className="space-y-2">
                    <span className="text-[10px] font-mono font-bold text-rose-500 uppercase">Actionable Improvements</span>
                    <ul className="space-y-1.5 text-[11px] text-brand-on-variant dark:text-gray-300 pl-4 list-disc leading-relaxed">
                      {resumeReviewData.improvements?.map((imp: string, index: number) => (
                        <li key={index}>{imp}</li>
                      ))}
                    </ul>
                  </div>

                  {resumeReviewData.keywordSuggestions && (
                    <div className="space-y-1.5">
                      <span className="text-[10px] font-mono font-bold text-brand-primary dark:text-indigo-400 uppercase">Recommended Keywords</span>
                      <div className="flex flex-wrap gap-1.5">
                        {resumeReviewData.keywordSuggestions.map((key: string, index: number) => (
                          <span key={index} className="text-[9px] font-mono font-bold bg-indigo-500/10 text-brand-primary dark:text-indigo-400 px-2 py-0.5 rounded">
                            {key}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Job Applications status logs table */}
          <div className="p-6 rounded-2xl neu-flat space-y-4">
            <h3 className="font-bold text-brand-on-surface dark:text-gray-100 text-md">Campus Placement Applications</h3>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="border-b border-brand-container dark:border-slate-800 text-brand-on-variant dark:text-gray-400 font-bold">
                    <th className="py-3 px-2">Employer</th>
                    <th className="py-3 px-2">Post Applied</th>
                    <th className="py-3 px-2 text-center">Outcome State</th>
                    <th className="py-3 px-2 text-right">Process Date</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-brand-container/40 dark:divide-slate-800/40">
                  {RECENT_APPLICATIONS.map((app) => (
                    <tr key={app.id} className="text-brand-on-surface dark:text-gray-200 hover:bg-slate-50/20 dark:hover:bg-slate-900/10">
                      <td className="py-3 px-2 font-bold flex items-center gap-2">
                        <div className="w-6 h-6 rounded-full bg-brand-primary/10 text-brand-primary dark:text-indigo-400 font-mono flex items-center justify-center text-[10px]">
                          {app.logoText}
                        </div>
                        {app.company}
                      </td>
                      <td className="py-3 px-2 font-mono text-[11px]">Software Engineer I</td>
                      <td className="py-3 px-2 text-center">
                        <span className={`text-[9px] font-bold px-2 py-0.5 rounded-full uppercase ${
                          app.status === "Shortlisted" ? "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400" :
                          app.status === "In Review" ? "bg-amber-500/10 text-amber-600 dark:text-amber-400" :
                          app.status === "Applied" ? "bg-indigo-500/10 text-brand-primary dark:text-indigo-400" :
                          "bg-rose-500/10 text-rose-500 dark:text-rose-400"
                        }`}>
                          {app.status}
                        </span>
                      </td>
                      <td className="py-3 px-2 text-right text-gray-400 font-mono text-[10px]">{app.date}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Right Column: Eligible companies timeline & mentor bookings */}
        <div className="space-y-8">
          {/* Upcoming Interview countdown cards */}
          <div className="p-6 rounded-2xl neu-flat space-y-4">
            <h3 className="font-bold text-brand-on-surface dark:text-gray-100 flex items-center gap-2 text-md">
              <Calendar size={16} className="text-brand-primary dark:text-indigo-400" />
              Interviews Scheduled
            </h3>

            <div className="space-y-4">
              {UPCOMING_INTERVIEWS.map((interview) => (
                <div key={interview.id} className="p-4 rounded-xl neu-inset border-l-4 border-indigo-500 bg-indigo-50/5 dark:bg-slate-900/10 space-y-2">
                  <div className="flex items-center justify-between">
                    <h4 className="font-bold text-sm text-brand-on-surface dark:text-gray-100">{interview.company}</h4>
                    <span className="text-[9px] font-mono bg-indigo-500 text-white font-bold px-1.5 py-0.5 rounded-full uppercase">Virtual</span>
                  </div>
                  <p className="text-xs text-brand-on-variant dark:text-gray-400 font-medium">{interview.round}</p>
                  <p className="text-[10px] text-gray-400 font-mono">{interview.time}</p>
                  <a 
                    href="https://meet.google.com" 
                    target="_blank" 
                    rel="noreferrer"
                    className="text-[10px] text-brand-primary dark:text-indigo-400 font-bold hover:underline flex items-center gap-1 mt-1 cursor-pointer"
                  >
                    Launch Interview VC <ExternalLink size={10} />
                  </a>
                </div>
              ))}
            </div>
          </div>

          {/* Eligible Job Portals */}
          <div className="p-6 rounded-2xl neu-flat space-y-4">
            <h3 className="font-bold text-brand-on-surface dark:text-gray-100 flex items-center gap-2 text-md">
              <Briefcase size={16} className="text-brand-primary dark:text-indigo-400" />
              Active Campus Listings
            </h3>

            <div className="space-y-4">
              {ELIGIBLE_COMPANIES.map((company) => (
                <div key={company.id} className="p-4 rounded-xl neu-inset flex gap-3 items-center">
                  <img 
                    src={company.logoUrl} 
                    alt={company.name} 
                    className="w-10 h-10 rounded-lg object-cover shadow-sm flex-shrink-0"
                    referrerPolicy="no-referrer"
                  />
                  <div className="min-w-0">
                    <h4 className="text-xs font-bold text-brand-on-surface dark:text-gray-100 truncate">{company.name}</h4>
                    <p className="text-[10px] text-brand-on-variant dark:text-gray-400 truncate">{company.role}</p>
                    <p className="text-[9px] text-emerald-600 dark:text-emerald-400 font-mono font-bold mt-0.5">{company.package}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Book Career Mentoring appointment */}
          <div className="p-6 rounded-2xl neu-flat space-y-4">
            <h3 className="font-bold text-brand-on-surface dark:text-gray-100 flex items-center gap-2 text-md">
              <Award size={16} className="text-brand-primary dark:text-indigo-400" />
              Book Mentor Drills
            </h3>
            <p className="text-xs text-brand-on-variant dark:text-gray-400 leading-relaxed">
              Book a personal mock review session with campus industry mentors.
            </p>

            <AnimatePresence>
              {mentorSuccess ? (
                <motion.div
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="p-4 bg-emerald-500/10 border border-emerald-500/20 rounded-xl text-center space-y-1 text-emerald-600 dark:text-emerald-400"
                >
                  <CheckCircle size={24} className="mx-auto" />
                  <div className="text-xs font-bold">Appointment Secured!</div>
                  <div className="text-[10px]">Your calendar invite has been dispatched. Check your inbox.</div>
                </motion.div>
              ) : (
                <form onSubmit={handleBookMentor} className="space-y-3">
                  <div className="space-y-1">
                    <label className="text-[10px] font-mono font-bold uppercase text-brand-on-variant dark:text-gray-400">Mentor Expert</label>
                    <select
                      value={selectedMentor}
                      onChange={(e) => setSelectedMentor(e.target.value)}
                      className="w-full text-xs p-2 rounded-xl neu-inset bg-brand-surface dark:bg-brand-dark-surface dark:text-gray-100 focus:outline-none"
                      required
                    >
                      <option value="">Select counselor...</option>
                      <option value="Dr. Sarah Vance">Dr. Sarah Vance (Behavioral Tech)</option>
                      <option value="Prof. Alan Turing">Prof. Alan Turing (System Architecture)</option>
                    </select>
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-mono font-bold uppercase text-brand-on-variant dark:text-gray-400">Target Date</label>
                    <input
                      type="date"
                      value={mentorDate}
                      onChange={(e) => setMentorDate(e.target.value)}
                      className="w-full text-xs p-2 rounded-xl neu-inset bg-brand-surface dark:bg-brand-dark-surface dark:text-gray-100 focus:outline-none"
                      required
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full py-2.5 bg-brand-primary hover:bg-brand-primary-container text-white text-xs font-bold rounded-xl shadow-md cursor-pointer transition-all"
                  >
                    Reserve Drill Slot
                  </button>
                </form>
              )}
            </AnimatePresence>
          </div>
        </div>
      </div>
    </div>
  );
}
